export interface UserData {
  uid: string;
  appUid: string;
  appName: string;
  email: string;
  phone: string;
  balance: number;
  joined_matches: string[];
  score: number;
  kills: number;
  matchesPlayed: number;
  matchesWon: number;
  totalEarned: number;
  gameName: string;
  gameUid: string;
  isUidVerified: boolean;
  photoUrl?: string;
  paymentMethod?: string;
  paymentName?: string;
  nameChangesLeft: number;
  matchSlots?: Record<string, number>;
}

export interface Match {
  id: string;
  title: string;
  type: string; // e.g. Solo, Duo, Squad, CS-Ranked, Battle Royale
  map: string; // Bermuda, Purgatory, etc.
  prize: number;
  fee: number;
  total: number;
  joined: number;
  img?: string;
  startTime?: { seconds: number; nanoseconds: number } | string | any;
  roomId?: string;
  roomPass?: string;
  status: "upcoming" | "completed";
  winnerName?: string;
  teamMode?: string; // Solo, Duo, Trio, Squad, Squad 4v4 etc.
  perKill?: number;  // Per Kill bounty
  platform?: string;  // MOBILE or PC
  rules?: string;     // Custom match-specific fairplay rules
}

export interface Transaction {
  id: string;
  title: string;
  amount: string;
  type: "deposit" | "withdraw" | "game" | "transfer";
  status: "pending" | "success" | "failed";
  trxId?: string;
  number?: string;
  method?: string;
  note?: string;
  date: string;
  createdAt?: number;
}

export interface AppConfig {
  bannerUrl: string;
  notice: string;
  adminPhone: string;
  bkashPhone?: string;
  nagadPhone?: string;
  rocketPhone?: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  timestamp: any;
}

export interface Giveaway {
  id: string;
  code: string;
  reward: number;
  claimedBy: string[];
  createdAt: number;
}
