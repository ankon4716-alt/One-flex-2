import React, { useState } from "react";
import { UserData } from "../types";
import {
  User,
  Plus,
  Coins,
  Copy,
  ChevronRight,
  Trophy,
  LogOut,
  Mail,
  ReceiptText,
  Wallet,
  Gift,
  FileText,
  ShieldCheck,
  Share2,
  Terminal,
  Headphones,
  X,
  CircleCheck,
  ArrowLeft,
  Lock,
  Scan,
  Edit,
  Phone,
  Zap,
  Bell,
} from "lucide-react";
import { sendPasswordResetEmail } from "firebase/auth";
import { auth } from "../firebase";

interface ProfileViewProps {
  userData: UserData | null;
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
  onOpenEditProfile: () => void;
  onSelectView: (view: string) => void;
  onLogout: () => void;
  onCopyText: (text: string) => void;
  onToast: (msg: string) => void;
  onRedeemPromo: (code: string) => Promise<void>;
  onOpenNotifications: () => void;
  hasUnreadNotification: boolean;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userData,
  onOpenDeposit,
  onOpenWithdraw,
  onOpenEditProfile,
  onSelectView,
  onLogout,
  onCopyText,
  onToast,
  onRedeemPromo,
  onOpenNotifications,
  hasUnreadNotification,
}) => {
  // If guest, show a placeholder asking to authenticate
  if (!userData) {
    return (
      <div className="w-full bg-[#0d121f] min-h-[calc(100vh-130px)] flex flex-col items-center justify-center p-6 text-white text-center">
        <div className="h-16 w-16 bg-indigo-950 border border-indigo-500/20 rounded-full flex items-center justify-center text-indigo-400 mb-4 animate-pulse">
          <User className="h-8 w-8" />
        </div>
        <h3 className="text-base font-black tracking-tight">Authentic Profile Needed</h3>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          Sign up or log in to generate your gamer tag, load stable coins wallet, and participate in cash match rooms.
        </p>
        <button
          onClick={() => onSelectView("home")}
          className="mt-6 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 font-extrabold text-xs rounded-xl shadow cursor-pointer transition-colors"
        >
          Go Back to Home
        </button>
      </div>
    );
  }

  // Display initial
  const [giveawayModal, setGiveawayModal] = useState(false);
  const [giveawayCode, setGiveawayCode] = useState("");
  const [giveawayApplied, setGiveawayApplied] = useState(false);
  const [termsModal, setTermsModal] = useState(false);
  const [privacyModal, setPrivacyModal] = useState(false);
  const [devInfoModal, setDevInfoModal] = useState(false);
  const [showProfileDetail, setShowProfileDetail] = useState(false);

  const handleResetPassword = async () => {
    if (!userData?.email) return;
    try {
      await sendPasswordResetEmail(auth, userData.email);
      onToast("Password reset email sent! Please check your inbox.");
    } catch (e: any) {
      onToast(e.message || "Failed to send reset email.");
    }
  };

  const initialLetter = userData.appName ? userData.appName.charAt(0).toUpperCase() : "G";
  const formattedCardHolder = userData.appName ? userData.appName.toUpperCase() : "PRO GAMER";

  // Quick theme toggle helper
  const handleToggleTheme = () => {
    onToast("Dark mode activated. Visual layout optimized for gamers!");
  };

  // Quick language toggle helper
  const handleToggleLanguage = () => {
    onToast("Language default set to English");
  };

  if (showProfileDetail) {
    return (
      <div className="w-full bg-[#0e0f13] min-h-screen text-slate-100 pb-36 select-none animate-fade-in">
        {/* Detail Header area mimicking the screenshot */}
        <div className="flex items-center justify-between px-4 pt-6 pb-4 border-b border-slate-800/20 bg-[#0e0f13] sticky top-0 z-30">
          <button
            onClick={() => setShowProfileDetail(false)}
            className="p-1.5 hover:bg-[#1a1b24] rounded-full cursor-pointer text-white transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h2 className="text-base font-black text-slate-100 text-center tracking-wide flex-1 pr-6">
            My Profile
          </h2>
        </div>

        {/* Centered Avatar silhouette layout */}
        <div className="flex flex-col items-center justify-center pt-8 pb-10 px-4">
          <div className="relative">
            {/* Real distinct dual glow amber/indigo gradient outline circle */}
            <div className="h-28 w-28 rounded-full bg-gradient-to-tr from-indigo-500 via-indigo-600 to-amber-500 p-1 flex items-center justify-center shadow-xl shadow-amber-500/10">
              <div className="w-full h-full rounded-full bg-[#0e0f13] flex items-center justify-center border-2 border-indigo-950/20">
                <User className="h-14 w-14 text-white stroke-[1.2]" />
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic User Profile parameter cards */}
        <div className="px-4 space-y-4">
          {/* Card 1: UID */}
          <div className="flex items-center p-4 bg-[#14151a] border border-[#22242c]/70 rounded-2xl shadow-md">
            <div className="h-12 w-12 bg-[#21222b] rounded-2xl flex items-center justify-center text-slate-350 mr-4 shrink-0">
              <Scan className="h-5 w-5 stroke-[2]" />
            </div>
            <div>
              <span className="text-[10.5px] text-slate-450 font-bold uppercase tracking-wider block leading-none mb-1">
                UID
              </span>
              <span className="text-sm font-extrabold text-white block tracking-widest font-mono font-bold">
                {userData.gameUid || "6116"}
              </span>
            </div>
          </div>

          {/* Card 2: Full Name */}
          <div className="flex items-center p-4 bg-[#14151a] border border-[#22242c]/70 rounded-2xl shadow-md">
            <div className="h-12 w-12 bg-[#21222b] rounded-2xl flex items-center justify-center text-slate-350 mr-4 shrink-0">
              <User className="h-5 w-5 stroke-[2]" />
            </div>
            <div>
              <span className="text-[10.5px] text-slate-450 font-bold uppercase tracking-wider block leading-none mb-1">
                Full Name
              </span>
              <span className="text-sm font-extrabold text-white block tracking-wide">
                {userData.appName || "only zixu"}
              </span>
            </div>
          </div>

          {/* Card 2.5: In-Game Name */}
          <div className="flex items-center p-4 bg-[#14151a] border border-[#22242c]/70 rounded-2xl shadow-md">
            <div className="h-12 w-12 bg-[#21222b] rounded-2xl flex items-center justify-center text-slate-350 mr-4 shrink-0">
              <Trophy className="h-5 w-5 stroke-[2]" />
            </div>
            <div>
              <span className="text-[10.5px] text-slate-450 font-bold uppercase tracking-wider block leading-none mb-1">
                In-Game Name
              </span>
              <span className="text-sm font-extrabold text-white block tracking-wide">
                {userData.gameName || "Not Set"}
              </span>
            </div>
          </div>

          {/* Card 3: Email */}
          <div className="flex items-center p-4 bg-[#14151a] border border-[#22242c]/70 rounded-2xl shadow-md">
            <div className="h-12 w-12 bg-[#21222b] rounded-2xl flex items-center justify-center text-slate-350 mr-4 shrink-0">
              <Mail className="h-5 w-5 stroke-[2]" />
            </div>
            <div className="min-w-0 pr-2">
              <span className="text-[10.5px] text-slate-450 font-bold uppercase tracking-wider block leading-none mb-1 font-sans">
                Email
              </span>
              <span className="text-sm font-extrabold text-white block truncate tracking-wide">
                {userData.email}
              </span>
            </div>
          </div>

          {/* Card 4: Phone Number */}
          <div className="flex items-center p-4 bg-[#14151a] border border-[#22242c]/70 rounded-2xl shadow-md">
            <div className="h-12 w-12 bg-[#21222b] rounded-2xl flex items-center justify-center text-slate-350 mr-4 shrink-0">
              <Phone className="h-5 w-5 stroke-[2]" />
            </div>
            <div>
              <span className="text-[10.5px] text-slate-450 font-bold uppercase tracking-wider block leading-none mb-1">
                Phone Number
              </span>
              <span className="text-sm font-extrabold text-white block tracking-wide font-mono font-bold">
                {userData.phone || "01919738413"}
              </span>
            </div>
          </div>
        </div>

        {/* Action button triggers matching screenshot style */}
        <div className="px-4 mt-8 space-y-4">
          <button
            onClick={onOpenEditProfile}
            className="w-full py-4 bg-[#3b82f6] hover:bg-[#2563eb] text-white text-sm font-black uppercase tracking-wider rounded-2xl shadow-lg cursor-pointer flex items-center justify-center gap-2.5 transition-all duration-150 active:scale-[0.99]"
          >
            <Edit className="h-4.5 w-4.5" />
            <span>Edit Profile</span>
          </button>

          <button
            onClick={handleResetPassword}
            className="w-full py-4 bg-[#111216] border border-[#22242c] hover:bg-[#1c1d24] text-white text-sm font-extrabold tracking-wider rounded-2xl cursor-pointer flex items-center justify-center gap-2.5 transition-all duration-150 active:scale-[0.99] shadow"
          >
            <Lock className="h-4.5 w-4.5 text-slate-400" />
            <span>Reset Password</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-[#0a0b0d] min-h-screen text-slate-100 pb-36 select-none animate-fade-in">
      {/* Top Header Row with Exit/Back Option */}
      <div className="px-4 pt-5 pb-2 flex items-center justify-between border-b border-[#21242c]/20 bg-[#0a0b0d] sticky top-0 z-30">
        <button
          onClick={() => onSelectView("home")}
          className="h-10 w-10 flex items-center justify-center rounded-xl bg-[#141722] border border-[#242835]/45 text-slate-300 hover:text-white transition-colors active:scale-95 cursor-pointer"
          title="Back to Lobby"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <span className="text-xs font-black uppercase tracking-widest text-[#2d82fe] font-sans">
          Profile Hub
        </span>
        <div className="w-10 h-10" /> {/* empty spacer for balanced centering */}
      </div>

      {/* Outer Card wrapping the Profile Header block and stat panels */}
      <div className="px-4 pt-4">
        <div className="w-full bg-[#141722] border border-[#242835]/40 rounded-[28px] p-5 shadow-xl relative overflow-hidden">
          {/* Ambient card background decorations */}
          <div className="absolute top-[-30px] right-[-30px] w-32 h-32 rounded-full bg-blue-500/5 blur-2xl pointer-events-none" />
          <div className="absolute bottom-[-30px] left-[-30px] w-24 h-24 rounded-full bg-orange-500/5 blur-xl pointer-events-none" />

          {/* User Side-By-Side Information Row */}
          <div className="flex items-center gap-4.5 pb-5">
            {/* Left: Avatar with Amber/indigo active circle ring */}
            <div className="relative shrink-0">
              <div className="h-24 w-24 rounded-full bg-gradient-to-tr from-amber-500 via-[#fd7e14] to-yellow-400 p-[3px] flex items-center justify-center shadow-[0_0_22px_rgba(245,158,11,0.4)]">
                <div className="w-full h-full rounded-full bg-[#0e1015] flex items-center justify-center">
                  <User className="h-12 w-12 text-slate-100 stroke-[1.5]" />
                </div>
              </div>
              <span className="absolute bottom-1 right-1 h-3.5 w-3.5 bg-emerald-500 border-2 border-[#141722] rounded-full animate-pulse" />
            </div>

            {/* Right: User Text Details stacked vertically */}
            <div className="flex-1 min-w-0 font-sans">
              <h2 className="text-xl font-black text-white truncate tracking-wide leading-snug">
                {userData.appName || "only zixu"}
              </h2>
              <p className="text-[12px] text-slate-400 font-mono tracking-wider mt-0.5 select-all">
                {userData.phone || "01919738413"}
              </p>
              <p className="text-[11px] text-slate-400 truncate mt-0.5 select-all">
                {userData.email || "costaankon6@gmail.com"}
              </p>

              {/* Pill badges container */}
              <div className="flex flex-wrap gap-2 mt-3.5">
                {/* 4-Digit permanent App UID Pill badge */}
                <div
                  onClick={() => {
                    onCopyText(userData.appUid || "---");
                    onToast("App UID Copied to Clipboard!");
                  }}
                  className="inline-flex items-center gap-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 active:scale-95 text-emerald-400 font-extrabold text-[10.5px] px-3 py-1.5 rounded-full border border-emerald-500/20 cursor-pointer transition-all"
                  title="Your permanent transfer/win App UID"
                >
                  <Zap className="h-3.5 w-3.5 text-emerald-400 stroke-[2.5]" />
                  <span className="tracking-wide">Id: {userData.appUid || "---"}</span>
                  <Copy className="h-2.5 w-2.5 ml-0.5 text-emerald-400 opacity-80" />
                </div>

                {/* Pill badge of Gamer UID */}
                <div
                  onClick={() => {
                    onCopyText(userData.gameUid || "6116");
                    onToast("UID Copied to Clipboard!");
                  }}
                  className="inline-flex items-center gap-1.5 bg-blue-500/10 hover:bg-blue-500/20 active:scale-95 text-[#2d82fe] font-extrabold text-[10.5px] px-3 py-1.5 rounded-full border border-blue-500/20 cursor-pointer transition-all"
                  title="Click to copy game UID"
                >
                  <User className="h-3.5 w-3.5 text-blue-400 stroke-[2.5]" />
                  <span className="tracking-wide">UID: {userData.gameUid || "6116"}</span>
                  <Copy className="h-2.5 w-2.5 ml-0.5 text-blue-400 opacity-80" />
                </div>
              </div>
            </div>
          </div>

          {/* Main Balance Container Card */}
          <div className="bg-[#10131e] border border-[#242835]/25 rounded-3xl p-5 mb-4 shadow-inner relative z-10">
            {/* Top row: main balance wallet */}
            <div className="flex justify-between items-center pb-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 bg-emerald-500/10 border border-emerald-500/15 rounded-full flex items-center justify-center text-emerald-400 shrink-0">
                  <Wallet className="h-6 w-6 stroke-[2]" />
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 font-bold block leading-none mb-1">
                    Main Balance
                  </span>
                  <span className="text-3xl font-black text-white tracking-wide font-sans flex items-baseline gap-0.5">
                    <span className="text-xl font-bold font-sans text-slate-100">৳</span>
                    {userData.balance ?? 0}
                  </span>
                </div>
              </div>

              {/* Dynamic plus button triggers deposit */}
              <button
                onClick={onOpenDeposit}
                className="h-14 w-14 rounded-2xl bg-[#2d82fe] hover:bg-blue-600 text-white flex items-center justify-center cursor-pointer transition-all transform active:scale-95 shadow-lg shadow-blue-500/15"
                title="Add balance"
              >
                <Plus className="h-7 w-7 stroke-[3]" />
              </button>
            </div>

            {/* Separating horizontal solid divider */}
            <div className="border-t border-slate-800/40 my-1" />

            {/* Bottom row: winning balance details - Clicking this opens My Wallet view */}
            <div 
              onClick={() => onSelectView("wallet")}
              className="flex justify-between items-center pt-4 cursor-pointer hover:bg-slate-900/40 p-2 -mx-2 rounded-2xl transition-all"
              title="Open My Wallet"
            >
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 bg-amber-500/10 border border-amber-500/15 rounded-full flex items-center justify-center text-amber-500 shrink-0">
                  <Trophy className="h-6 w-6 stroke-[2]" />
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 font-bold block leading-none mb-1">
                    Winning Balance
                  </span>
                  <span className="text-2xl font-black text-amber-500 tracking-wide font-sans flex items-baseline gap-0.5">
                    <span className="text-lg font-bold font-sans text-amber-500">৳</span>
                    {userData.winBalance ?? 0}
                  </span>
                </div>
              </div>

              {/* Winning balance details button which directs to wallet view */}
              <div
                className="px-5 py-2.5 bg-[#1e202a] hover:bg-[#252836] rounded-xl text-slate-100 text-xs font-black tracking-wide flex items-center gap-1 transition-all active:scale-[0.98] shadow"
              >
                <span>Details</span>
                <ChevronRight className="h-4 w-4 text-slate-400 stroke-[2.5]" />
              </div>
            </div>
          </div>

          {/* Equal Width Side-by-Side Matches Counters Bento Grid */}
          <div className="grid grid-cols-2 gap-4">
            {/* Matches Played Box */}
            <div className="bg-[#141722] border border-[#242835]/40 rounded-2xl p-5 text-center shadow-md relative group">
              <span className="text-3xl font-black text-white block tracking-wide font-sans">
                {userData.matchesPlayed ?? 0}
              </span>
              <span className="text-[11px] text-slate-400 font-bold mt-1 block uppercase tracking-wider font-sans">
                Matches Played
              </span>
            </div>

            {/* Matches Won Box */}
            <div className="bg-[#141722] border border-amber-500/30 rounded-2xl p-5 text-center shadow-[0_0_15px_rgba(245,158,11,0.03)] relative group">
              <span className="text-3xl font-black text-white block tracking-wide font-sans">
                {userData.matchesWon ?? 0}
              </span>
              <span className="text-[11px] text-slate-403 font-bold mt-1 block uppercase tracking-wider font-sans">
                Matches Won
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Grouped Profile Settings Navigation Blocks */}
      <div className="px-4 mt-8 space-y-6">
        
        {/* Account Center Group */}
        <div>
          <h3 className="text-lg font-black text-white tracking-wide mb-3 pl-1 font-sans">
            Account Center
          </h3>
          <div className="space-y-3">
            {/* 1. Profile option card */}
            <button
              onClick={() => setShowProfileDetail(true)}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <User className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Profile
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* 2. My Wallet Option */}
            <button
              onClick={() => onSelectView("wallet")}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <Wallet className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  My Wallet
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* 3. All Statements Option */}
            <button
              onClick={() => onSelectView("statements")}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <ReceiptText className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  All Statements
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* 4. Giveaway Code Option */}
            <button
              onClick={() => setGiveawayModal(true)}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <Gift className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Giveaway Code
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>
          </div>
        </div>

        {/* Game Center Group */}
        <div>
          <h3 className="text-lg font-black text-white tracking-wide mb-3 pl-1 font-sans">
            Game Center
          </h3>
          <div className="space-y-3">
            {/* Leaderboard Option */}
            <button
              onClick={() => onSelectView("leaderboard")}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <Trophy className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Leaderboard
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* Notifications Alert Option */}
            <button
              onClick={onOpenNotifications}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm relative"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150 relative">
                  <Bell className="h-5 w-5 stroke-[2]" />
                  {hasUnreadNotification && (
                    <span className="absolute top-2 right-2 h-2.5 w-2.5 rounded-full bg-red-500 border border-[#141722] animate-pulse" />
                  )}
                </div>
                <div className="text-left">
                  <span className="text-sm font-bold text-slate-200 tracking-wide font-sans block">
                    Notification Inbox
                  </span>
                  {hasUnreadNotification ? (
                    <span className="text-[10px] font-black text-rose-400">You have unread updates</span>
                  ) : (
                    <span className="text-[10px] text-slate-400">System announcements</span>
                  )}
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>
          </div>
        </div>

        {/* More Settings Group */}
        <div>
          <h3 className="text-lg font-black text-white tracking-wide mb-3 pl-1 font-sans">
            More
          </h3>
          <div className="space-y-3">
            {/* Terms and Condition Option */}
            <button
              onClick={() => setTermsModal(true)}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <FileText className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Terms and Condition
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* Privacy Policy Option */}
            <button
              onClick={() => setPrivacyModal(true)}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <ShieldCheck className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Privacy Policy
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* Share App Option */}
            <button
              onClick={() => {
                const shareText = "Hey! Join daily match segments on Ꭷɴᴇㅤꜰʟᴇx.!TUR!, play with pro gamers, and make instant stable-coin money!";
                if (navigator.share) {
                  navigator.share({
                    title: "Ꭷɴᴇㅤꜰʟᴇx.!TUR! Custom Match Platform",
                    text: shareText,
                    url: window.location.origin,
                  }).catch(() => {});
                } else {
                  onCopyText(window.location.origin);
                  onToast("Invite Link copied to Clipboard! Share it with your friends.");
                }
              }}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <Share2 className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Share App
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>

            {/* Developer Info Option */}
            <button
              onClick={() => setDevInfoModal(true)}
              className="w-full flex items-center justify-between p-4 bg-[#141722] border border-[#242835]/40 rounded-[20px] cursor-pointer hover:bg-[#1b1e2a] transition-all duration-150 active:scale-[0.99] group shadow-sm"
            >
              <div className="flex items-center gap-4.5">
                <div className="h-11 w-11 bg-white/5 rounded-full flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-150">
                  <Terminal className="h-5 w-5 stroke-[2]" />
                </div>
                <span className="text-sm font-bold text-slate-200 tracking-wide font-sans">
                  Developer Info
                </span>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-slate-200 transition-colors" />
            </button>
          </div>
        </div>

        {/* LOGOUT BUTTON CENTERED WITH RED BORDER SCREENSHOT PATTERN */}
        <div className="pt-4 pb-8">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-3 py-4 border border-red-500/20 bg-red-500/5 text-red-500 text-sm font-bold uppercase tracking-widest rounded-2xl hover:bg-rose-500/5 active:scale-[0.98] transition-all cursor-pointer font-sans"
          >
            <LogOut className="h-5 w-5 text-red-500" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* FLOATING CORNER CUSTOMER SUPPORT HEADSET BUTTON */}
      <button
        onClick={() => {
          onCopyText("01726471689");
          onToast("WhatsApp support line copied! Opening chat link...");
          window.open("https://wa.me/8801726471689", "_blank");
        }}
        className="fixed bottom-24 right-5 h-14 w-14 rounded-full bg-[#181a24] border-2 border-white flex items-center justify-center text-white cursor-pointer active:scale-95 duration-150 transition-all shadow-xl hover:shadow-2xl z-40 group animate-bounce"
        title="Admin Support Contact"
      >
        <div className="absolute inset-0 rounded-full border border-white/20 scale-110 group-hover:animate-ping opacity-60" />
        <Headphones className="h-6 w-6 text-white shrink-0" />
      </button>

      {/* 1. GIVEAWAY CODE MODAL */}
      {giveawayModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in select-none">
          <div className="bg-[#121622] border border-[#242835]/75 rounded-3xl p-6 w-full max-w-sm text-center shadow-2xl relative">
            <button
              onClick={() => {
                setGiveawayModal(false);
                setGiveawayCode("");
                setGiveawayApplied(false);
              }}
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-slate-800/40 hover:bg-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="h-14 w-14 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500 mx-auto mb-4 animate-bounce">
              <Gift className="h-7 w-7" />
            </div>

            <h3 className="text-base font-black tracking-widest text-white uppercase">Redeem Giveaway Code</h3>
            <p className="text-[11px] text-slate-400 mt-2 font-medium leading-relaxed max-w-[260px] mx-auto">
              Enter official promotional or event giveaway codes to secure live wallet rewards instantly.
            </p>

            <div className="mt-5 space-y-4">
              <input
                type="text"
                placeholder="ENTER PROMO / CODE HERE"
                value={giveawayCode}
                onChange={(e) => setGiveawayCode(e.target.value)}
                className="w-full text-center text-xs font-black tracking-widest uppercase p-3.5 bg-slate-900 border border-[#242835] rounded-xl text-white focus:border-amber-500 outline-none font-mono"
              />

              <button
                onClick={async () => {
                  if (!giveawayCode.trim()) {
                    onToast("Please enter a valid code");
                    return;
                  }
                  try {
                    await onRedeemPromo(giveawayCode);
                    setGiveawayModal(false);
                    setGiveawayCode("");
                  } catch (e) {}
                }}
                className="w-full py-3 bg-[#008744] hover:bg-[#007038] text-white text-[12px] font-black uppercase tracking-widest rounded-xl shadow-lg transition-all active:scale-[0.98] cursor-pointer"
              >
                CLAIM CODE NOW
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. TERMS & CONDITIONS MODAL */}
      {termsModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in select-none">
          <div className="bg-[#121622] border border-[#242835]/75 rounded-3xl p-6 w-full max-w-sm shadow-2xl relative flex flex-col max-h-[80vh]">
            <button
              onClick={() => setTermsModal(false)}
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-slate-800/40 hover:bg-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="h-12 w-12 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-4 shrink-0">
              <FileText className="h-6 w-6" />
            </div>

            <h3 className="text-base font-black tracking-widest text-white uppercase mb-1">Terms and Condition</h3>
            <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider mb-4 shrink-0">
              User & Gamer Regulations
            </p>

            <div className="flex-1 overflow-y-auto pr-1 space-y-3.5 text-[11px] text-slate-400 leading-relaxed scrollbar-thin">
              <div>
                <h4 className="font-extrabold text-white uppercase tracking-wide">1. Professional Fair Play</h4>
                <p className="mt-1">
                  Any usage of third-party helper apps, macro tools, scripts, or speed hackers triggers immediate lifetime platform bans with forfeit account balances.
                </p>
              </div>
              <div className="border-t border-[#242835]/30 pt-3">
                <h4 className="font-extrabold text-white uppercase tracking-wide">2. Room Timing & Disconnects</h4>
                <p className="mt-1">
                  Room IDs are loaded timely. If you fail to join within the designated slot minutes, match rules proceed as scheduled. No slot fee returns are verified.
                </p>
              </div>
              <div className="border-t border-[#242835]/30 pt-3">
                <h4 className="font-extrabold text-white uppercase tracking-wide">3. Cash Out Audits</h4>
                <p className="mt-1 text-amber-500">
                  Winnings withdraw process completes manually in 1 to 24 business hours as per system transaction verification checks.
                </p>
              </div>
            </div>

            <button
              onClick={() => setTermsModal(false)}
              className="mt-6 w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-black uppercase tracking-widest rounded-xl transition-all active:scale-[0.98] cursor-pointer shrink-0"
            >
              I ACCEPT REGULATIONS
            </button>
          </div>
        </div>
      )}

      {/* 3. PRIVACY POLICY MODAL */}
      {privacyModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in select-none">
          <div className="bg-[#121622] border border-[#242835]/75 rounded-3xl p-6 w-full max-w-sm shadow-2xl relative flex flex-col max-h-[80vh]">
            <button
              onClick={() => setPrivacyModal(false)}
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-slate-800/40 hover:bg-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="h-12 w-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-4 shrink-0">
              <ShieldCheck className="h-6 w-6" />
            </div>

            <h3 className="text-base font-black tracking-widest text-white uppercase mb-1">Privacy Policy</h3>
            <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider mb-4 shrink-0">
              Secure Data Protocol
            </p>

            <div className="flex-1 overflow-y-auto pr-1 space-y-3.5 text-[11px] text-slate-400 leading-relaxed scrollbar-thin">
              <div>
                <h4 className="font-extrabold text-white uppercase tracking-wide">1. Data Storage</h4>
                <p className="mt-1">
                  Your primary coordinates, email handle, and in-game numeric UID credentials are encrypted on Firebase secure cloud repositories. No external sharing occurs.
                </p>
              </div>
              <div className="border-t border-[#242835]/30 pt-3">
                <h4 className="font-extrabold text-white uppercase tracking-wide">2. Absolute Logs Protection</h4>
                <p className="mt-1">
                  Deposit logs and cashout handles via Nagad / bKash stay monitored purely for direct processing. We store no personal banking credentials or passwords.
                </p>
              </div>
            </div>

            <button
              onClick={() => setPrivacyModal(false)}
              className="mt-6 w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-black uppercase tracking-widest rounded-xl transition-all active:scale-[0.98] cursor-pointer shrink-0"
            >
              OK, GOT IT
            </button>
          </div>
        </div>
      )}

      {/* 4. DEVELOPER INFO MODAL */}
      {devInfoModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in select-none">
          <div className="bg-[#121622] border border-[#242835]/75 rounded-3xl p-6 w-full max-w-sm text-center shadow-2xl relative">
            <button
              onClick={() => setDevInfoModal(false)}
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-slate-800/40 hover:bg-slate-700/50 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="h-14 w-14 rounded-full bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-500 mx-auto mb-4 animate-pulse">
              <Terminal className="h-6 w-6" />
            </div>

            <h3 className="text-base font-black tracking-widest text-white uppercase">Developer Info</h3>
            <p className="text-[10px] text-rose-400 font-bold uppercase tracking-widest mt-1">
              Ꭷɴᴇㅤꜰʟᴇx. Mod
            </p>

            <div className="mt-5 p-4 bg-slate-900 border border-[#242835]/65 rounded-2xl text-left space-y-2 text-[11px]">
              <div className="flex justify-between items-center bg-slate-950/40 px-3 py-2 rounded-xl">
                <span className="text-slate-450 font-bold uppercase tracking-wider">Owner:</span>
                <span className="text-white font-extrabold font-mono text-xs">ANKON PRO</span>
              </div>
              <div className="flex justify-between items-center bg-slate-950/40 px-3 py-2 rounded-xl">
                <span className="text-slate-450 font-bold uppercase tracking-wider">Contact Phone:</span>
                <span className="text-white font-extrabold font-mono text-xs">01726471689</span>
              </div>
              <div className="flex justify-between items-center bg-slate-950/40 px-3 py-2 rounded-xl">
                <span className="text-slate-450 font-bold uppercase tracking-wider">Framework:</span>
                <span className="text-emerald-400 font-extrabold uppercase">React & FireDB</span>
              </div>
            </div>

            <button
              onClick={() => setDevInfoModal(false)}
              className="mt-6 w-full py-3 bg-gradient-to-r from-indigo-600 to-rose-600 hover:from-indigo-700 hover:to-rose-700 text-white text-[11px] font-black uppercase tracking-widest rounded-xl shadow-lg transition-all active:scale-[0.98] cursor-pointer"
            >
              CLOSE INFO
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
