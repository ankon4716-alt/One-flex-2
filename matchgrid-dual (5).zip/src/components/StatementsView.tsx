import React, { useState, useMemo } from "react";
import { Transaction, UserData } from "../types";
import { 
  ArrowLeft, 
  ArrowUpRight, 
  ArrowDownRight, 
  Gamepad2, 
  Trophy, 
  Gift, 
  Sparkles, 
  Zap, 
  Search, 
  Coins 
} from "lucide-react";

interface StatementsViewProps {
  userData: UserData | null;
  transactions: Transaction[];
  onBack: () => void;
}

export const StatementsView: React.FC<StatementsViewProps> = ({
  userData,
  transactions,
  onBack,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const filters = [
    "All",
    "Deposit",
    "Withdrawal",
    "Registration Fee",
    "Prize",
    "Gift",
    "Giveaways",
    "Admin"
  ];

  const filterTransactions = (tab: string, t: Transaction): boolean => {
    const titleLower = (t.title || "").toLowerCase();
    const noteLower = (t.note || "").toLowerCase();
    
    if (tab === "All") return true;
    if (tab === "Deposit") {
      return t.type === "deposit" || titleLower.includes("deposit") || noteLower.includes("deposit");
    }
    if (tab === "Withdrawal") {
      return t.type === "withdraw" || titleLower.includes("withdraw") || titleLower.includes("cashout") || noteLower.includes("withdraw") || noteLower.includes("cashout");
    }
    if (tab === "Registration Fee") {
      return (
        titleLower.includes("fee") || 
        titleLower.includes("registration") || 
        titleLower.includes("joining") || 
        titleLower.includes("join") ||
        noteLower.includes("fee") || 
        noteLower.includes("registration")
      );
    }
    if (tab === "Prize") {
      return (
        titleLower.includes("prize") || 
        titleLower.includes("won") || 
        titleLower.includes("win") || 
        titleLower.includes("victory") || 
        titleLower.includes("tournament") ||
        noteLower.includes("prize") ||
        noteLower.includes("winner")
      );
    }
    if (tab === "Gift") {
      return titleLower.includes("gift") || noteLower.includes("gift");
    }
    if (tab === "Giveaways") {
      return (
        titleLower.includes("giveaway") || 
        noteLower.includes("giveaway") || 
        titleLower.includes("code") || 
        noteLower.includes("recharge code") || 
        noteLower.includes("code")
      );
    }
    if (tab === "Admin") {
      return (
        titleLower.includes("admin") || 
        noteLower.includes("admin") || 
        titleLower.includes("adjustment") || 
        noteLower.includes("adjustment") ||
        titleLower.includes("manual") ||
        noteLower.includes("manual") ||
        titleLower.includes("added by") ||
        titleLower.includes("deducted by")
      );
    }
    return true;
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      // 1. Text filter
      const matchesSearch = 
        (t.title || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.note || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.amount || "").toLowerCase().includes(searchQuery.toLowerCase());

      // 2. Tab filter
      const matchesTab = filterTransactions(selectedFilter, t);

      return matchesSearch && matchesTab;
    });
  }, [transactions, selectedFilter, searchQuery]);

  // Assist selecting card background based on filter matches
  const getIconAndStyle = (t: Transaction) => {
    const titleLower = (t.title || "").toLowerCase();
    const noteLower = (t.note || "").toLowerCase();

    const isPrize = titleLower.includes("prize") || titleLower.includes("won") || titleLower.includes("win") || titleLower.includes("victory") || titleLower.includes("tournament") || noteLower.includes("prize") || noteLower.includes("winner");
    const isAdmin = titleLower.includes("admin") || titleLower.includes("adjustment") || titleLower.includes("manual") || titleLower.includes("added by") || titleLower.includes("deducted by");
    const isDeposit = t.type === "deposit" || titleLower.includes("deposit");
    const isWithdraw = t.type === "withdraw" || titleLower.includes("withdraw") || titleLower.includes("cashout");
    const isGift = titleLower.includes("gift") || noteLower.includes("gift");
    const isGiveaway = titleLower.includes("giveaway") || titleLower.includes("code");

    if (isPrize) {
      return {
        icon: <Trophy className="h-5 w-5 text-amber-400" />,
        style: "bg-amber-500/10 text-amber-400 border border-amber-500/15"
      };
    }
    if (isAdmin) {
      return {
        icon: <Zap className="h-5 w-5 text-blue-400" />,
        style: "bg-blue-500/10 text-blue-400 border border-blue-500/15"
      };
    }
    if (isDeposit) {
      return {
        icon: <ArrowUpRight className="h-5 w-5" />,
        style: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/15"
      };
    }
    if (isWithdraw) {
      return {
        icon: <ArrowDownRight className="h-5 w-5" />,
        style: "bg-rose-500/10 text-rose-400 border border-rose-500/15"
      };
    }
    if (isGift) {
      return {
        icon: <Gift className="h-5 w-5 text-purple-400" />,
        style: "bg-purple-500/10 text-purple-400 border border-purple-500/15"
      };
    }
    if (isGiveaway) {
      return {
        icon: <Sparkles className="h-5 w-5 text-indigo-400" />,
        style: "bg-indigo-500/10 text-indigo-400 border border-indigo-500/15"
      };
    }
    return {
      icon: <Gamepad2 className="h-5 w-5 text-slate-400" />,
      style: "bg-slate-500/10 text-slate-400 border border-slate-500/15"
    };
  };

  return (
    <div className="w-full pb-32 bg-[#0a0d14] min-h-screen">
      {/* Sticky Header */}
      <div className="sticky top-0 z-30 bg-[#0e1015]/95 backdrop-blur-md px-4 py-4 flex items-center gap-4.5 border-b border-[#21242c]/55 shadow-md">
        <button 
          onClick={onBack}
          className="h-10 w-10 flex items-center justify-center rounded-full bg-[#161a26]/80 hover:bg-[#1f2536] text-white active:scale-95 transition-all cursor-pointer border border-[#242835]/40"
        >
          <ArrowLeft className="h-5 w-5 stroke-[2.5]" />
        </button>
        <div>
          <h2 className="text-[#f1f5f9] text-base font-black tracking-wide">All Transactions</h2>
          <span className="text-[10px] text-slate-400 font-extrabold tracking-wider uppercase">STATEMENT ENGINE</span>
        </div>
      </div>

      {/* Horizontal scrolling filter list exactly as requested */}
      <div className="mt-4 px-4">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none snap-x mask-fade-right">
          {filters.map((filter) => {
            const isActive = selectedFilter === filter;
            return (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`flex-shrink-0 snap-align-none px-[18px] py-2.5 rounded-full text-xs font-bold transition-all duration-150 cursor-pointer ${
                  isActive
                    ? "bg-[#2d82fe] text-white hover:bg-[#3d8efe] border border-blue-600/30 shadow-md shadow-blue-500/10 scale-102"
                    : "bg-[#141722] text-slate-400 hover:text-slate-200 border border-[#242835]/40 hover:border-[#2f354a] active:scale-97"
                }`}
              >
                {filter}
              </button>
            );
          })}
        </div>
      </div>

      {/* Search Bar filter */}
      <div className="mt-3 px-4">
        <div className="relative w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search transactions by reference..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#121622]/80 text-[#f1f5f9] border border-[#242835]/65 rounded-xl pl-10 pr-4 py-3 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all placeholder:text-slate-500 font-sans"
          />
        </div>
      </div>

      {/* Transaction Feed */}
      <div className="mt-4 px-4 space-y-2.5">
        <div className="flex justify-between items-center px-1 mb-2">
          <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">
            {selectedFilter} History
          </span>
          <span className="text-[10px] text-blue-400 font-black tracking-wide font-mono bg-blue-500/10 border border-blue-500/15 rounded-md px-2 py-0.5 shadow-sm">
            {filteredTransactions.length} items
          </span>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="bg-[#121622] rounded-2xl border border-[#242835]/40 p-12 text-center text-slate-400 text-xs shadow-inner">
            No transaction logs found matching current filter context.
          </div>
        ) : (
          filteredTransactions.map((t) => {
            const isProfit = t.amount.startsWith("+") || parseFloat(t.amount) > 0;
            const config = getIconAndStyle(t);

            return (
              <div
                key={t.id}
                className="bg-[#121622] rounded-xl border border-[#242835]/45 p-4 flex items-center justify-between shadow-sm hover:border-[#2d3248] transition-all"
              >
                <div className="flex items-center gap-3">
                  {/* Icon Box */}
                  <div className={`h-9.5 w-9.5 rounded-xl flex items-center justify-center ${config.style}`}>
                    {config.icon}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-white truncate max-w-[170px] leading-tight">
                      {t.title}
                    </h4>
                    {t.note && (
                      <p className="text-[10px] text-[#2d82fe] font-semibold mt-0.5 leading-tight">
                        Ref: {t.note}
                      </p>
                    )}
                    <p className="text-[9px] text-slate-400 font-mono mt-1">{t.date}</p>
                  </div>
                </div>

                <div className="text-right flex flex-col items-end gap-1.5">
                  <span
                    className={`text-xs font-extrabold block leading-none font-sans ${
                      isProfit ? "text-emerald-400" : "text-rose-400"
                    }`}
                  >
                    {t.amount?.startsWith("+") || t.amount?.startsWith("-") ? t.amount : `${isProfit ? "+" : "-"}৳${t.amount}`}
                  </span>
                  <span
                    className={`text-[8.5px] px-2 py-0.5 rounded-md font-black tracking-wide uppercase leading-none border ${
                      t.status === "success"
                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                        : t.status === "pending"
                        ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                        : "bg-rose-500/10 text-rose-400 border-rose-500/25"
                    }`}
                  >
                    {t.status}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
