import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Mail, 
  Phone, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowLeft, 
  MessageSquareX, 
  Wallet,
  HelpCircle
} from 'lucide-react';

interface AuthViewProps {
  onLogin: (email: string, pass: string) => void;
  onRegister: (name: string, email: string, phone: string, pass: string) => void;
  onToast: (msg: string) => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ onLogin, onRegister, onToast }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Form State
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      onLogin(email, password);
    } else {
      if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
      }
      onRegister(fullName, email, phone, password);
    }
  };

  return (
    <div className="min-h-screen bg-[#07080a] flex flex-col text-slate-200 font-sans">
      <AnimatePresence mode="wait">
        {isLogin ? (
          <motion.div
            key="login"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex-1 flex flex-col px-8 py-12"
          >
            {/* Logo Section */}
            <div className="flex justify-center mb-12">
              <div className="relative">
                <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full scale-150" />
                <div className="relative w-32 h-32 rounded-full border-4 border-[#1e293b] flex items-center justify-center overflow-hidden bg-[#0e1117] shadow-2xl">
                  {/* Mock Logo Background */}
                  <img 
                    src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=200" 
                    alt="Logo" 
                    className="w-full h-full object-cover opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end justify-center pb-4">
                    <div className="flex flex-col items-center">
                      <span className="text-[12px] font-black text-white tracking-widest uppercase">Let's Play</span>
                      <span className="text-[7px] font-bold text-blue-400 uppercase tracking-tighter">Premium Gaming</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center mb-10">
              <h1 className="text-4xl font-display font-black text-white mb-2 tracking-tight">Welcome Back</h1>
              <p className="text-slate-400 font-medium">Sign in to your account</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Email</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail size={18} className="text-slate-500" />
                  </div>
                  <input
                    type="email"
                    required
                    placeholder="Enter Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-4 text-white placeholder-slate-600 transition-all outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock size={18} className="text-slate-500" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="Enter Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-12 text-white placeholder-slate-600 transition-all outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                <div className="flex justify-end">
                  <button type="button" className="text-xs font-bold text-[#2d82fe] hover:underline">
                    Forgot Password?
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#2d82fe] hover:bg-blue-600 text-white font-black py-4 rounded-2xl shadow-lg shadow-blue-900/20 active:scale-95 transition-all mt-4"
              >
                Log In
              </button>
            </form>

            <div className="mt-auto pt-8 text-center space-y-8">
              <p className="text-sm">
                Don't have an account?{' '}
                <button 
                  onClick={() => setIsLogin(false)} 
                  className="text-[#2d82fe] font-black hover:underline"
                >
                  Create Account
                </button>
              </p>
              
              <div className="flex items-center justify-center gap-2 text-slate-500 group cursor-pointer">
                <HelpCircle size={16} />
                <span className="text-xs font-bold uppercase tracking-widest group-hover:text-slate-300 transition-colors">Need Help?</span>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="register"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col px-8 py-8"
          >
            <button 
              onClick={() => setIsLogin(true)}
              className="w-10 h-10 rounded-full border border-slate-800 flex items-center justify-center text-white mb-8 active:scale-90"
            >
              <ArrowLeft size={20} />
            </button>

            <div className="text-center mb-8">
              <h1 className="text-4xl font-display font-black text-white mb-2 tracking-tight">Create Account</h1>
              <p className="text-slate-400 font-medium">Join the tournament today</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5 overflow-y-auto max-h-[60vh] pr-1 custom-scrollbar">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Full Name</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <User size={18} className="text-slate-500" />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="Enter Full Name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-4 text-white placeholder-slate-600 transition-all outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Email</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail size={18} className="text-slate-500" />
                  </div>
                  <input
                    type="email"
                    required
                    placeholder="Enter Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-4 text-white placeholder-slate-600 transition-all outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Phone Number</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Phone size={18} className="text-slate-500" />
                  </div>
                  <input
                    type="tel"
                    required
                    placeholder="Enter Phone Number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-4 text-white placeholder-slate-600 transition-all outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock size={18} className="text-slate-500" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="Enter Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-12 text-white placeholder-slate-600 transition-all outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-500"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">Confirm Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock size={18} className="text-slate-500" />
                  </div>
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    required
                    placeholder="Enter Confirm Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full bg-[#13161c] border border-slate-800 focus:border-[#2d82fe] rounded-2xl py-4 pl-12 pr-12 text-white placeholder-slate-600 transition-all outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-500"
                  >
                    {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
            </form>

            <div className="mt-8">
              <button
                type="submit"
                onClick={handleSubmit}
                className="w-full bg-[#2d82fe] hover:bg-blue-600 text-white font-black py-4 rounded-2xl shadow-lg shadow-blue-900/20 active:scale-95 transition-all"
              >
                Create Account
              </button>
              
              <p className="text-center text-sm mt-6">
                Already have an account?{' '}
                <button 
                  onClick={() => setIsLogin(true)} 
                  className="text-[#2d82fe] font-black hover:underline"
                >
                  Log In
                </button>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 2px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #1e293b;
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};
