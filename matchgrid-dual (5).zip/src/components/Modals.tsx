import React, { useState } from "react";
import { X, User, Phone, Edit, ArrowRight, ShieldAlert, Headphones, Scroll, Landmark, Coins, AlertOctagon, CheckCircle2, ArrowLeft, Copy, Check, Banknote, QrCode, AlertTriangle, Trophy, Users, Info } from "lucide-react";
import { Match, UserData } from "../types";

// BKash/Nagad logo mappings or generic styles
interface ModalsProps {
  // Notice / Announcement
  showNotice: boolean;
  noticeText: string;
  onCloseNotice: () => void;

  // Notifications
  showNotifModal: boolean;
  onCloseNotifModal: () => void;
  notifList: any[];

  // Edit Profile
  showEditModal: boolean;
  onCloseEditModal: () => void;
  userData: UserData | null;
  onSaveProfile: (appName: string, gameName: string, gameUid: string, avatarUrl?: string) => void;

  // Settings
  showSettingsModal: boolean;
  onCloseSettingsModal: () => void;
  onSavePaymentSettings: (methodNumber: string, name: string) => void;

  // Join Match
  activeJoinMatch: Match | null;
  onCloseJoinMatch: () => void;
  userDataBalance: number;
  onConfirmJoinMatch: (gameName: string, gameUid: string) => void;

  // Details Modals
  showRoomModal: boolean;
  onCloseRoomModal: () => void;
  showPrizeModal: boolean;
  onClosePrizeModal: () => void;
  showSlotsModal: boolean;
  onCloseSlotsModal: () => void;
  showRulesModal: boolean;
  onCloseRulesModal: () => void;
  selectedMatchForDetails: Match | null;
  participants: any[];

  // Deposit
  showDepositModal: boolean;
  onCloseDepositModal: () => void;
  adminBkashPhone: string;
  appConfig?: any;
  onDeposit: (amount: string, trxId: string) => void;

  // Withdraw
  showWithdrawModal: boolean;
  onCloseWithdrawModal: () => void;
  onWithdraw: (amount: string, walletNumber: string, selectMethod: string) => void;

  // Transfer
  showTransferModal: boolean;
  onCloseTransferModal: () => void;
  onVerifyReceiver: (uid: string) => Promise<{ appName?: string; verified: boolean; recipientUid?: string }>;
  onTransfer: (uid: string, amount: number, note: string, pass: string) => void;

  // Auth
  showAuthModal: boolean;
  onCloseAuthModal: () => void;
  onLogin: (email: string, pass: string) => void;
  onRegister: (name: string, email: string, phone: string, pass: string) => void;

  onToast: (msg: string) => void;
}

export const Modals: React.FC<ModalsProps> = ({
  showNotice,
  noticeText,
  onCloseNotice,
  showNotifModal,
  onCloseNotifModal,
  notifList,
  showRulesModal,
  onCloseRulesModal,
  showEditModal,
  onCloseEditModal,
  userData,
  onSaveProfile,
  showSettingsModal,
  onCloseSettingsModal,
  onSavePaymentSettings,
  activeJoinMatch,
  onCloseJoinMatch,
  userDataBalance,
  onConfirmJoinMatch,
  showRoomModal,
  onCloseRoomModal,
  showPrizeModal,
  onClosePrizeModal,
  showSlotsModal,
  onCloseSlotsModal,
  selectedMatchForDetails,
  participants,
  showDepositModal,
  onCloseDepositModal,
  adminBkashPhone,
  appConfig,
  onDeposit,
  showWithdrawModal,
  onCloseWithdrawModal,
  onWithdraw,
  showTransferModal,
  onCloseTransferModal,
  onVerifyReceiver,
  onTransfer,
  showAuthModal,
  onCloseAuthModal,
  onLogin,
  onRegister,
  onToast,
}) => {
  // Modal states
  const [profileName, setProfileName] = useState(userData?.appName || "");
  const [profileGameName, setProfileGameName] = useState(userData?.gameName || "");
  const [profileGameUid, setProfileGameUid] = useState(userData?.gameUid || "");
  const [profileAvatar, setProfileAvatar] = useState(userData?.photoUrl || "");

  const [settingsNumber, setSettingsNumber] = useState(userData?.paymentMethod || "");
  const [settingsName, setSettingsName] = useState(userData?.paymentName || "");

  // Join match state
  const [joinGameName, setJoinGameName] = useState(userData?.gameName || "");
  const [joinGameUid, setJoinGameUid] = useState(userData?.gameUid || "");
  const [joinAgreed, setJoinAgreed] = useState(false);
  const [joinPlayer2Name, setJoinPlayer2Name] = useState("");
  const [joinPlayer3Name, setJoinPlayer3Name] = useState("");
  const [joinPlayer4Name, setJoinPlayer4Name] = useState("");
  const [isJoining, setIsJoining] = useState(false);

  React.useEffect(() => {
    if (!activeJoinMatch) {
      setJoinPlayer2Name("");
      setJoinPlayer3Name("");
      setJoinPlayer4Name("");
      setIsJoining(false);
    }
  }, [activeJoinMatch]);

  // Deposit state
  const [depAmount, setDepAmount] = useState("");
  const [depTrx, setDepTrx] = useState("");
  const [depMethod, setDepMethod] = useState<"bkash" | "nagad" | "rocket">("bkash");
  const [copiedPhone, setCopiedPhone] = useState(false);

  // Withdraw state
  const [drawAmount, setDrawAmount] = useState("");
  const [drawNum, setDrawNum] = useState("");
  const [drawMethod, setDrawMethod] = useState("bKash");

  // Transfer state
  const [transUid, setTransUid] = useState("");
  const [resolvedUid, setResolvedUid] = useState("");
  const [transAmount, setTransAmount] = useState("");
  const [transNote, setTransNote] = useState("");
  const [transPass, setTransPass] = useState("");
  const [receiverVerified, setReceiverVerified] = useState(false);
  const [receiverName, setReceiverName] = useState("");
  const [verifyingReceiver, setVerifyingReceiver] = useState(false);

  // Auth forms
  const [authFormType, setAuthFormType] = useState<"login" | "register">("login");
  const [authEmail, setAuthEmail] = useState("");
  const [authPass, setAuthPass] = useState("");
  const [authName, setAuthName] = useState("");
  const [authPhone, setAuthPhone] = useState("");

  // Clean updates when user details mount
  React.useEffect(() => {
    if (userData) {
      setProfileName(userData.appName || "");
      setProfileGameName(userData.gameName || "");
      setProfileGameUid(userData.gameUid || "");
      setProfileAvatar(userData.photoUrl || "");
      setSettingsNumber(userData.paymentMethod || "");
      setSettingsName(userData.paymentName || "");
      setJoinGameName(userData.gameName || "");
      setJoinGameUid(userData.gameUid || "");
    }
  }, [userData]);

  const handleVerifyUid = async (appUid: string) => {
    setTransUid(appUid);
    if (appUid.length < 4) {
      setReceiverVerified(false);
      setReceiverName("");
      setResolvedUid("");
      return;
    }
    setVerifyingReceiver(true);
    const res = await onVerifyReceiver(appUid);
    setVerifyingReceiver(false);
    if (res.verified && res.recipientUid) {
      setReceiverVerified(true);
      setReceiverName(res.appName || "User");
      setResolvedUid(res.recipientUid);
    } else {
      setReceiverVerified(false);
      setReceiverName("");
      setResolvedUid("");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    onToast("Copied to clipboard!");
  };

  return (
    <>
      {/* 1. Announcement Popup (Centered, no border) */}
      {showNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-xs" onClick={onCloseNotice} />
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl relative z-10 border-0 flex flex-col items-center">
            <div className="h-16 w-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mb-4">
              <Coins className="h-8 w-8 text-indigo-600" />
            </div>
            <h3 className="text-base font-black text-slate-800 tracking-tight leading-none mb-2">
              Official Announcement
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed max-w-[280px] mb-6">
              {noticeText || "Welcome to Ꭷɴᴇㅤꜰʟᴇx.!TUR! Join daily custom matches, show your skill, and win real cash rewards instantly."}
            </p>
            <button
              onClick={onCloseNotice}
              className="w-full bg-slate-900 border-0 hover:bg-slate-800 text-white font-extrabold text-xs py-3 rounded-full cursor-pointer transition shadow-md shadow-slate-900/10"
            >
              Okay, Got it
            </button>
          </div>
        </div>
      )}

      {/* 2. Notifications Modal (Slide-up Sheet) */}
      {showNotifModal && (
        <div className="fixed inset-0 z-50 flex items-end">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-xs" onClick={onCloseNotifModal} />
          <div className="bg-white w-full rounded-t-3xl max-h-[85vh] overflow-y-auto p-5 relative z-10 animate-slide-up pb-10">
            <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-4" />
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-4 bg-white sticky top-0">
              <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">
                Notifications
              </h3>
              <button onClick={onCloseNotifModal} className="p-1.5 bg-slate-100 rounded-full cursor-pointer">
                <X className="h-4 w-4 text-slate-500" />
              </button>
            </div>
            <div className="space-y-3">
              {notifList.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs font-bold">
                  All caught up! No recent notifications.
                </div>
              ) : (
                notifList.map((item) => (
                  <div key={item.id} className="bg-slate-50/50 border border-slate-100 rounded-xl p-3.5 relative pl-4">
                    <span className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-600 rounded-l" />
                    <h4 className="text-xs font-bold text-slate-800 leading-tight">{item.title}</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{item.message}</p>
                    <span className="block text-[8px] text-slate-400 text-right mt-2 font-mono">{item.date}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. Fair Play Rules Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onCloseRulesModal} />
          <div className="bg-[#121622] border-t border-[#242835]/70 w-full max-w-md rounded-t-3xl max-h-[85vh] overflow-y-auto p-6 relative z-10 animate-slide-up pb-10 text-slate-100 shadow-2xl">
            <div className="w-12 h-1 bg-[#242835] rounded-full mx-auto mb-4" />
            <div className="flex justify-between items-center pb-4 border-b border-[#242835]/40 mb-5 bg-[#121622] sticky top-0 z-20">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                মিলেমিশে খেলার শর্তাবলী
              </h3>
              <button 
                onClick={onCloseRulesModal} 
                className="p-1.5 bg-[#1f2335]/80 hover:bg-[#2c324a] text-slate-400 hover:text-white rounded-full transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="bg-[#141722] border border-[#242835] rounded-2xl p-5 mb-6 text-[13px] text-slate-300 space-y-4 leading-relaxed font-medium">
              <p className="font-black text-blue-400 uppercase tracking-wider text-[11px]">
                অ্যাকাউন্ট সাসপেনশন এড়াতে দয়া করে নিয়মগুলো মেনে চলুন:
              </p>
              <div className="space-y-3">
                {[
                  "কোন প্রকার এমুলেটর (Emulator) ব্যবহার করা যাবে না। শুধুমাত্র মোবাইল প্লেয়াররাই অংশ নিতে পারবেন।",
                  "গেমের মধ্যে হ্যাক, থার্ড-পার্টি স্ক্রিপ্ট মডিফায়ার অথবা টিম-আপ করা সম্পূর্ণ নিষিদ্ধ।",
                  "টুর্নামেন্টে অংশ নিতে হলে প্লেয়ারের ফ্রি ফায়ার আইডির লেভেল নূন্যতম ২৫ বা তার বেশি হতে হবে।",
                  "ম্যাচ শুরু হওয়ার ঠিক ৫ থেকে ১০ মিনিট আগে কাস্টম রুমে জয়েন করতে হবে।",
                  "বিজয়ীদের অবশ্যই বিজয়ের একটি সম্পূর্ণ স্ক্রিনশট গ্রুপ বা সাপোর্টে জমা দিতে হবে।"
                ].map((rule, idx) => (
                  <div key={idx} className="flex gap-3">
                    <span className="h-5 w-5 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-[10px] font-black text-indigo-400 shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <p>{rule}</p>
                  </div>
                ))}
              </div>
            </div>
            <button
              onClick={onCloseRulesModal}
              className="w-full py-4 bg-slate-100 hover:bg-white text-slate-900 font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-xl active:scale-95"
            >
              আমি নিয়মগুলো পড়েছি এবং সম্মত আছি
            </button>
          </div>
        </div>
      )}

      {/* 4. Edit Profile Modal (Beautifully Custom Dark & Premium style) */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onCloseEditModal} />
          <div className="bg-[#121622] border-t border-[#242835]/70 w-full max-w-md rounded-t-3xl max-h-[85vh] overflow-y-auto p-6 relative z-10 animate-slide-up pb-10 text-slate-100 shadow-2xl">
            <div className="w-12 h-1 bg-[#242835] rounded-full mx-auto mb-4" />
            <div className="flex justify-between items-center pb-4 border-b border-[#242835]/40 mb-5 bg-[#121622] sticky top-0 z-20">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Edit App Profile
              </h3>
              <button 
                onClick={onCloseEditModal} 
                className="p-1.5 bg-[#1f2335]/80 hover:bg-[#2c324a] text-slate-400 hover:text-white rounded-full transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-5">
              <div>
                <label className="text-[10px] text-slate-450 font-black uppercase tracking-wider block mb-1.5">
                  App Nickname
                </label>
                <div className="relative flex items-center">
                  <span className="absolute left-3.5 text-slate-450 z-10">
                    <User className="h-4 w-4" />
                  </span>
                  <input
                    type="text"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    placeholder="App Username"
                    className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl pl-11 pr-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all font-sans"
                  />
                </div>
              </div>

              <div className="border-t border-[#242835]/30 pt-5">
                <h5 className="text-[11.5px] font-black text-blue-400 uppercase tracking-wider mb-4">
                  In-Game Profiles
                </h5>
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] text-slate-450 font-black uppercase tracking-wider block mb-1.5">
                      Exact In-Game Name
                    </label>
                    <div className="relative flex items-center">
                      <span className="absolute left-3.5 text-slate-450 z-10">
                        <Edit className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        value={profileGameName}
                        onChange={(e) => setProfileGameName(e.target.value)}
                        placeholder="e.g. YT_ANKON_FF"
                        className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl pl-11 pr-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-450 font-black uppercase tracking-wider block mb-1.5">
                      Free Fire Player ID (UID)
                    </label>
                    <div className="relative flex items-center">
                      <span className="absolute left-3.5 text-slate-450 z-10">
                        <Phone className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        value={profileGameUid}
                        onChange={(e) => setProfileGameUid(e.target.value)}
                        placeholder="e.g. 524716893"
                        className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl pl-11 pr-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => onSaveProfile(profileName, profileGameName, profileGameUid, profileAvatar)}
                  className="w-full py-4 bg-[#3b82f6] hover:bg-blue-600 border-0 text-white font-black text-xs uppercase tracking-wider rounded-2xl cursor-pointer shadow-lg active:scale-[0.99] transition-all"
                >
                  Save Profile Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Payments / Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-end">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-xs" onClick={onCloseEditModal} />
          <div className="bg-white w-full rounded-t-3xl max-h-[85vh] overflow-y-auto p-5 relative z-10 animate-slide-up pb-10">
            <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-4" />
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-5 bg-white sticky top-0">
              <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">
                Withdrawal Profiles
              </h3>
              <button onClick={onCloseSettingsModal} className="p-1.5 bg-slate-100 rounded-full cursor-pointer">
                <X className="h-4 w-4 text-slate-500" />
              </button>
            </div>
            <div className="space-y-4">
              <p className="text-[11px] text-slate-400 bg-amber-500/5 border border-amber-500/10 p-3 rounded-lg leading-relaxed font-medium">
                Saves default withdrawal accounts below for streamlined bKash/Nagad cashouts.
              </p>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1.5">
                  Default Wallet Number
                </label>
                <input
                  type="number"
                  value={settingsNumber}
                  onChange={(e) => setSettingsNumber(e.target.value)}
                  placeholder="bKash or Nagad number"
                  className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-3 text-xs font-semibold focus:outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1.5">
                  Account Holder Name
                </label>
                <input
                  type="text"
                  value={settingsName}
                  onChange={(e) => setSettingsName(e.target.value)}
                  placeholder="e.g. Adnan Rahman"
                  className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-3 text-xs font-semibold focus:outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>

              <button
                onClick={() => onSavePaymentSettings(settingsNumber, settingsName)}
                className="w-full mt-2 py-3 bg-indigo-600 hover:bg-slate-900 border-0 text-white font-extrabold text-xs rounded-xl cursor-pointer"
              >
                Save Payment Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Join Match Confirmation Modal */}
      {activeJoinMatch && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-0 sm:p-4 animate-fade-in font-sans">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onCloseJoinMatch} />
          <div className="bg-[#0b0c10] w-full sm:max-w-md rounded-t-[32px] sm:rounded-3xl max-h-[92vh] overflow-y-auto p-5 relative z-10 animate-slide-up pb-10 border border-slate-800/80 text-slate-100">
            {/* Header / Action Bar matching screenshot */}
            <div className="relative flex items-center justify-center pb-5 mb-5 border-b border-slate-800/50 sticky top-0 bg-[#0b0c10]/95 backdrop-blur-md z-1">
              <button 
                onClick={onCloseJoinMatch} 
                className="absolute left-0 p-2 text-slate-300 hover:text-white rounded-full bg-slate-900/40 cursor-pointer active:scale-95 transition-all"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <h3 className="text-[17px] font-black text-white text-center leading-none">
                Join Match
              </h3>
            </div>

            <div className="space-y-4">
              {/* Available Balance green-accented Card */}
              <div className="bg-[#0f221a] border border-[#10b981]/25 rounded-[18px] p-5 text-center shadow-[0_0_20px_rgba(16,185,129,0.02)]">
                <span className="text-[11.5px] text-[#10b981] font-bold uppercase tracking-wider block mb-1.5">
                  Available Balance
                </span>
                <span className="text-3.5xl font-black text-white block tracking-tight">
                  ৳{userDataBalance}
                </span>
              </div>

              {/* Match details card with divider lines */}
              <div className="bg-[#121620] border border-slate-800/80 rounded-[18px] p-4.5 space-y-3.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold uppercase tracking-wider">Entry Fee (Per Person)</span>
                  <span className="text-[#f59e0b] font-black text-sm">৳{activeJoinMatch.fee}</span>
                </div>
                <div className="border-t border-slate-800/50 my-1"></div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold uppercase tracking-wider">Match Type</span>
                  <span className="text-white font-black">{activeJoinMatch.teamMode || activeJoinMatch.type || "Solo"}</span>
                </div>
                <div className="border-t border-slate-800/50 my-1"></div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold uppercase tracking-wider">Slots Left</span>
                  <span className="text-white font-black">
                    {(activeJoinMatch.total || 48) - (activeJoinMatch.joined || 0)} / {activeJoinMatch.total || 48}
                  </span>
                </div>
              </div>

              {/* Golden dynamic instructions warning banner */}
              <div className="bg-amber-500/5 border border-amber-500/80 rounded-[10px] py-2.5 px-4 text-center">
                <span className="text-[11.5px] text-[#facc15] font-black block tracking-wide">
                  আপনার গেম আইডি এর নাম দিয়ে জয়েন করবেন
                </span>
              </div>

              {/* Game name inputs */}
              {(() => {
                const matchTeamMode = (activeJoinMatch.teamMode || "").toLowerCase();
                const matchType = (activeJoinMatch.type || "").toLowerCase();
                const matchTitle = (activeJoinMatch.title || "").toLowerCase();

                const isDuoMode = matchTeamMode.includes("duo") || matchType.includes("duo") || matchTitle.includes("duo") || matchType === "cs [2v2]";
                const isSquadMode = matchTeamMode.includes("squad") || matchType.includes("squad") || matchTitle.includes("squad") || matchTeamMode.includes("4v4") || matchType.includes("4v4") || matchType.includes("clash squad");

                const isFormValid = (() => {
                  if (isJoining) return false;
                  if (!joinGameName.trim()) return false;
                  if (isDuoMode) {
                    return !!joinPlayer2Name.trim();
                  }
                  if (isSquadMode) {
                    return !!joinPlayer2Name.trim() && !!joinPlayer3Name.trim() && !!joinPlayer4Name.trim();
                  }
                  return true;
                })();

                return (
                  <div className="space-y-4">
                    {/* Input labels header */}
                    <div className="flex items-center gap-1.5 pb-1 text-left">
                      <h4 className="text-[13px] font-black text-slate-300 uppercase tracking-wider">
                        Player Names
                      </h4>
                    </div>

                    {/* Dynamic User inputs */}
                    <div className="space-y-3.5 text-left">
                      <div>
                        <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1.5 tracking-wider">
                          Player 1 Name
                        </label>
                        <div className="relative flex items-center bg-[#0e111a] border border-slate-800 rounded-2xl px-3.5 py-3 focus-within:border-indigo-500 transition-all">
                          <User className="h-4.5 w-4.5 text-slate-400 mr-2.5 flex-shrink-0" />
                          <input
                            type="text"
                            value={joinGameName}
                            onChange={(e) => setJoinGameName(e.target.value)}
                            placeholder="Enter Player 1 Name"
                            className="w-full bg-transparent text-slate-100 text-xs font-semibold focus:outline-none placeholder-slate-600"
                            disabled={isJoining}
                          />
                          <div className="h-5 w-5 rounded bg-slate-900/80 border border-slate-800 flex items-center justify-center font-black text-[9px] text-slate-400 ml-2 select-none">
                            1P
                          </div>
                        </div>
                      </div>

                      {isDuoMode && (
                        <div>
                          <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1.5 tracking-wider animate-pulse">
                            Player 2 Name (DUO) <span className="text-amber-500">*</span>
                          </label>
                          <div className="relative flex items-center bg-[#0e111a] border border-slate-800 rounded-2xl px-3.5 py-3 focus-within:border-indigo-500 transition-all">
                            <User className="h-4.5 w-4.5 text-slate-400 mr-2.5 flex-shrink-0" />
                            <input
                              type="text"
                              value={joinPlayer2Name}
                              onChange={(e) => setJoinPlayer2Name(e.target.value)}
                              placeholder="Enter Player 2 Name"
                              className="w-full bg-transparent text-slate-100 text-xs font-semibold focus:outline-none placeholder-slate-600"
                              disabled={isJoining}
                            />
                            <div className="h-5 w-5 rounded bg-slate-900/80 border border-slate-800 flex items-center justify-center font-black text-[9px] text-slate-400 ml-2 select-none">
                              2P
                            </div>
                          </div>
                        </div>
                      )}

                      {isSquadMode && (
                        <div className="space-y-3.5">
                          <div>
                            <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1.5 tracking-wider animate-pulse">
                              Player 2 Name (SQUAD) <span className="text-amber-500">*</span>
                            </label>
                            <div className="relative flex items-center bg-[#0e111a] border border-slate-800 rounded-2xl px-3.5 py-3 focus-within:border-indigo-500 transition-all">
                              <User className="h-4.5 w-4.5 text-slate-400 mr-2.5 flex-shrink-0" />
                              <input
                                type="text"
                                value={joinPlayer2Name}
                                onChange={(e) => setJoinPlayer2Name(e.target.value)}
                                placeholder="Enter Player 2 Name"
                                className="w-full bg-transparent text-slate-100 text-xs font-semibold focus:outline-none placeholder-slate-600"
                                disabled={isJoining}
                              />
                            </div>
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1.5 tracking-wider animate-pulse">
                              Player 3 Name (SQUAD) <span className="text-amber-500">*</span>
                            </label>
                            <div className="relative flex items-center bg-[#0e111a] border border-slate-800 rounded-2xl px-3.5 py-3 focus-within:border-indigo-500 transition-all">
                              <User className="h-4.5 w-4.5 text-slate-400 mr-2.5 flex-shrink-0" />
                              <input
                                type="text"
                                value={joinPlayer3Name}
                                onChange={(e) => setJoinPlayer3Name(e.target.value)}
                                placeholder="Enter Player 3 Name"
                                className="w-full bg-transparent text-slate-100 text-xs font-semibold focus:outline-none placeholder-slate-600"
                                disabled={isJoining}
                              />
                            </div>
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1.5 tracking-wider animate-pulse">
                              Player 4 Name (SQUAD) <span className="text-amber-500">*</span>
                            </label>
                            <div className="relative flex items-center bg-[#0e111a] border border-slate-800 rounded-2xl px-3.5 py-3 focus-within:border-indigo-500 transition-all">
                              <User className="h-4.5 w-4.5 text-slate-400 mr-2.5 flex-shrink-0" />
                              <input
                                type="text"
                                value={joinPlayer4Name}
                                onChange={(e) => setJoinPlayer4Name(e.target.value)}
                                placeholder="Enter Player 4 Name"
                                className="w-full bg-transparent text-slate-100 text-xs font-semibold focus:outline-none placeholder-slate-600"
                                disabled={isJoining}
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      <div>
                        <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1.5 tracking-wider">
                          Gamer UID (Optional)
                        </label>
                        <div className="relative flex items-center bg-[#0e111a] border border-slate-800 rounded-2xl px-3.5 py-3 focus-within:border-indigo-500 transition-all">
                          <Coins className="h-4.5 w-4.5 text-slate-500 mr-2.5 flex-shrink-0" />
                          <input
                            type="number"
                            value={joinGameUid}
                            onChange={(e) => setJoinGameUid(e.target.value)}
                            placeholder="e.g. 524716893"
                            className="w-full bg-transparent text-slate-100 text-xs font-semibold focus:outline-none placeholder-slate-600 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                            disabled={isJoining}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Agree checkbox designed for dark frame */}
                    <div className="flex items-start gap-2.5 bg-[#0e111a] p-3 rounded-xl border border-slate-800 text-left">
                      <input
                        type="checkbox"
                        id="agree-rules"
                        checked={joinAgreed}
                        onChange={(e) => setJoinAgreed(e.target.checked)}
                        className="mt-0.5 h-4 w-4 bg-[#0e111a] border-slate-800 text-blue-600 rounded focus:ring-blue-500 focus:ring-offset-0 cursor-pointer"
                        disabled={isJoining}
                      />
                      <label htmlFor="agree-rules" className="text-[10.5px] text-slate-400 font-semibold select-none leading-relaxed">
                        আমি ম্যাচ খেলার শর্তাবলী এবং ফেয়ারপ্লে নিয়মকানুনের প্রতি একমত পোষণ করছি। নিয়ম ভঙ্গ করলে রেওয়ার্ড বা পয়েন্ট বাতিল হবে।
                      </label>
                    </div>

                    {/* Complete Confirmation matching screenshot */}
                    <button
                      disabled={isJoining || userDataBalance < activeJoinMatch.fee || !isFormValid}
                      onClick={async () => {
                        if (isJoining) return;
                        setIsJoining(true);
                        try {
                          const finalName = isDuoMode
                            ? `${joinGameName.trim()}, ${joinPlayer2Name.trim()}`
                            : isSquadMode
                            ? `${joinGameName.trim()}, ${joinPlayer2Name.trim()}, ${joinPlayer3Name.trim()}, ${joinPlayer4Name.trim()}`
                            : joinGameName.trim();
                          await onConfirmJoinMatch(finalName, joinGameUid);
                        } catch (e) {
                          onToast("ম্যাচে জয়েন করতে ব্যর্থ হয়েছে। পুনরায় চেষ্টা করুন।");
                        } finally {
                          setIsJoining(false);
                        }
                      }}
                      className={`w-full py-3.5 text-[14px] font-black rounded-xl transition cursor-pointer select-none tracking-wide ${
                        !isJoining && userDataBalance >= activeJoinMatch.fee && isFormValid
                          ? "bg-blue-600 hover:bg-blue-700 text-white shadow-xl shadow-blue-500/25 active:scale-98"
                          : "bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700/50"
                      }`}
                    >
                      {isJoining ? "Joining instantly..." : `Pay ৳${activeJoinMatch.fee} & Join`}
                    </button>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* 7. Deposit Modal (Beautifully Custom Dark & Premium style) */}
      {showDepositModal && (() => {
        const activeNumber = (() => {
          if (depMethod === "bkash") return appConfig?.bkashPhone || adminBkashPhone || "01627762093";
          if (depMethod === "nagad") return appConfig?.nagadPhone || adminBkashPhone || "01627762093";
          if (depMethod === "rocket") return appConfig?.rocketPhone || adminBkashPhone || "01627762093";
          return adminBkashPhone || "01627762093";
        })();

        const handleCopyNumber = () => {
          copyToClipboard(activeNumber);
          setCopiedPhone(true);
          setTimeout(() => setCopiedPhone(false), 2000);
        };

        const methodLabel = depMethod === "bkash" ? "bKash" : depMethod === "nagad" ? "Nagad" : "Rocket";

        return (
          <div className="fixed inset-0 z-50 flex items-end justify-center">
            <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={onCloseDepositModal} />
            <div className="bg-[#10141e] border-t border-[#1a2030] w-full max-w-md rounded-t-[2.5rem] max-h-[92vh] overflow-y-auto relative z-10 animate-slide-up pb-8 text-slate-100 shadow-2xl">
              
              {/* App status drag bar indicator */}
              <div className="w-12 h-1.5 bg-[#20283c] rounded-full mx-auto my-3" />
              
              {/* Top sticky app header */}
              <div className="flex items-center px-6 pb-4 border-b border-[#20283c]/50 mb-4 bg-[#10141e] sticky top-0 z-20">
                <button 
                  onClick={onCloseDepositModal}
                  className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer mr-2"
                >
                  <ArrowLeft className="h-6 w-6" />
                </button>
                <div className="flex-1 text-center">
                  <h3 className="text-xl font-bold tracking-tight text-white pr-8">
                    Deposit Money
                  </h3>
                </div>
              </div>

              <div className="px-6 space-y-5">
                {/* 1. SELECT PAYMENT METHOD */}
                <div className="space-y-2">
                  <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Select Payment Method
                  </span>
                  
                  <div className="grid grid-cols-3 gap-3">
                    {/* bKash Selection */}
                    <button
                      onClick={() => {
                        setDepMethod("bkash");
                        setCopiedPhone(false);
                      }}
                      className={`relative flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                        depMethod === "bkash" 
                          ? "bg-[#e2136e]/5 border-[#e2136e]" 
                          : "bg-[#161c2c] border-[#222b40]/50 hover:border-slate-700"
                      }`}
                    >
                      {/* Stylized high contrast bKash logo */}
                      <div className="w-14 h-9 flex items-center justify-center rounded-lg bg-[#e2136e] shadow-md">
                        <span className="text-white font-extrabold text-[13px] tracking-tight uppercase">bKash</span>
                      </div>
                      {depMethod === "bkash" && (
                        <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#e2136e] rounded-full flex items-center justify-center">
                          <Check className="h-2 w-2 text-white stroke-[4]" />
                        </div>
                      )}
                    </button>

                    {/* Nagad Selection */}
                    <button
                      onClick={() => {
                        setDepMethod("nagad");
                        setCopiedPhone(false);
                      }}
                      className={`relative flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                        depMethod === "nagad" 
                          ? "bg-[#f7931a]/5 border-[#f7931a]" 
                          : "bg-[#161c2c] border-[#222b40]/50 hover:border-slate-700"
                      }`}
                    >
                      {/* Stylized high contrast Nagad logo */}
                      <div className="w-14 h-9 flex items-center justify-center rounded-lg bg-gradient-to-br from-[#f7931a] to-[#ff4e00] shadow-md">
                        <span className="text-white font-black text-[13px] tracking-tighter">নগদ</span>
                      </div>
                      {depMethod === "nagad" && (
                        <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#f7931a] rounded-full flex items-center justify-center">
                          <Check className="h-2 w-2 text-white stroke-[4]" />
                        </div>
                      )}
                    </button>

                    {/* Rocket Selection */}
                    <button
                      onClick={() => {
                        setDepMethod("rocket");
                        setCopiedPhone(false);
                      }}
                      className={`relative flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                        depMethod === "rocket" 
                          ? "bg-[#8c2394]/5 border-[#8c2394]" 
                          : "bg-[#161c2c] border-[#222b40]/50 hover:border-slate-700"
                      }`}
                    >
                      {/* Stylized high contrast Rocket logo */}
                      <div className="w-14 h-9 flex items-center justify-center rounded-lg bg-[#8c2394] shadow-md">
                        <span className="text-white font-[#inter] font-extrabold text-[11px] tracking-tighter uppercase">Rocket</span>
                      </div>
                      {depMethod === "rocket" && (
                        <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#8c2394] rounded-full flex items-center justify-center">
                          <Check className="h-2 w-2 text-white stroke-[4]" />
                        </div>
                      )}
                    </button>
                  </div>
                </div>

                {/* 2. SEND MONEY TO BOX */}
                <div className="bg-[#161c2c] border border-[#222b40]/80 p-4 rounded-3xl flex justify-between items-center relative overflow-hidden shadow-lg group">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl" />
                  <div>
                    <span className="text-[10px] text-slate-400 font-extrabold block tracking-wide uppercase">Send Money To</span>
                    <span className="text-amber-500 font-mono font-black text-2xl mt-1.5 block tracking-wide select-all">
                      {activeNumber}
                    </span>
                  </div>
                  
                  <button
                    onClick={handleCopyNumber}
                    className="p-3 bg-[#20283d] hover:bg-[#2b3552] text-blue-400 hover:text-blue-300 rounded-2xl border-0 cursor-pointer active:scale-95 transition-all relative"
                  >
                    {copiedPhone ? (
                      <span className="text-[10px] font-black text-emerald-400 absolute -top-7 right-0 bg-[#20283d] px-2 py-1 rounded-md shadow-lg border border-emerald-500/20 whitespace-nowrap">Copied!</span>
                    ) : null}
                    <Copy className="h-5 w-5" />
                  </button>
                </div>

                {/* 3. INSTRUCTIONS */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Instructions
                  </span>
                  <div className="bg-[#141926] border border-[#20283a]/70 p-4.5 rounded-3xl text-xs text-slate-300 space-y-2 leading-relaxed">
                    <div className="flex gap-2">
                      <span className="text-amber-500 font-semibold font-mono">1.</span>
                      <span>Dial <b className="text-white font-black">{depMethod === "bkash" ? "*247#" : depMethod === "nagad" ? "*167#" : "*322#"}</b> or open the <b className="text-white">{methodLabel}</b> app.</span>
                    </div>
                    <div className="flex gap-2">
                      <span className="text-amber-500 font-semibold font-mono">2.</span>
                      <span>Choose: <b className="text-white font-extrabold">Send Money</b></span>
                    </div>
                    <div className="flex gap-2 items-center">
                      <span className="text-amber-500 font-semibold font-mono">3.</span>
                      <span className="flex-1">Enter the Number: <b className="text-white font-mono font-bold tracking-wider">{activeNumber}</b></span>
                      <button 
                        onClick={handleCopyNumber}
                        className="p-1 bg-[#20283d] text-slate-400 hover:text-white rounded-md cursor-pointer ml-1"
                      >
                        <Copy className="h-3 w-3" />
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <span className="text-amber-500 font-semibold font-mono">4.</span>
                      <span>Enter the Amount</span>
                    </div>
                    <div className="flex gap-2">
                      <span className="text-amber-500 font-semibold font-mono">5.</span>
                      <span>Now enter your <b className="text-white">{methodLabel} PIN</b> to confirm.</span>
                    </div>
                    <div className="flex gap-2">
                      <span className="text-amber-500 font-semibold font-mono">6.</span>
                      <span>Put the Transaction ID in the box below and press <b className="text-white uppercase">Verify Deposit</b></span>
                    </div>
                  </div>
                </div>

                {/* 4. AMOUNT INPUT */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Amount
                  </label>
                  <div className="relative flex items-center">
                    <span className="absolute left-4 text-slate-400">
                      <Banknote className="h-5 w-5" />
                    </span>
                    <input
                      type="number"
                      value={depAmount}
                      onChange={(e) => {
                        if (parseFloat(e.target.value) >= 0 || e.target.value === "") {
                          setDepAmount(e.target.value);
                        }
                      }}
                      placeholder="Enter Amount"
                      className="w-full bg-[#161c2c] text-white border border-[#222b40] rounded-2xl pl-12 pr-4 py-4 text-sm font-semibold leading-normal focus:outline-none focus:border-blue-500 focus:bg-[#121624] transition-all placeholder-slate-500"
                    />
                  </div>
                </div>

                {/* 5. TRANSACTION ID INPUT */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Transaction ID
                  </label>
                  <div className="relative flex items-center">
                    <span className="absolute left-4 text-slate-400">
                      <QrCode className="h-5 w-5" />
                    </span>
                    <input
                      type="text"
                      value={depTrx}
                      onChange={(e) => setDepTrx(e.target.value)}
                      placeholder="Enter Transaction ID"
                      className="w-full bg-[#161c2c] text-white border border-[#222b40] rounded-2xl pl-12 pr-4 py-4 text-sm font-mono tracking-wider focus:outline-none focus:border-blue-500 focus:bg-[#121624] transition-all placeholder-slate-500"
                    />
                  </div>
                </div>

                {/* ACTION SUBMIT BUTTON */}
                <div className="pt-3">
                  <button
                    disabled={!depAmount || !depTrx}
                    onClick={() => onDeposit(depAmount, depTrx)}
                    className={`w-full py-4 text-sm font-black uppercase tracking-wider rounded-2xl transition-all duration-150 cursor-pointer select-none active:scale-[0.99] shadow-lg ${
                      depAmount && depTrx
                        ? "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/10"
                        : "bg-[#20283c] text-slate-500 cursor-not-allowed border border-[#232d43] shadow-none opacity-40"
                    }`}
                  >
                    Verify Deposit
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 8. Withdraw Modal (Beautifully Custom Dark & Premium style matching screenshot) */}
      {showWithdrawModal && (() => {
        const activeWinBalance = userData?.winBalance ?? 0;

        return (
          <div className="fixed inset-0 z-50 flex items-end justify-center">
            <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={onCloseWithdrawModal} />
            <div className="bg-[#10141e] border-t border-[#1a2030] w-full max-w-md rounded-t-[2.5rem] max-h-[92vh] overflow-y-auto relative z-10 animate-slide-up pb-8 text-slate-100 shadow-2xl">
              
              {/* Drag indicator */}
              <div className="w-12 h-1.5 bg-[#20283c] rounded-full mx-auto my-3" />
              
              {/* Header inside modal */}
              <div className="flex items-center px-6 pb-4 border-b border-[#20283c]/50 mb-4 bg-[#10141e] sticky top-0 z-20">
                <button 
                  onClick={onCloseWithdrawModal}
                  className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer mr-2"
                >
                  <ArrowLeft className="h-6 w-6" />
                </button>
                <div className="flex-1 text-center">
                  <h3 className="text-xl font-bold tracking-tight text-white pr-8">
                    Withdraw Money
                  </h3>
                </div>
              </div>

              <div className="px-6 space-y-5">
                {/* 1. METHOD SELECTOR */}
                <div className="space-y-2">
                  <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Select Method to Receive Money
                  </span>
                  
                  <div className="grid grid-cols-3 gap-3">
                    {/* bKash Wallet */}
                    <button
                      onClick={() => setDrawMethod("bKash")}
                      className={`relative flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                        drawMethod === "bKash" 
                          ? "bg-[#e2136e]/5 border-[#e2136e]" 
                          : "bg-[#161c2c] border-[#222b40]/50 hover:border-slate-700"
                      }`}
                    >
                      <div className="w-14 h-9 flex items-center justify-center rounded-lg bg-[#e2136e] shadow-md">
                        <span className="text-white font-extrabold text-[13px] tracking-tight uppercase">bKash</span>
                      </div>
                      {drawMethod === "bKash" && (
                        <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#e2136e] rounded-full flex items-center justify-center">
                          <Check className="h-2 w-2 text-white stroke-[4]" />
                        </div>
                      )}
                    </button>

                    {/* Nagad Wallet */}
                    <button
                      onClick={() => setDrawMethod("Nagad")}
                      className={`relative flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                        drawMethod === "Nagad" 
                          ? "bg-[#f7931a]/5 border-[#f7931a]" 
                          : "bg-[#161c2c] border-[#222b40]/50 hover:border-slate-700"
                      }`}
                    >
                      <div className="w-14 h-9 flex items-center justify-center rounded-lg bg-gradient-to-br from-[#f7931a] to-[#ff4e00] shadow-md">
                        <span className="text-white font-black text-[13px] tracking-tighter">নগদ</span>
                      </div>
                      {drawMethod === "Nagad" && (
                        <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#f7931a] rounded-full flex items-center justify-center">
                          <Check className="h-2 w-2 text-white stroke-[4]" />
                        </div>
                      )}
                    </button>

                    {/* Rocket Wallet */}
                    <button
                      onClick={() => setDrawMethod("Rocket")}
                      className={`relative flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                        drawMethod === "Rocket" 
                          ? "bg-[#8c2394]/5 border-[#8c2394]" 
                          : "bg-[#161c2c] border-[#222b40]/50 hover:border-slate-700"
                      }`}
                    >
                      <div className="w-14 h-9 flex items-center justify-center rounded-lg bg-[#8c2394] shadow-md">
                        <span className="text-white font-[#inter] font-extrabold text-[11px] tracking-tighter uppercase">Rocket</span>
                      </div>
                      {drawMethod === "Rocket" && (
                        <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#8c2394] rounded-full flex items-center justify-center">
                          <Check className="h-2 w-2 text-white stroke-[4]" />
                        </div>
                      )}
                    </button>
                  </div>
                </div>

                {/* 2. WINNING BALANCE PREMIUM CONTAINER */}
                <div className="bg-[#1b1510] border border-[#d97706]/20 py-4.5 px-6 rounded-3xl text-center relative overflow-hidden shadow-lg">
                  <span className="text-[11px] text-amber-500/80 font-bold uppercase tracking-wide block mb-1">
                    Winning Balance
                  </span>
                  <span className="text-3xl font-black text-amber-500 tracking-tight font-sans block">
                    ৳{activeWinBalance.toFixed(0)}
                  </span>
                </div>

                {/* 3. AMOUNT ENTRY INPUT */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Amount
                  </label>
                  <div className="relative flex items-center">
                    <span className="absolute left-4 text-slate-400">
                      <Banknote className="h-5 w-5" />
                    </span>
                    <input
                      type="number"
                      value={drawAmount}
                      onChange={(e) => {
                        if (parseFloat(e.target.value) >= 0 || e.target.value === "") {
                          setDrawAmount(e.target.value);
                        }
                      }}
                      placeholder="Enter Amount"
                      className="w-full bg-[#161c2c] text-white border border-[#222b40] rounded-2xl pl-12 pr-4 py-4 text-sm font-semibold leading-normal focus:outline-none focus:border-blue-500 focus:bg-[#121624] transition-all placeholder-slate-550"
                    />
                  </div>
                </div>

                {/* 4. ACCOUNT NUMBER ENTRY INPUT */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-400 font-bold uppercase tracking-wide block">
                    Mobile Number
                  </label>
                  <div className="relative flex items-center">
                    <span className="absolute left-4 text-slate-400">
                      <Phone className="h-5 w-5" />
                    </span>
                    <input
                      type="text"
                      value={drawNum}
                      onChange={(e) => setDrawNum(e.target.value)}
                      placeholder="Enter Mobile Number"
                      className="w-full bg-[#161c2c] text-white border border-[#222b40] rounded-2xl pl-12 pr-4 py-4 text-sm font-semibold leading-normal focus:outline-none focus:border-blue-500 focus:bg-[#121624] transition-all placeholder-slate-550"
                    />
                  </div>
                </div>

                {/* SUBMIT ACTION BUTTON TRIGGER */}
                <div className="pt-3">
                  <button
                    disabled={!drawAmount || !drawNum || parseFloat(drawAmount) < 100 || parseFloat(drawAmount) > activeWinBalance}
                    onClick={() => onWithdraw(drawAmount, drawNum, drawMethod)}
                    className={`w-full py-4 text-sm font-black uppercase tracking-wider rounded-2xl transition-all duration-150 cursor-pointer select-none active:scale-[0.99] shadow-lg ${
                      drawAmount && drawNum && parseFloat(drawAmount) >= 100 && parseFloat(drawAmount) <= activeWinBalance
                        ? "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/10"
                        : "bg-[#20283c] text-slate-500 cursor-not-allowed border border-[#232d43] shadow-none opacity-40"
                    }`}
                  >
                    Request Withdraw
                  </button>
                </div>

                {/* STATUS BAR IN BENGALI TEXT FOR OPERATIONAL HOURS */}
                <div className="border border-[#d97706]/35 bg-[#1e1c14] text-center py-3.5 px-4 rounded-2xl text-[12px] font-bold text-amber-400 mt-4 leading-relaxed">
                  উত্তোলনের সময়: সকাল ১০টা থেকে রাত ১২টা পর্যন্ত
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 9. Transfer Modal (Beautifully Custom Dark & Premium style) */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onCloseTransferModal} />
          <div className="bg-[#121622] border-t border-[#242835]/70 w-full max-w-md rounded-t-3xl max-h-[85vh] overflow-y-auto p-6 relative z-10 animate-slide-up pb-10 text-slate-100 shadow-2xl">
            <div className="w-12 h-1 bg-[#242835] rounded-full mx-auto mb-4" />
            <div className="flex justify-between items-center pb-4 border-b border-[#242835]/40 mb-5 bg-[#121622] sticky top-0 z-20">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Instant Transfer Coins
              </h3>
              <button 
                onClick={onCloseTransferModal} 
                className="p-1.5 bg-[#1f2335]/80 hover:bg-[#2c324a] text-slate-400 hover:text-white rounded-full transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-5">
              <div className="bg-[#171c2a] border border-[#242835] rounded-2xl p-4 text-center shadow-inner">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block leading-none tracking-wider">SENDABLE BALANCE</span>
                <span className="text-blue-400 font-black text-xl block mt-2 tracking-tight">৳ {userDataBalance.toFixed(2)}</span>
              </div>

              {/* Trans Inputs */}
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] text-slate-400 font-black uppercase block tracking-wider mb-1.5">
                    Recipient 4-Digit App UID
                  </label>
                  <input
                    type="text"
                    value={transUid}
                    onChange={(e) => handleVerifyUid(e.target.value.trim())}
                    placeholder="Enter friend's 4-digit numeric UID"
                    className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl px-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all font-mono"
                  />
                  <div className="text-[9.5px] font-extrabold mt-1.5 min-h-[14px] px-1 tracking-wide">
                    {verifyingReceiver ? (
                      <span className="text-amber-400 leading-none animate-pulse">Verifying friend 4-digit ID...</span>
                    ) : receiverVerified ? (
                      <span className="text-emerald-400 leading-none">✓ Recipient verified: {receiverName}</span>
                    ) : transUid ? (
                      <span className="text-rose-400 leading-none">✗ No active registered player found under this UID (Min 4 digits)</span>
                    ) : null}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 font-black uppercase block tracking-wider mb-1.5">
                    Transfer Amount (Min 10 Tk)
                  </label>
                  <input
                    type="number"
                    value={transAmount}
                    onChange={(e) => {
                      if (parseFloat(e.target.value) >= 0 || e.target.value === "") {
                        setTransAmount(e.target.value);
                      }
                    }}
                    placeholder="e.g. 50"
                    className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl px-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 font-black uppercase block tracking-wider mb-1.5">
                    Transfer Note (Optional)
                  </label>
                  <input
                    type="text"
                    value={transNote}
                    onChange={(e) => setTransNote(e.target.value)}
                    placeholder="e.g. Gift"
                    className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl px-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500 focus:bg-slate-950 transition-all"
                  />
                </div>

                <div className="border-t border-[#242835]/30 pt-4">
                  <label className="text-[10px] text-slate-400 font-black uppercase block tracking-wider mb-1.5">
                    App Password <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="password"
                    value={transPass}
                    onChange={(e) => setTransPass(e.target.value)}
                    placeholder="App password to authenticate"
                    className="w-full bg-slate-900/60 text-white border border-[#242835] rounded-xl px-4 py-3.5 text-xs font-bold leading-normal focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="pt-4">
                <button
                  disabled={!receiverVerified || !transAmount || parseFloat(transAmount) < 10 || parseFloat(transAmount) > userDataBalance || !transPass}
                  onClick={() => onTransfer(resolvedUid, parseFloat(transAmount), transNote, transPass)}
                  className={`w-full py-4 text-xs font-black uppercase tracking-wider rounded-2xl transition-all duration-150 cursor-pointer select-none active:scale-[0.99] shadow-lg ${
                    receiverVerified && transAmount && parseFloat(transAmount) >= 10 && parseFloat(transAmount) <= userDataBalance && transPass
                      ? "bg-blue-500 text-white hover:bg-blue-600 shadow-blue-500/20"
                      : "bg-[#1f2335] text-slate-500 cursor-not-allowed border border-[#242835]/40 shadow-none opacity-50"
                  }`}
                >
                  Confirm Secure Transfer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 10. Auth Modal (Login / Sign Up) */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-sm animate-fade-in">
          <div className="absolute inset-0" onClick={onCloseAuthModal} />
          <div className="bg-white rounded-3xl p-6 shadow-2xl relative z-15 w-full max-w-sm border-0 animate-slide-up text-center">
            <button
              onClick={onCloseAuthModal}
              className="absolute top-4 right-4 p-1 bg-slate-100 hover:bg-slate-200 rounded-full cursor-pointer text-slate-500"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Logo */}
            <div className="h-14 w-14 bg-gradient-to-tr from-indigo-600 to-rose-500 rounded-2xl flex items-center justify-center text-white text-2xl font-black rotate-[-5deg] mx-auto mb-4 shadow shadow-indigo-600/20">
              🎮
            </div>

            <h2 className="text-xl font-extrabold text-slate-800 tracking-tight leading-none">
              Ꭷɴᴇㅤꜰʟᴇx.!TUR!
            </h2>
            <p className="text-[11px] text-slate-400 font-bold uppercase mt-1 leading-none tracking-wider mb-6">
              {authFormType === "login" ? "Login to account" : "Create gamer handle"}
            </p>

            {authFormType === "login" ? (
              /* LOGIN FORM */
              <div className="space-y-4 text-left">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="Enter email"
                    className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    value={authPass}
                    onChange={(e) => setAuthPass(e.target.value)}
                    placeholder="Enter password"
                    className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-600"
                  />
                </div>

                <button
                  onClick={() => onLogin(authEmail, authPass)}
                  className="w-full py-3 bg-indigo-600 hover:bg-slate-900 border-0 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer transition"
                >
                  Log In
                </button>

                <div className="text-center text-xs text-slate-400 mt-4 leading-none">
                  Don't have an account?{" "}
                  <span
                    onClick={() => setAuthFormType("register")}
                    className="text-indigo-600 font-black cursor-pointer underline"
                  >
                    Sign Up
                  </span>
                </div>
              </div>
            ) : (
              /* REGISTER FORM */
              <div className="space-y-4 text-left">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    placeholder="e.g. Adnan"
                    className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                    Mobile Phone
                  </label>
                  <input
                    type="number"
                    value={authPhone}
                    onChange={(e) => setAuthPhone(e.target.value)}
                    placeholder="e.g. 01700112233"
                    className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="e.g. adnan@gmail.com"
                    className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                    Security Password
                  </label>
                  <input
                    type="password"
                    value={authPass}
                    onChange={(e) => setAuthPass(e.target.value)}
                    placeholder="Password"
                    className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-600"
                  />
                </div>

                <button
                  onClick={() => onRegister(authName, authEmail, authPhone, authPass)}
                  className="w-full py-3 bg-indigo-600 hover:bg-slate-900 border-0 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer transition"
                >
                  Create Account
                </button>

                <div className="text-center text-xs text-slate-400 mt-4 leading-none">
                  Already have an account?{" "}
                  <span
                    onClick={() => setAuthFormType("login")}
                    className="text-indigo-600 font-black cursor-pointer underline"
                  >
                    Log In
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 11. Room Details Modal */}
      {showRoomModal && selectedMatchForDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onCloseRoomModal} />
          <div className="bg-[#121622] rounded-[32px] max-w-sm w-full p-6 shadow-2xl relative z-10 border border-[#242835]/60 animate-scale-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Room Details</h3>
              <button 
                onClick={onCloseRoomModal}
                className="p-1.5 bg-[#1f2335] text-slate-400 rounded-full cursor-pointer hover:text-white transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-[#0e111a] border border-[#242835] rounded-2xl p-4 flex flex-col items-center">
                <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1.5">Room ID</span>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-black text-white tracking-widest">
                    {selectedMatchForDetails.roomId || "WAITING..."}
                  </span>
                  {selectedMatchForDetails.roomId && (
                    <button 
                      onClick={() => copyToClipboard(selectedMatchForDetails.roomId!)}
                      className="p-1.5 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/20 active:scale-90 transition-all cursor-pointer"
                    >
                      <Copy className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-[#0e111a] border border-[#242835] rounded-2xl p-4 flex flex-col items-center">
                <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1.5">Password</span>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-black text-amber-500 tracking-widest">
                    {selectedMatchForDetails.roomPass || "TBD"}
                  </span>
                  {selectedMatchForDetails.roomPass && (
                    <button 
                      onClick={() => copyToClipboard(selectedMatchForDetails.roomPass!)}
                      className="p-1.5 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/20 active:scale-90 transition-all cursor-pointer"
                    >
                      <Copy className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-4 flex gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
                <p className="text-[11px] text-slate-400 font-bold leading-relaxed">
                  ম্যাচ শুরু হওয়ার ৫-১০ মিনিট আগে রুম আইডি এবং পাসওয়ার্ড এখানে দেওয়া হবে। পাসওয়ার্ড কাউকে দিবেন না।
                </p>
              </div>

              <button
                onClick={onCloseRoomModal}
                className="w-full py-4 bg-slate-100 hover:bg-white text-slate-900 font-black text-xs uppercase tracking-widest rounded-2xl mt-2 transition-all shadow-xl"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 12. Prize Details Modal */}
      {showPrizeModal && selectedMatchForDetails && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-0 sm:p-4 animate-fade-in font-sans">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClosePrizeModal} />
          <div className="bg-[#0b0c10] border-t sm:border border-slate-800/80 w-full sm:max-w-md rounded-t-[32px] sm:rounded-3xl max-h-[92vh] overflow-y-auto p-5 relative z-10 animate-slide-up pb-10 text-slate-100">
            <button
              onClick={onClosePrizeModal}
              className="absolute -top-3.5 right-4 sm:-top-4 sm:-right-4 p-1.5 bg-[#0b0c10] border-2 border-amber-500 rounded-full shadow-[0_0_15px_rgba(245,158,11,0.45)] cursor-pointer text-white hover:bg-amber-950 transition-all active:scale-95 z-50 flex items-center justify-center"
            >
              <X className="h-4 w-4.5 text-white" />
            </button>

            <div className="flex justify-between items-center pb-4 border-b border-slate-800/50 mb-5 text-left sticky top-0 bg-[#0b0c10]/95 backdrop-blur-md z-1">
              <div className="flex items-center gap-2.5">
                <div className="bg-amber-500/15 p-2.5 text-amber-500 rounded-full flex items-center justify-center shrink-0">
                  <Trophy className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-[17px] font-black text-white leading-none">
                    {selectedMatchForDetails.status === "completed" ? "Match Results" : "Total Prize Pool"}
                  </h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase mt-1 tracking-wider">
                    {selectedMatchForDetails.title}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-gradient-to-br from-amber-600/20 to-amber-900/10 border border-amber-500/20 rounded-3xl p-6 text-center shadow-inner">
                <span className="text-[11px] text-amber-500 font-black uppercase tracking-widest block mb-1">
                   Match Total Prize
                </span>
                <span className="text-4xl font-black text-white block tracking-tighter">
                  ৳{selectedMatchForDetails.prize}
                </span>
              </div>

              {selectedMatchForDetails.status === "completed" && selectedMatchForDetails.results && selectedMatchForDetails.results.length > 0 ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 p-1">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                    <span className="text-[12px] font-black text-emerald-500 uppercase tracking-widest">Winners & Results List</span>
                  </div>
                  <div className="space-y-2.5">
                    {selectedMatchForDetails.results.map((res: any, idx: number) => (
                      <div key={idx} className="bg-[#121620] border border-slate-800 rounded-2xl p-4 flex justify-between items-center group transition-all hover:border-emerald-500/30">
                        <div className="flex items-center gap-3">
                          <div className={`h-8 w-8 rounded-xl flex items-center justify-center font-black text-xs ${idx === 0 ? 'bg-amber-500 text-black' : idx === 1 ? 'bg-slate-300 text-slate-900' : idx === 2 ? 'bg-amber-700/50 text-amber-100' : 'bg-slate-800 text-slate-400'}`}>
                            {idx + 1}
                          </div>
                          <div>
                            <p className="text-sm font-black text-white truncate max-w-[150px]">{res.name}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">Kills: {res.kills}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-base font-black text-emerald-500 tracking-tight">+৳{res.prize}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 p-1">
                    <Headphones className="h-4 w-4 text-slate-400" />
                    <span className="text-[12px] font-black text-slate-400 uppercase tracking-widest">Payout Structure</span>
                  </div>
                  
                  <div className="space-y-2.5">
                    {[
                      { rank: "Winner / BOOYAH", prize: selectedMatchForDetails.prize },
                      { rank: "Top Fragger / Most Kills", prize: "BONUS" },
                      { rank: "Per Kill Reward", prize: `৳${selectedMatchForDetails.perKill || 7}` }
                    ].map((row, idx) => (
                      <div key={idx} className="bg-[#121620] border border-slate-800 rounded-2xl p-4 flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-300 uppercase tracking-wide">{row.rank}</span>
                        <span className="text-sm font-black text-[#f59e0b]">{row.prize}</span>
                      </div>
                    ))}
                  </div>

                  <div className="bg-amber-500/5 border border-amber-500/10 rounded-2xl p-4 text-center mt-4">
                    <span className="text-[11px] text-amber-500 font-bold block leading-relaxed italic">
                      {selectedMatchForDetails.status === "completed" 
                        ? "Admin is processing final results. Player names will appear here soon!" 
                        : "Match results will be posted here after the match concludes and prizes are distributed by admins."}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={onClosePrizeModal}
              className="w-full mt-6 py-4 bg-white/5 border border-white/5 hover:bg-white/10 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all active:scale-[0.98] cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 13. Slots Details Modal */}
      {showSlotsModal && selectedMatchForDetails && (
        <div className="fixed inset-0 z-50 flex items-end">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs" onClick={onCloseSlotsModal} />
          <div className="bg-[#0e1015] w-full rounded-t-[40px] max-h-[90vh] flex flex-col relative z-10 animate-slide-up border-t border-[#242835]/60 overflow-hidden">
            <div className="w-12 h-1.5 bg-[#242835] rounded-full mx-auto mt-4 mb-4" />
            <div className="px-6 flex justify-between items-center mb-6">
              <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Match Participants</h3>
                <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mt-1">
                  {participants.length} / {selectedMatchForDetails.total} Joined
                </p>
              </div>
              <button 
                onClick={onCloseSlotsModal}
                className="h-10 w-10 bg-[#1f2335] text-white rounded-full flex items-center justify-center"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 pb-10">
              {participants.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="h-16 w-16 bg-[#141722] rounded-full flex items-center justify-center mb-4 border border-slate-800">
                    <Users className="h-8 w-8 text-slate-700" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-500">No participants yet</h4>
                  <p className="text-xs text-slate-600 mt-1">Be the first one to join this match!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {participants.map((p, idx) => (
                    <div 
                      key={p.uid || idx} 
                      className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${
                        p.uid === userData?.uid 
                          ? "bg-indigo-500/10 border-indigo-500/30 ring-1 ring-indigo-500/20" 
                          : "bg-[#141722] border-[#242835]"
                      }`}
                    >
                      <div className={`h-10 w-10 rounded-xl flex items-center justify-center font-black text-xs ${
                        p.uid === userData?.uid ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-500 border border-slate-800"
                      }`}>
                        {p.slot || idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-black text-white truncate uppercase tracking-tight">
                          {p.gameName || p.appName || "Unnamed Player"}
                          {p.uid === userData?.uid && (
                            <span className="ml-2 text-[8px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full">YOU</span>
                          )}
                        </h4>
                        <p className="text-[10px] text-slate-500 font-bold truncate">UID: {p.uid?.slice(0, 8)}...</p>
                      </div>
                      <CheckCircle2 className={`h-5 w-5 ${p.uid === userData?.uid ? "text-indigo-400" : "text-emerald-500/40"}`} />
                    </div>
                  ))}
                </div>
              )}

              {participants.length > 0 && (
                <div className="mt-8 p-5 bg-[#141722] rounded-[32px] border border-[#242835]">
                  <div className="flex items-center gap-3 mb-3">
                    <Info className="h-5 w-5 text-blue-400" />
                    <h5 className="text-xs font-black text-white uppercase tracking-wider">Slot Allocation</h5>
                  </div>
                  <p className="text-[11px] text-slate-400 font-bold leading-relaxed">
                    আপনার জয়েন করা স্লট নাম্বার অনুযায়ী রুমে জয়েন করবেন। স্লট পরিবর্তন করলে রুম থেকে কিক দেওয়া হতে পারে। ফেয়ার খেলা বজায় রাখুন।
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
