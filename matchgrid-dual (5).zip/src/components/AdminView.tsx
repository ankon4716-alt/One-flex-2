import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDoc,
  setDoc,
  query,
  orderBy,
  where,
  increment,
} from "firebase/firestore";
import {
  Plus,
  Trash2,
  Key,
  Trophy,
  Save,
  CheckCircle,
  XCircle,
  Clock,
  Coins,
  Settings,
  Bell,
  UserCheck,
  User,
  Zap,
  ArrowLeft,
} from "lucide-react";
import { Match, AppConfig } from "../types";

interface AdminViewProps {
  onToast: (msg: string) => void;
  matches: Match[];
  onRefreshMatches: () => Promise<void>;
  appConfig: AppConfig;
  onRefreshConfig: () => Promise<void>;
  banners?: any[];
  categories?: string[];
  onBack?: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  onToast,
  matches,
  onRefreshMatches,
  appConfig,
  onRefreshConfig,
  banners = [],
  categories = [],
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<"matches" | "config" | "transactions" | "users" | "giveaways" | "exports">("matches");

  // ---- NEW MATCH FORM STATE ----
  const [title, setTitle] = useState("");
  const [type, setType] = useState("BR SOLO");
  const [map, setMap] = useState("Bermuda");
  const [prize, setPrize] = useState(100);
  const [fee, setFee] = useState(15);
  const [total, setTotal] = useState(8);
  const [startTimeStr, setStartTimeStr] = useState("");
  const [img, setImg] = useState("");
  const [teamMode, setTeamMode] = useState("Solo");
  const [perKill, setPerKill] = useState(5);
  const [platform, setPlatform] = useState("MOBILE");
  const [matchRules, setMatchRules] = useState("");

  // ---- DYNAMIC GIVEAWAY GENERATOR STATES ----
  const [giveaways, setGiveaways] = useState<any[]>([]);
  const [newGiveawayCode, setNewGiveawayCode] = useState("");
  const [newGiveawayReward, setNewGiveawayReward] = useState(50);
  const [isCreatingGiveaway, setIsCreatingGiveaway] = useState(false);

  // ---- GLOBAL PLAYER DETAIL EDIT FORM STATES ----
  const [editingUserUid, setEditingUserUid] = useState<string | null>(null);
  const [editAppName, setEditAppName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editGameName, setEditGameName] = useState("");
  const [editGameUid, setEditGameUid] = useState("");
  const [editMatchesPlayed, setEditMatchesPlayed] = useState(0);
  const [editMatchesWon, setEditMatchesWon] = useState(0);
  const [editIsUidVerified, setEditIsUidVerified] = useState(false);
  const [editBalance, setEditBalance] = useState(0);
  const [editWinBalance, setEditWinBalance] = useState(0);
  const [isSavingUserChanges, setIsSavingUserChanges] = useState(false);

  const [loading, setLoading] = useState(false);
  const [userSearchTerm, setUserSearchTerm] = useState("");

  // ---- APP CONFIG FIELDS ----
  const [bannerUrl, setBannerUrl] = useState(appConfig.bannerUrl);
  const [notice, setNotice] = useState(appConfig.notice);
  const [adminPhone, setAdminPhone] = useState(appConfig.adminPhone);
  const [bkashPhone, setBkashPhone] = useState(appConfig.bkashPhone || appConfig.adminPhone || "");
  const [nagadPhone, setNagadPhone] = useState(appConfig.nagadPhone || appConfig.adminPhone || "");
  const [rocketPhone, setRocketPhone] = useState(appConfig.rocketPhone || appConfig.adminPhone || "");

  // ---- BANNER SYSTEM OPERATIONS STATES ----
  const [newBannerImg, setNewBannerImg] = useState("");
  const [newBannerTitle, setNewBannerTitle] = useState("");
  const [newBannerSubtitle, setNewBannerSubtitle] = useState("");
  const [addingBanner, setAddingBanner] = useState(false);

  // ---- ROOM MANAGEMENT STATES ----
  const [editingRoomMatchId, setEditingRoomMatchId] = useState<string | null>(null);
  const [roomId, setRoomId] = useState("");
  const [roomPass, setRoomPass] = useState("");

  // ---- CUSTOM MATCH RULES EDIT STATES ----
  const [editingRulesMatchId, setEditingRulesMatchId] = useState<string | null>(null);
  const [rulesText, setRulesText] = useState("");

  // ---- DECLARE WINNER STATES ----
  const [declaringWinnerId, setDeclaringWinnerId] = useState<string | null>(null);
  const [winnerName, setWinnerName] = useState("");
  const [winnerUid, setWinnerUid] = useState("");
  const [bonusEarned, setBonusEarned] = useState(100);

  // ---- MULTI-PLAYER RESULTS MANAGEMENT ----
  const [viewingParticipantsMatchId, setViewingParticipantsMatchId] = useState<string | null>(null);
  const [matchParticipantsForResults, setMatchParticipantsForResults] = useState<any[]>([]);
  const [isFetchingParticipants, setIsFetchingParticipants] = useState(false);
  const [matchResultsMap, setMatchResultsMap] = useState<Record<string, { kills: number; prize: number }>>({});
  const [isSubmittingResults, setIsSubmittingResults] = useState(false);

  // ---- NOTIFICATION BROADCAST ----
  const [notifTitle, setNotifTitle] = useState("");
  const [notifMsg, setNotifMsg] = useState("");

  // ---- QUICK BALANCE ADJUSTMENT BY APP UID ----
  const [quickAppUid, setQuickAppUid] = useState("");
  const [quickAmount, setQuickAmount] = useState("");
  const [quickAction, setQuickAction] = useState<"add" | "deduct">("add");
  const [quickWalletType, setQuickWalletType] = useState<"balance" | "winBalance">("balance");
  const [quickNote, setQuickNote] = useState("Admin Adjustment");
  const [verifyingQuickUser, setVerifyingQuickUser] = useState(false);
  const [verifiedQuickUser, setVerifiedQuickUser] = useState<any | null>(null);

  const handleVerifyQuickUid = async (appUidStr: string) => {
    setQuickAppUid(appUidStr);
    const clean = appUidStr.trim();
    if (clean.length < 4) {
      setVerifiedQuickUser(null);
      return;
    }
    setVerifyingQuickUser(true);
    try {
      const q = query(collection(db, "users"), where("appUid", "==", clean));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const docAndData = snap.docs[0];
        setVerifiedQuickUser({
          uid: docAndData.id,
          ...docAndData.data()
        });
      } else {
        setVerifiedQuickUser(null);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setVerifyingQuickUser(false);
    }
  };

  const submitQuickAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifiedQuickUser) {
      onToast("Please input a valid verified player 4-digit App UID first.");
      return;
    }
    const val = parseFloat(quickAmount);
    if (!val || val <= 0) {
      onToast("Specify positive valid numeric coin amount.");
      return;
    }

    try {
      const delta = quickAction === "add" ? val : -val;
      const userRef = doc(db, "users", verifiedQuickUser.uid);
      
      // Update correct wallet balance based on type (balance or winBalance)
      const fieldToUpdate = quickWalletType;
      await updateDoc(userRef, {
        [fieldToUpdate]: increment(delta)
      });

      // Write transaction folder log
      let transactionTitle = "";
      if (quickWalletType === "balance") {
        transactionTitle = quickAction === "add" ? "Admin Added Money" : "Admin Deducted Money";
      } else {
        transactionTitle = quickAction === "add" ? "Win Prize Added" : "Win Prize Deducted";
      }

      await addDoc(collection(db, "users", verifiedQuickUser.uid, "transactions"), {
        title: transactionTitle,
        amount: quickAction === "add" ? `+৳${val}` : `-৳${val}`,
        type: quickAction === "add" ? "deposit" : "withdraw",
        status: "success",
        note: quickNote,
        date: new Date().toLocaleDateString(),
        createdAt: Date.now(),
      });

      const walletLabel = quickWalletType === "balance" ? "Main Balance" : "Winning Balance";
      onToast(`Successfully adjusted ${walletLabel} of ${verifiedQuickUser.appName}! Balance updated.`);
      setQuickAppUid("");
      setQuickAmount("");
      setVerifiedQuickUser(null);
      await fetchAllUsers();
    } catch (err) {
      onToast("Failed to make ledger adjustment.");
    }
  };

  // ---- PENDING TRANSACTION LISTS ----
  const [pendingTrx, setPendingTrx] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    fetchGlobalTransactions();
    fetchAllUsers();
    if (activeTab === "giveaways") {
      fetchGiveaways();
    }
  }, [activeTab]);

  const fetchGiveaways = async () => {
    try {
      const snap = await getDocs(collection(db, "giveaways"));
      const arr: any[] = [];
      snap.forEach((doc) => {
        arr.push({ id: doc.id, ...doc.data() });
      });
      arr.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setGiveaways(arr);
    } catch (e) {
      console.error("Error fetching giveaways", e);
    }
  };

  const handleGenerate6DigitCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let codeResult = "";
    for (let i = 0; i < 6; i++) {
      codeResult += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewGiveawayCode(codeResult);
  };

  const handleCreateGiveaway = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = newGiveawayCode.trim().toUpperCase();
    if (cleanCode.length !== 6) {
      onToast("Giveaway code must be exactly 6 characters.");
      return;
    }
    if (!newGiveawayReward || newGiveawayReward <= 0) {
      onToast("Reward coins must be a positive number.");
      return;
    }

    setIsCreatingGiveaway(true);
    try {
      await setDoc(doc(db, "giveaways", cleanCode), {
        code: cleanCode,
        reward: Number(newGiveawayReward),
        claimedBy: [],
        createdAt: Date.now()
      });
      onToast(`Successfully created giveaway code: ${cleanCode} with reward ৳${newGiveawayReward}`);
      setNewGiveawayCode("");
      await fetchGiveaways();
    } catch (err) {
      onToast("Failed to write dynamic giveaway to database.");
    } finally {
      setIsCreatingGiveaway(false);
    }
  };

  const handleDeleteGiveaway = async (code: string) => {
    if (!window.confirm(`Are you sure you want to deactivate and delete giveaway code: ${code}?`)) return;
    try {
      await deleteDoc(doc(db, "giveaways", code));
      onToast(`Deactivated giveaway: ${code}`);
      await fetchGiveaways();
    } catch (err) {
      onToast("Deactivation failed.");
    }
  };

  const handleStartEditingUser = (user: any) => {
    setEditingUserUid(user.uid);
    setEditAppName(user.appName || "");
    setEditPhone(user.phone || "");
    setEditGameName(user.gameName || "");
    setEditGameUid(user.gameUid || "");
    setEditMatchesPlayed(user.matchesPlayed || 0);
    setEditMatchesWon(user.matchesWon || 0);
    setEditIsUidVerified(!!user.isUidVerified);
    setEditBalance(user.balance || 0);
    setEditWinBalance(user.winBalance || 0);
  };

  const handleSaveUserChanges = async (userUid: string) => {
    setIsSavingUserChanges(true);
    try {
      const userRef = doc(db, "users", userUid);
      await updateDoc(userRef, {
        appName: editAppName.trim(),
        phone: editPhone.trim(),
        gameName: editGameName.trim(),
        gameUid: editGameUid.trim(),
        matchesPlayed: Number(editMatchesPlayed),
        matchesWon: Number(editMatchesWon),
        isUidVerified: editIsUidVerified,
        balance: Number(editBalance),
        winBalance: Number(editWinBalance)
      });
      onToast(`Successfully updated gamer profile & stats!`);
      setEditingUserUid(null);
      await fetchAllUsers();
    } catch (err) {
      onToast("Failed to save profile changes.");
    } finally {
      setIsSavingUserChanges(false);
    }
  };

  const fetchGlobalTransactions = async () => {
    try {
      // We will look up all transactions. Since we want standard firebase compatibility, 
      // we query 'global_transactions' collection which we will write whenever a user requests deposit/withdraw.
      const snap = await getDocs(collection(db, "global_transactions"));
      const arr: any[] = [];
      snap.forEach((doc) => {
        arr.push({ id: doc.id, ...doc.data() });
      });
      // Sort: pending first, then by date descending
      arr.sort((a, b) => {
        if (a.status === "pending" && b.status !== "pending") return -1;
        if (a.status !== "pending" && b.status === "pending") return 1;
        const timeA = a.createdAt || (a.date ? new Date(a.date).getTime() : 0) || 0;
        const timeB = b.createdAt || (b.date ? new Date(b.date).getTime() : 0) || 0;
        return timeB - timeA;
      });
      setPendingTrx(arr);
    } catch (e) {
      console.error("Error fetching transactions", e);
    }
  };

  const fetchAllUsers = async () => {
    try {
      const snap = await getDocs(collection(db, "users"));
      const arr: any[] = [];
      snap.forEach((doc) => {
        arr.push({ uid: doc.id, ...doc.data() });
      });
      setAllUsers(arr);
    } catch (e) {
      console.error("Error fetching users", e);
    }
  };

  // Preset match helper
  const handleApplyPreset = (preset: string) => {
    if (preset === "cs") {
      setTitle("Premium CS-Ranked Clash 4v4");
      setType("CS-Ranked");
      setMap("Bermuda");
      setPrize(120);
      setFee(20);
      setTotal(8);
      setImg("https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400");
      setTeamMode("Squad");
      setPerKill(15);
      setPlatform("MOBILE");
    } else if (preset === "br") {
      setTitle("Ultimate Squad Battle Royale Cup");
      setType("Battle Royale");
      setMap("Purgatory");
      setPrize(400);
      setFee(35);
      setTotal(48);
      setImg("https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=400");
      setTeamMode("Squad");
      setPerKill(7);
      setPlatform("MOBILE");
    } else if (preset === "ludo") {
      setTitle("Grand Ludo Master 1v1 Battle");
      setType("Ludo");
      setMap("Classic Board");
      setPrize(90);
      setFee(12);
      setTotal(2);
      setImg("https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&q=80&w=400");
      setTeamMode("Solo");
      setPerKill(0);
      setPlatform("MOBILE");
    }
  };

  // Submit match
  const handleCreateMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !type.trim() || !map.trim() || !startTimeStr) {
      onToast("Fill in all tournament fields.");
      return;
    }

    setLoading(true);
    try {
      const startDateTime = new Date(startTimeStr);
      const startTimeStamp = {
        seconds: Math.floor(startDateTime.getTime() / 1000),
        nanoseconds: 0,
      };

      const cleanedType = type.trim();
      if (cleanedType !== "") {
        const catQuery = query(collection(db, "categories"), where("name", "==", cleanedType));
        const catSnap = await getDocs(catQuery);
        if (catSnap.empty) {
          await addDoc(collection(db, "categories"), { name: cleanedType });
        }
      }

      const matchData = {
        title: title.trim(),
        type: cleanedType,
        map: map.trim(),
        prize: Number(prize),
        fee: Number(fee),
        total: Number(total),
        joined: 0,
        img: img.trim() || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400",
        startTime: startTimeStamp,
        status: "upcoming" as const,
        roomId: "",
        roomPass: "",
        teamMode: teamMode || "Solo",
        perKill: Number(perKill || 0),
        platform: platform || "MOBILE",
        rules: matchRules.trim() || "",
      };

      await addDoc(collection(db, "matches"), matchData);
      onToast("Tournament match built and deployed successfully!");
      setTitle("");
      setStartTimeStr("");
      setMatchRules("");
      await onRefreshMatches();
    } catch (e) {
      onToast("Firestore error creating tournament.");
    } finally {
      setLoading(false);
    }
  };

  // Update room login details
  const handleSaveRoomDetails = async (matchId: string) => {
    if (!roomId.trim()) {
      onToast("Please enter a valid lobby Room ID.");
      return;
    }
    try {
      await updateDoc(doc(db, "matches", matchId), {
        roomId: roomId.trim(),
        roomPass: roomPass.trim(),
      });
      onToast("Room details synced securely!");
      setEditingRoomMatchId(null);
      setRoomId("");
      setRoomPass("");
      await onRefreshMatches();
    } catch (e) {
      onToast("Failed to link lobby credentials.");
    }
  };

  const handleSaveMatchRules = async (matchId: string) => {
    try {
      await updateDoc(doc(db, "matches", matchId), {
        rules: rulesText.trim(),
      });
      onToast("Match fairplay rules updated successfully!");
      setEditingRulesMatchId(null);
      setRulesText("");
      await onRefreshMatches();
    } catch (e) {
      onToast("Failed to update match rules.");
    }
  };

  // Conclude match and hand out prize money to the selected user!
  const handleEndMatch = async (matchId: string) => {
    if (!winnerName.trim()) {
      onToast("Specify winner nickname.");
      return;
    }

    try {
      // Mark match completed
      await updateDoc(doc(db, "matches", matchId), {
        status: "completed",
        winnerName: winnerName.trim(),
        prize: Number(bonusEarned),
      });

      // If user 4-digit App UID is entered, search and resolve it, then credit their wallet automatically!
      if (winnerUid.trim()) {
        const appUidQuery = query(collection(db, "users"), where("appUid", "==", winnerUid.trim()));
        const querySnap = await getDocs(appUidQuery);
        if (!querySnap.empty) {
          const matchedDoc = querySnap.docs[0];
          const resolvedRealUid = matchedDoc.id;
          const userRef = doc(db, "users", resolvedRealUid);
          
          await updateDoc(userRef, {
            balance: increment(Number(bonusEarned)),
            winBalance: increment(Number(bonusEarned)),
            totalEarned: increment(Number(bonusEarned)),
            matchesWon: increment(1),
            score: increment(15), // add rank points
          });

          // Write a successful transaction log
          await addDoc(collection(db, "users", resolvedRealUid, "transactions"), {
            title: `Won Tournament Prize: ${winnerName.trim()}`,
            amount: `+${bonusEarned}`,
            type: "deposit",
            status: "success",
            date: new Date().toLocaleDateString(),
            createdAt: Date.now(),
          });
          onToast(`Wallet of gamer ${matchedDoc.data().appName || ""} (App UID: ${winnerUid.trim()}) credited with ৳${bonusEarned}!`);
        } else {
          onToast("Match archived, but target App UID was not found.");
        }
      } else {
        onToast("Match archived, winner name declared.");
      }

      setDeclaringWinnerId(null);
      setWinnerName("");
      setWinnerUid("");
      await onRefreshMatches();
    } catch (e) {
      onToast("Firestore error closing competition.");
    }
  };

  // Delete match fully
  const handleDeleteMatch = async (matchId: string) => {
    if (!window.confirm("Are you sure you want to delete this tournament permanently?")) return;
    try {
      await deleteDoc(doc(db, "matches", matchId));
      onToast("Tournament scrubbed.");
      await onRefreshMatches();
    } catch (e) {
      onToast("Error removing document.");
    }
  };

  const handleOpenResultsManagement = async (matchId: string) => {
    setViewingParticipantsMatchId(matchId);
    setIsFetchingParticipants(true);
    setMatchResultsMap({});
    try {
      // Fetch users who joined this match
      const q = query(collection(db, "users"), where("joined_matches", "array-contains", matchId));
      const snap = await getDocs(q);
      const arr: any[] = [];
      const initialResults: Record<string, { kills: number; prize: number }> = {};
      
      snap.forEach((doc) => {
        const data = doc.data();
        arr.push({ 
          id: doc.id, 
          uid: doc.id,
          appName: data.appName,
          gameName: data.gameName,
          gameUid: data.gameUid 
        });
        // Initialize with 0 kills/prize
        initialResults[doc.id] = { kills: 0, prize: 0 };
      });
      
      setMatchParticipantsForResults(arr);
      setMatchResultsMap(initialResults);
    } catch (e) {
      console.error(e);
      onToast("Failed to fetch match participants.");
    } finally {
      setIsFetchingParticipants(false);
    }
  };

  const handleUpdateResultValue = (participantId: string, field: "kills" | "prize", value: number) => {
    setMatchResultsMap(prev => ({
      ...prev,
      [participantId]: {
        ...prev[participantId],
        [field]: value
      }
    }));
  };

  const handleSubmitAllResults = async () => {
    if (!viewingParticipantsMatchId) return;
    if (!window.confirm("Are you sure you want to distribute these prizes? This action will credit user balances instantly.")) return;
    
    setIsSubmittingResults(true);
    try {
      const resultsArray: any[] = [];
      const matchRef = doc(db, "matches", viewingParticipantsMatchId);
      const matchSnap = await getDoc(matchRef);
      const matchData = matchSnap.data();

      // Iterate through participants and process prizes
      for (const participant of matchParticipantsForResults) {
        const result = matchResultsMap[participant.id];
        if (!result) continue;

        // If they earned money (kills or prize)
        if (result.kills > 0 || result.prize > 0) {
          const totalPrize = Number(result.prize) + (Number(result.kills) * (matchData?.perKill || 0));
          
          if (totalPrize > 0 && participant.uid) {
            // Update user balance
            const userRef = doc(db, "users", participant.uid);
            await updateDoc(userRef, {
              winBalance: increment(totalPrize),
              totalEarned: increment(totalPrize),
              matchesPlayed: increment(1),
              score: increment(10 + (result.kills * 2) + (result.prize > 0 ? 20 : 0))
            });

            // Log transaction
            await addDoc(collection(db, "users", participant.uid, "transactions"), {
              title: `Match Reward: ${matchData?.title || "Tournament"}`,
              amount: `+৳${totalPrize}`,
              type: "deposit",
              status: "success",
              note: `Kills: ${result.kills}, Prize: ৳${result.prize}`,
              date: new Date().toLocaleDateString(),
              createdAt: Date.now(),
            });

            // Add to results array for public display
            resultsArray.push({
              uid: participant.uid,
              name: participant.gameName || participant.appName || "Player",
              kills: result.kills,
              prize: totalPrize,
              rank: result.prize > 0 ? "Winner" : "Participant"
            });
          }
        }
      }

      // Update match document with results and mark as completed
      await updateDoc(matchRef, {
        status: "completed",
        results: resultsArray,
        updatedAt: Date.now()
      });

      onToast("Prizes distributed and match marked as completed!");
      setViewingParticipantsMatchId(null);
      await onRefreshMatches();
    } catch (e) {
      console.error(e);
      onToast("Error distributing prizes.");
    } finally {
      setIsSubmittingResults(false);
    }
  };

  // Save Config properties
  const handleSaveConfig = async () => {
    try {
      await updateDoc(doc(db, "config", "banner"), {
        url: bannerUrl.trim(),
        notice: notice.trim(),
        bkash: adminPhone.trim(),
        bkashPhone: bkashPhone.trim(),
        nagadPhone: nagadPhone.trim(),
        rocketPhone: rocketPhone.trim(),
      });
      onToast("Global parameters updated inside Firestore.");
      await onRefreshConfig();
    } catch (e) {
      onToast("Failed to write to config document.");
    }
  };

  // Add and Delete Carousel Banners
  const handleAddBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBannerImg.trim()) {
      onToast("Banner Image URL is required.");
      return;
    }
    setAddingBanner(true);
    try {
      await addDoc(collection(db, "banners"), {
        img: newBannerImg.trim(),
        title: newBannerTitle.trim() || "PRO TOURNAMENT EVENT",
        subtitle: newBannerSubtitle.trim() || "Play, win, and get instantly credited!",
      });
      onToast("Banner added successfully in real-time!");
      setNewBannerImg("");
      setNewBannerTitle("");
      setNewBannerSubtitle("");
    } catch (err) {
      onToast("Failed to write banner.");
    } finally {
      setAddingBanner(false);
    }
  };

  const handleDeleteBanner = async (bannerId: string) => {
    if (!window.confirm("Are you sure you want to delete this event banner?")) return;
    try {
      await deleteDoc(doc(db, "banners", bannerId));
      onToast("Event banner removed.");
    } catch (err) {
      onToast("Failed to remove banner.");
    }
  };

  // Send Broadcast Announcements
  const handleBroadcastAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifMsg.trim()) {
      onToast("Notification needs title & body payload.");
      return;
    }
    try {
      await addDoc(collection(db, "notifications"), {
        title: notifTitle.trim(),
        message: notifMsg.trim(),
        date: new Date().toLocaleDateString(),
        timestamp: new Date().toISOString(),
      });
      onToast("Success! Broadcast pushed to notifications stream.");
      setNotifTitle("");
      setNotifMsg("");
    } catch (e) {
      onToast("Broadcast failed.");
    }
  };

  // Approve transaction request (Wallet recharge / Cashout payout approve)
  const handleApproveTransaction = async (trx: any) => {
    try {
      const { userUid, id, amount, type } = trx;
      
      // Update global transaction document status
      await updateDoc(doc(db, "global_transactions", id), {
        status: "success",
      });

      // Update nested user transaction status
      const userTrxQuery = query(
        collection(db, "users", userUid, "transactions"),
        where("trxId", "==", trx.trxId || "")
      );
      const userTrxSnap = await getDocs(userTrxQuery);
      
      let matchedTrxId = "";
      userTrxSnap.forEach((doc) => {
        matchedTrxId = doc.id;
      });

      if (matchedTrxId) {
        await updateDoc(doc(db, "users", userUid, "transactions", matchedTrxId), {
          status: "success",
        });
      } else {
        // Fallback: search by date and amount format
        const fallbackSnap = await getDocs(collection(db, "users", userUid, "transactions"));
        fallbackSnap.forEach(async (doc) => {
          const d = doc.data();
          if (d.status === "pending" && (d.trxId === trx.trxId || d.amount === amount)) {
            await updateDoc(doc.ref, { status: "success" });
          }
        });
      }

      // If it is a deposit request, credit user's balance right away!
      if (type === "deposit") {
        const val = parseFloat(amount.replace("+", ""));
        await updateDoc(doc(db, "users", userUid), {
          balance: increment(val),
        });
      }
      
      onToast("Transaction authorized & approved successfully!");
      fetchGlobalTransactions();
    } catch (e) {
      onToast("Failed to approve transaction.");
    }
  };

  // Decline transaction request
  const handleDeclineTransaction = async (trx: any) => {
    try {
      const { userUid, id, amount, type } = trx;

      await updateDoc(doc(db, "global_transactions", id), {
        status: "failed",
      });

      // Find inside user inner folder
      const fallbackSnap = await getDocs(collection(db, "users", userUid, "transactions"));
      fallbackSnap.forEach(async (doc) => {
        const d = doc.data();
        if (d.status === "pending" && (d.trxId === trx.trxId || d.amount === amount)) {
          await updateDoc(doc.ref, { status: "failed" });
        }
      });

      // If withdrawal was declined, return the reserved funds back to user to their winning balance!
      if (type === "withdraw") {
        const val = Math.abs(parseFloat(amount.replace("-", "")));
        await updateDoc(doc(db, "users", userUid), {
          winBalance: increment(val),
        });
      }

      onToast("Transaction status declined. Reserved funds returned if cashout.");
      fetchGlobalTransactions();
    } catch (e) {
      onToast("Failed to update status.");
    }
  };

  // Verify User UID / Verify Gamer
  const handleToggleUidVerification = async (user: any) => {
    try {
      const nextStatus = !user.isUidVerified;
      await updateDoc(doc(db, "users", user.uid), {
        isUidVerified: nextStatus,
      });
      onToast(`User token verification toggled to: ${nextStatus ? 'Verified' : 'Pending'}`);
      fetchAllUsers();
    } catch (e) {
      onToast("Verification write failed.");
    }
  };

  // Manual Adjust User Balance (Supports Main Balance or Win Prize balance specifically)
  const handleAdjustBalance = async (userUid: string, amtStr: string, field: "balance" | "winBalance" = "balance") => {
    const parsed = parseFloat(amtStr);
    if (isNaN(parsed)) return;
    try {
      await updateDoc(doc(db, "users", userUid), {
        [field]: increment(parsed),
      });
      const fieldTitle = field === "balance" ? "Main Balance" : "Winning Balance (Win Prize)";
      onToast(`Manually adjusted ${fieldTitle} by ৳${parsed}`);

      // Auto-log inside statement transactions
      const isAdd = parsed >= 0;
      const amountStr = isAdd ? `+৳${parsed}` : `-৳${Math.abs(parsed)}`;
      await addDoc(collection(db, "users", userUid, "transactions"), {
        title: field === "balance" 
          ? (isAdd ? "Admin Added Money" : "Admin Deducted Money")
          : (isAdd ? "Prize Added by Admin" : "Prize Deducted by Admin"),
        amount: amountStr,
        type: field === "balance" ? "deposit" : "game",
        status: "success",
        note: "System administrator adjustment",
        date: new Date().toLocaleDateString(),
        createdAt: Date.now(),
      });

      fetchAllUsers();
    } catch (e) {
      onToast("Balance update error.");
    }
  };

  return (
    <div className="w-full bg-slate-50 min-h-screen p-4 pb-32">
      {/* Admin Panel Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-900 text-white rounded-2xl p-5 mb-5 shadow-lg border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Settings className="h-6 w-6 text-indigo-400 animate-spin" style={{ animationDuration: "10s" }} />
            <div>
              <span className="text-[9px] text-indigo-200 font-extrabold uppercase tracking-widest leading-none">
                Administrative Control Terminal
              </span>
              <h2 className="text-base font-black tracking-tight mt-1 leading-none">Console Dashboard</h2>
            </div>
          </div>
          {onBack && (
            <button
              onClick={onBack}
              className="flex items-center gap-1 px-3 py-1.5 bg-white/10 hover:bg-white/20 active:scale-95 transition-all text-xs font-bold rounded-lg border border-white/10 cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Exit Admin</span>
            </button>
          )}
        </div>
      </div>

      {/* ADMIN TABS NAVIGATION */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-slate-200/80 rounded-xl mb-5 text-[10px] sm:text-xs">
        <button
          onClick={() => setActiveTab("matches")}
          className={`flex-1 min-w-[70px] py-1.5 sm:py-2 font-black rounded-lg transition-all text-center cursor-pointer ${
            activeTab === "matches"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:bg-slate-350/40"
          }`}
        >
          Tournaments
        </button>
        <button
          onClick={() => setActiveTab("transactions")}
          className={`flex-1 min-w-[90px] py-1.5 sm:py-2 font-black rounded-lg transition-all text-center cursor-pointer ${
            activeTab === "transactions"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:bg-slate-350/40"
          }`}
        >
          Ledger
        </button>
        <button
          onClick={() => setActiveTab("users")}
          className={`flex-1 min-w-[50px] py-1.5 sm:py-2 font-black rounded-lg transition-all text-center cursor-pointer ${
            activeTab === "users"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:bg-slate-350/40"
          }`}
        >
          Users
        </button>
        <button
          onClick={() => setActiveTab("giveaways")}
          className={`flex-1 min-w-[80px] py-1.5 sm:py-2 font-black rounded-lg transition-all text-center cursor-pointer ${
            activeTab === "giveaways"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:bg-slate-350/40"
          }`}
        >
          🎁 Giveaways
        </button>
        <button
          onClick={() => setActiveTab("exports")}
          className={`flex-1 min-w-[90px] py-1.5 sm:py-2 font-black rounded-lg transition-all text-center cursor-pointer ${
            activeTab === "exports"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:bg-slate-350/40"
          }`}
        >
          💻 HTML Code
        </button>
        <button
          onClick={() => setActiveTab("config")}
          className={`flex-1 min-w-[55px] py-1.5 sm:py-2 font-black rounded-lg transition-all text-center cursor-pointer ${
            activeTab === "config"
              ? "bg-slate-900 text-white shadow-sm"
              : "text-slate-600 hover:bg-slate-350/40"
          }`}
        >
          Configs
        </button>
      </div>

      {/* TAB CONTAINER 1: GENERATE & ORGANIZE TOURNAMENTS */}
      {activeTab === "matches" && (
        <div className="space-y-6">
          {/* Quick preset triggers */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
            <h4 className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider mb-2.5">
              Quick Tournament Builder Presets
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleApplyPreset("cs")}
                className="py-1.5 text-[11px] font-extrabold bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 text-indigo-700 rounded-lg cursor-pointer"
              >
                🎮 4v4 CS Match
              </button>
              <button
                type="button"
                onClick={() => handleApplyPreset("br")}
                className="py-1.5 text-[11px] font-extrabold bg-teal-50 border border-teal-100 hover:bg-teal-100 text-teal-700 rounded-lg cursor-pointer"
              >
                🪂 Squad BR
              </button>
              <button
                type="button"
                onClick={() => handleApplyPreset("ludo")}
                className="py-1.5 text-[11px] font-extrabold bg-amber-50 border border-amber-100 hover:bg-amber-100 text-amber-700 rounded-lg cursor-pointer"
              >
                🎲 Ludo 1v1
              </button>
            </div>
          </div>

          {/* Add Match Form */}
          <form
            onSubmit={handleCreateMatch}
            className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3.5"
          >
            <div className="flex items-center gap-1.5 pb-2 border-b border-slate-100">
              <Plus className="h-4.5 w-4.5 text-indigo-500" />
              <h3 className="text-xs font-black text-slate-800">Add Live Match Segment</h3>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Match Title Banner Name
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Bermuda Snipers Battle Pro"
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Game Type (Select or Type Custom)
                </label>
                <input
                  type="text"
                  list="admin-categories-datalist"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  placeholder="e.g. Free Fire SOLO"
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none uppercase text-slate-800"
                />
                <datalist id="admin-categories-datalist">
                  {(categories && categories.length > 1 ? categories : ["BR SOLO", "BR DUO", "BR SURVIVAL", "CS [2v2]", "CLASH SQUAD", "LONE WOLF", "Ludo"]).filter(c => c !== "All").map((cat) => (
                    <option key={cat} value={cat} />
                  ))}
                </datalist>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Map Choice
                </label>
                <input
                  type="text"
                  value={map}
                  onChange={(e) => setMap(e.target.value)}
                  placeholder="Bermuda / Kalahari"
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Prize Pool (৳)
                </label>
                <input
                  type="number"
                  value={prize}
                  onChange={(e) => setPrize(Math.max(0, Number(e.target.value)))}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Entry Fee (৳)
                </label>
                <input
                  type="number"
                  value={fee}
                  onChange={(e) => setFee(Math.max(0, Number(e.target.value)))}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Max Slots
                </label>
                <input
                  type="number"
                  value={total}
                  onChange={(e) => setTotal(Math.max(1, Number(e.target.value)))}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Team Mode (1,2,3,4)
                </label>
                <select
                  value={teamMode}
                  onChange={(e) => setTeamMode(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-slate-800"
                >
                  <option value="Solo">Solo (1)</option>
                  <option value="Duo">Duo (2)</option>
                  <option value="Trio">Trio (3)</option>
                  <option value="Squad">Squad (4)</option>
                  <option value="Squad 4v4">Squad 4v4</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Per Kill reward (৳)
                </label>
                <input
                  type="number"
                  value={perKill}
                  onChange={(e) => setPerKill(Math.max(0, Number(e.target.value)))}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Platform
                </label>
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-slate-800"
                >
                  <option value="MOBILE">MOBILE</option>
                  <option value="PC">PC / EMULATOR</option>
                  <option value="ALL">ALL PLATFORMS</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Tournament Scheduled Start Time
              </label>
              <input
                type="datetime-local"
                value={startTimeStr}
                onChange={(e) => setStartTimeStr(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Match Banner Graphic URL (Optional)
              </label>
              <input
                type="text"
                value={img}
                onChange={(e) => setImg(e.target.value)}
                placeholder="https://..."
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
              />
              <div className="mt-2">
                <span className="text-[10px] text-indigo-600 font-bold block mb-1">
                  💡 Dynamic Image presets:
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setImg("https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600")}
                    className="p-1 px-2 text-[10px] font-bold bg-white hover:bg-slate-100 border border-slate-200 rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    🔥 Free Fire Setup
                  </button>
                  <button
                    type="button"
                    onClick={() => setImg("https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&q=80&w=600")}
                    className="p-1 px-2 text-[10px] font-bold bg-white hover:bg-slate-100 border border-slate-200 rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    🏜️ Desert Combat
                  </button>
                  <button
                    type="button"
                    onClick={() => setImg("https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=600")}
                    className="p-1 px-2 text-[10px] font-bold bg-white hover:bg-slate-100 border border-slate-200 rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    ⚡ Clash Squad
                  </button>
                  <button
                    type="button"
                    onClick={() => setImg("https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&q=80&w=600")}
                    className="p-1 px-2 text-[10px] font-bold bg-white hover:bg-slate-100 border border-slate-200 rounded-lg cursor-pointer transition-colors active:scale-95"
                  >
                    🎲 Ludo Classic
                  </button>
                </div>
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Match Description & Rules (Use emojis: ⚠️ for warning, 🚫 for banned, ✔️ for allowed)
              </label>
              <textarea
                rows={4}
                value={matchRules}
                onChange={(e) => setMatchRules(e.target.value)}
                placeholder="Declare match-specific rules. For example:
⚠️ “LETS PLAY” Br Solo & Duo Match Rules & Conditions ⚠️
🚫 Double Vector & Charge Boster ❌ Not Allow
✔️ M590 Gun Allow ✔️
🚫 Vehicle (গাড়ি) ❌ Not Allow"
                className="w-full text-xs font-semibold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none leading-relaxed"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer transition-colors"
            >
              {loading ? "Constructing match parameters..." : "Deploy Match Tournament"}
            </button>
          </form>

          {/* Matches List / Admin Operations */}
          <div className="space-y-3.5">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wide">
              Configure Live Matches Stream ({matches.length})
            </h3>

            {matches.map((m) => {
              const gameTime = m.startTime?.seconds
                ? new Date(m.startTime.seconds * 1000).toLocaleString()
                : new Date(m.startTime).toLocaleString();

              return (
                <div key={m.id} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <span className="text-[9px] bg-slate-100 text-slate-700 font-bold px-2 py-0.5 rounded-full border border-slate-200 uppercase">
                        {m.type} • {m.map}
                      </span>
                      <h4 className="text-xs font-black text-slate-800 mt-1.5 tracking-tight">{m.title}</h4>
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-1 font-bold">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{gameTime}</span>
                      </div>
                    </div>
                    {/* Delete action button */}
                    <button
                      onClick={() => handleDeleteMatch(m.id)}
                      className="p-1.5 bg-rose-50 text-rose-500 hover:bg-rose-100 hover:text-rose-600 rounded-full cursor-pointer transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {m.status === "upcoming" ? (
                    <div className="bg-indigo-50/50 rounded-xl p-3 border border-indigo-100 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-indigo-600 font-extrabold flex items-center gap-1 uppercase">
                          <Zap className="h-3 w-3 animate-bounce" /> Current Lobby Setup:
                        </span>
                        {(m.roomId || m.roomPass) && (
                          <span className="text-[9px] text-emerald-600 font-bold">Room Active ✔</span>
                        )}
                      </div>

                      {editingRoomMatchId === m.id ? (
                        <div className="space-y-2">
                          <div className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              placeholder="Lobby Room ID"
                              value={roomId}
                              onChange={(e) => setRoomId(e.target.value)}
                              className="text-[11px] font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none"
                            />
                            <input
                              type="text"
                              placeholder="Lobby Passcode"
                              value={roomPass}
                              onChange={(e) => setRoomPass(e.target.value)}
                              className="text-[11px] font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none"
                            />
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleSaveRoomDetails(m.id)}
                              className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[10px] rounded-lg cursor-pointer"
                            >
                              Sync Lobby Codes
                            </button>
                            <button
                              onClick={() => setEditingRoomMatchId(null)}
                              className="px-3 py-1.5 bg-slate-200 text-slate-700 font-bold text-[10px] rounded-lg cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-slate-500 font-bold">
                            {m.roomId ? `Room: ${m.roomId} | pass: ${m.roomPass}` : "No codes linked yet"}
                          </span>
                          <button
                            onClick={() => {
                              setEditingRoomMatchId(m.id);
                              setRoomId(m.roomId || "");
                              setRoomPass(m.roomPass || "");
                            }}
                            className="bg-indigo-600 text-white text-[9px] font-black px-2.5 py-1 rounded-lg hover:bg-indigo-700 cursor-pointer flex items-center gap-0.5"
                          >
                            <Key className="h-2.5 w-2.5" /> Modify Details
                          </button>
                        </div>
                      )}

                      {/* Consolidate match structure */}
                      {editingRoomMatchId !== m.id && (
                        <div className="pt-2 border-t border-indigo-100/60 flex justify-end">
                          {declaringWinnerId === m.id ? (
                            <div className="w-full space-y-2 border-t border-slate-100 pt-2 bg-white/50 p-2 rounded-xl">
                              <span className="text-[10px] text-slate-750 font-black block">Declare Winner Gamer Profile</span>
                              <input
                                type="text"
                                placeholder="Gamer Nickname (e.g. Pro Bangladeshi)"
                                value={winnerName}
                                onChange={(e) => setWinnerName(e.target.value)}
                                className="w-full text-xs font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none"
                              />

                              <div className="grid grid-cols-2 gap-2">
                                <input
                                  type="text"
                                  placeholder="Winner 4-Digit App UID"
                                  value={winnerUid}
                                  onChange={(e) => setWinnerUid(e.target.value)}
                                  className="text-xs font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none"
                                />
                                <input
                                  type="number"
                                  placeholder="Reward Coins"
                                  value={bonusEarned}
                                  onChange={(e) => setBonusEarned(Number(e.target.value))}
                                  className="text-xs font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none"
                                />
                              </div>

                              <div className="flex gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleEndMatch(m.id)}
                                  className="flex-1 py-1.5 bg-emerald-600 text-white font-extrabold text-[10px] rounded-lg cursor-pointer"
                                >
                                  Complete & Pay
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeclaringWinnerId(null)}
                                  className="py-1.5 px-3 bg-slate-200 text-slate-700 font-bold text-[10px] rounded-lg cursor-pointer"
                                >
                                  Close
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              onClick={() => handleOpenResultsManagement(m.id!)}
                              className="bg-emerald-600 text-white text-[10px] font-black px-4 py-2 rounded-xl hover:bg-emerald-700 cursor-pointer flex items-center gap-2 shadow-lg shadow-emerald-500/20 uppercase tracking-wider transition-all active:scale-95"
                            >
                              <Trophy className="h-3.5 w-3.5" /> Distribute Prizes
                            </button>
                          )}
                        </div>
                      )}

                      {/* Custom rules of the match */}
                      <div className="pt-2.5 border-t border-slate-100 space-y-2.5 text-left">
                        <div className="flex justify-between items-center bg-slate-50 p-2 rounded-xl border border-slate-150">
                          <div className="text-[10px] text-slate-500 font-bold uppercase">
                            Custom Rules: 
                            {m.rules ? (
                              <span className="text-emerald-600 font-bold ml-1">Lined ({m.rules.length} chars)</span>
                            ) : (
                              <span className="text-rose-600 italic ml-1">None (Default rules apply)</span>
                            )}
                          </div>
                          {editingRulesMatchId === m.id ? (
                            <button
                              onClick={() => setEditingRulesMatchId(null)}
                              className="text-[9px] font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 cursor-pointer"
                            >
                              Cancel
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setEditingRulesMatchId(m.id);
                                setRulesText(m.rules || "");
                              }}
                              className="text-[9px] font-black text-indigo-750 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-0.5 rounded border border-indigo-200 cursor-pointer flex items-center gap-0.5 transition-colors"
                            >
                              ⚙️ Edit Rules
                            </button>
                          )}
                        </div>

                        {editingRulesMatchId === m.id && (
                          <div className="space-y-2 bg-indigo-50/40 p-2.5 rounded-xl border border-indigo-100">
                            <label className="text-[9px] font-extrabold uppercase text-indigo-800 block">
                              Write fairplay rules below (Use ⚠️, 🚫, ✔️ for icons):
                            </label>
                            <textarea
                              rows={6}
                              value={rulesText}
                              onChange={(e) => setRulesText(e.target.value)}
                              placeholder="⚠️ Rules & Conditions ⚠️
🚫 Item Name ❌ Not Allow
✔️ Item Name ✔️ Allow"
                              className="w-full text-[11px] font-semibold bg-white p-2 border border-slate-200 rounded-lg outline-none leading-relaxed text-slate-800"
                            />
                            <button
                              type="button"
                              onClick={() => handleSaveMatchRules(m.id)}
                              className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] rounded-lg cursor-pointer transition-colors shadow-md"
                            >
                              Update Match Rules
                            </button>
                          </div>
                        )}
                        
                        {m.rules && editingRulesMatchId !== m.id && (
                          <div className="text-[10px] font-medium text-slate-600 bg-amber-500/5 p-2 rounded-lg border border-amber-500/10 max-h-24 overflow-y-auto whitespace-pre-line leading-relaxed">
                            {m.rules}
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="bg-emerald-50 text-emerald-800 p-2.5 rounded-xl flex items-center justify-between text-xs font-bold border border-emerald-100">
                      <span className="flex items-center gap-1 text-[10px] uppercase">
                        🏆 Winner: {m.winnerName || "Declared!"}
                      </span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-950 px-2 py-0.5 rounded">
                        ৳{m.prize} Awarded
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* RESULTS MANAGEMENT OVERLAY (MODERN FULLSCREEN SHEET) */}
      {viewingParticipantsMatchId && (
        <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-md flex flex-col p-4 sm:p-8">
          <div className="max-w-4xl mx-auto w-full bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="bg-slate-900 text-white p-6 flex justify-between items-center bg-gradient-to-r from-slate-900 to-indigo-950">
              <div>
                <h3 className="text-lg font-black uppercase tracking-tight">Post Results & Distribute Coins</h3>
                <p className="text-[10px] text-indigo-300 font-bold uppercase mt-1">
                  Syncing participants ledger for Match ID: {viewingParticipantsMatchId}
                </p>
              </div>
              <button 
                onClick={() => setViewingParticipantsMatchId(null)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer"
              >
                <XCircle className="h-6 w-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30">
              {isFetchingParticipants ? (
                <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <div className="h-10 w-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                  <p className="text-xs font-black text-slate-500 uppercase">Indexing Gamer Profiles...</p>
                </div>
              ) : matchParticipantsForResults.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-2xl border border-slate-100">
                  <UserCheck className="h-12 w-12 text-slate-200 mx-auto mb-4" />
                  <p className="text-sm font-bold text-slate-500">Wait! No players have joined this custom match yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-12 gap-4 px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black text-slate-400 uppercase tracking-widest border border-slate-200">
                    <div className="col-span-4">Participant Identity</div>
                    <div className="col-span-3">Gamer ID Link</div>
                    <div className="col-span-2 text-center">Kills</div>
                    <div className="col-span-3 text-right">Winning Prize (৳)</div>
                  </div>

                  {matchParticipantsForResults.map((p) => (
                    <div key={p.id} className="grid grid-cols-12 gap-4 px-4 py-3 border border-slate-100 bg-white rounded-2xl items-center hover:border-indigo-100 hover:bg-indigo-50/20 transition-all shadow-sm">
                      <div className="col-span-4">
                        <p className="text-xs font-black text-slate-800 truncate leading-none mb-1">{p.gameName || p.appName}</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight flex items-center gap-1">
                          <User className="h-2.5 w-2.5" /> @{p.appName}
                        </p>
                      </div>
                      <div className="col-span-3">
                        <span className="text-[10px] font-mono font-bold bg-slate-50 px-2 py-1 rounded-lg border border-slate-200 text-slate-700">
                          {p.gameUid || "UNLINKED"}
                        </span>
                      </div>
                      <div className="col-span-2 flex justify-center">
                        <input 
                          type="number"
                          min="0"
                          value={matchResultsMap[p.id]?.kills || 0}
                          onChange={(e) => handleUpdateResultValue(p.id, "kills", parseInt(e.target.value) || 0)}
                          className="w-16 text-center text-xs font-black py-2 bg-white border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-indigo-700"
                        />
                      </div>
                      <div className="col-span-3 flex justify-end">
                        <input 
                          type="number"
                          min="0"
                          value={matchResultsMap[p.id]?.prize || 0}
                          onChange={(e) => handleUpdateResultValue(p.id, "prize", parseInt(e.target.value) || 0)}
                          className="w-24 text-right text-xs font-black py-2 bg-emerald-50 border border-emerald-100 rounded-xl focus:border-emerald-500 outline-none px-3 text-emerald-600"
                          placeholder="e.g. 50"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-6 bg-white border-t border-slate-100 flex gap-4">
              <button 
                onClick={() => setViewingParticipantsMatchId(null)}
                className="flex-1 py-4 bg-slate-100 border border-slate-200 text-slate-600 font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all cursor-pointer"
              >
                Cancel / Exit
              </button>
              <button 
                onClick={handleSubmitAllResults}
                disabled={isSubmittingResults || matchParticipantsForResults.length === 0}
                className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-xl shadow-indigo-100 disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none cursor-pointer flex items-center justify-center gap-2"
              >
                {isSubmittingResults ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Synchronizing Balances...</span>
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    <span>Authorize & Post Results</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTAINER 2: PENDING LEDGER TRANSACTIONS */}
      {activeTab === "transactions" && (
        <div className="space-y-4">
          <h3 className="text-xs font-black text-slate-800 uppercase tracking-wide">
            Pending User Transactions Requests ({pendingTrx.filter((t) => t.status === "pending").length})
          </h3>

          {pendingTrx.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
              <Coins className="h-8 w-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-400">Ledger balance sheets are completely clear.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingTrx.map((trx) => (
                <div key={trx.id} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-2.5">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase">
                      Target UID: <span className="font-mono text-indigo-600 block">{trx.userUid}</span>
                    </span>
                    <span
                      className={`text-[9px] font-black px-2 py-0.5 rounded uppercase ${
                        trx.status === "pending"
                          ? "bg-amber-100 text-amber-800"
                          : trx.status === "success"
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-rose-100 text-rose-800"
                      }`}
                    >
                      {trx.status}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-xs font-black text-slate-800 leading-none">{trx.title}</h4>
                      <p className="text-[9px] font-mono mt-1 text-slate-400">{trx.date}</p>
                    </div>
                    <span className="text-sm font-black text-slate-900">{trx.amount}</span>
                  </div>

                  {trx.trxId && (
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-200/50 flex justify-between items-center text-[10px]">
                      <span className="font-bold text-slate-400">BKASH/NAGAD TRX ID:</span>
                      <span className="text-slate-800 font-black font-mono select-all bg-slate-100 px-1.5 py-0.5 rounded">
                        {trx.trxId}
                      </span>
                    </div>
                  )}

                  {trx.number && (
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-200/50 flex justify-between items-center text-[10px]">
                      <span className="font-bold text-slate-400">WITHDRAW TO NUMBER ({trx.method}):</span>
                      <span className="text-slate-800 font-black font-mono select-all bg-slate-100 px-1.5 py-0.5 rounded">
                        {trx.number}
                      </span>
                    </div>
                  )}

                  {trx.status === "pending" && (
                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                      <button
                        onClick={() => handleApproveTransaction(trx)}
                        className="py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10px] rounded-lg cursor-pointer flex items-center justify-center gap-1 transition-all shadow"
                      >
                        <CheckCircle className="h-3.5 w-3.5" /> Approve Payment
                      </button>
                      <button
                        onClick={() => handleDeclineTransaction(trx)}
                        className="py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[10px] rounded-lg cursor-pointer flex items-center justify-center gap-1 transition-all shadow"
                      >
                        <XCircle className="h-3.5 w-3.5" /> Reject Request
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTAINER 3: MEMBERS AND GAMERS VERIFY LIST */}
      {activeTab === "users" && (
        <div className="space-y-4">
          {/* Quick Balance Adjustment Panel */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
            <h4 className="text-[11px] font-black text-indigo-700 uppercase tracking-widest flex items-center gap-1.5">
              <Zap className="h-3.5 w-3.5 text-amber-500 fill-amber-500 shrink-0" /> Quick Wallet Balance Assistant
            </h4>
            <p className="text-[10px] text-slate-500 leading-normal">
              Directly credit prizes, add money, or deduct balances from any player globally using their permanent 4-digit App UID.
            </p>

            <form onSubmit={submitQuickAdjustment} className="space-y-3 pt-1">
              <div className="grid grid-cols-2 gap-2">
                {/* 4-digit App UID input */}
                <div className="space-y-1">
                  <label className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide block">Gamer App UID</label>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="e.g. 4851"
                    value={quickAppUid}
                    onChange={(e) => handleVerifyQuickUid(e.target.value.replace(/\D/g, ""))}
                    className="w-full bg-white border border-slate-200 text-slate-800 text-xs font-bold rounded-lg p-2 focus:outline-none focus:border-indigo-500 font-mono"
                    required
                  />
                </div>

                {/* Amount input */}
                <div className="space-y-1">
                  <label className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide block">Taka Coin Amount (৳)</label>
                  <input
                    type="number"
                    placeholder="e.g. 100"
                    value={quickAmount}
                    onChange={(e) => setQuickAmount(e.target.value)}
                    className="w-full bg-white border border-slate-200 text-slate-800 text-xs font-bold rounded-lg p-2 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {/* Wallet Destination dropdown */}
                <div className="space-y-1 col-span-1">
                  <label className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide block">Wallet Target</label>
                  <select
                    value={quickWalletType}
                    onChange={(e) => setQuickWalletType(e.target.value as "balance" | "winBalance")}
                    className="w-full bg-white border border-slate-200 text-slate-800 text-[11px] font-bold rounded-lg p-2 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="balance">Main Wallet (Add Money)</option>
                    <option value="winBalance">Winning Wallet (Win Prize)</option>
                  </select>
                </div>

                {/* Action dropdown */}
                <div className="space-y-1 col-span-1">
                  <label className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide block">Select Operation</label>
                  <select
                    value={quickAction}
                    onChange={(e) => setQuickAction(e.target.value as "add" | "deduct")}
                    className="w-full bg-white border border-slate-200 text-slate-800 text-[11px] font-bold rounded-lg p-2 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="add">Add Balance (+)</option>
                    <option value="deduct">Deduct Balance (-)</option>
                  </select>
                </div>

                {/* Reference/Reason note */}
                <div className="space-y-1 col-span-1">
                  <label className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide block">Reference / Note</label>
                  <input
                    type="text"
                    placeholder="e.g. Winner Prize"
                    value={quickNote}
                    onChange={(e) => setQuickNote(e.target.value)}
                    className="w-full bg-white border border-slate-200 text-slate-800 text-[11px] font-bold rounded-lg p-2 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Instant Verification Status box */}
              <div className="min-h-[22px] px-0.5">
                {verifyingQuickUser ? (
                  <span className="text-[10px] text-amber-600 font-bold animate-pulse">Running database search...</span>
                ) : verifiedQuickUser ? (
                  <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 font-black">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                    <span>Target Player: {verifiedQuickUser.appName} (Main: ৳{verifiedQuickUser.balance || 0} | Win: ৳{verifiedQuickUser.winBalance || 0})</span>
                  </div>
                ) : quickAppUid.length >= 4 ? (
                  <span className="text-[10px] text-rose-500 font-bold">✗ Player with 4-digit UID "{quickAppUid}" not found.</span>
                ) : null}
              </div>

              {/* Submit Trigger */}
              <button
                type="submit"
                disabled={!verifiedQuickUser || !quickAmount}
                className="w-full text-[10px] font-black uppercase tracking-wider text-white py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl cursor-pointer active:scale-98 transition-all"
              >
                Perform Real-time Wallet Adjustment
              </button>
            </form>
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pt-2">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wide">
              Registered Gamers Directory ({allUsers.length})
            </h3>
            {/* Live Search box */}
            <input
              type="text"
              placeholder="Search by App UID, Name or Phone"
              value={userSearchTerm}
              onChange={(e) => setUserSearchTerm(e.target.value)}
              className="w-full sm:max-w-xs bg-slate-50 border border-slate-200 text-xs font-bold rounded-xl px-3 py-1.5 outline-none focus:border-indigo-500"
            />
          </div>

          <div className="space-y-3">
            {allUsers.filter((u) => {
              const term = userSearchTerm.toLowerCase().trim();
              if (!term) return true;
              return (
                u.appName?.toLowerCase().includes(term) ||
                u.phone?.toLowerCase().includes(term) ||
                u.appUid?.toLowerCase().includes(term) ||
                u.gameUid?.toLowerCase().includes(term)
              );
            }).map((user) => (
              <div key={user.uid} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-slate-100 p-0.5 shadow-sm border border-slate-200">
                    <img
                      src={user.photoUrl || `https://ui-avatars.com/api/?name=${user.appName}&background=4f46e5&color=fff`}
                      alt=""
                      className="w-full h-full object-cover rounded-full bg-white"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-black text-slate-800 truncate flex items-center gap-1.5 flex-wrap">
                      {user.appName}
                      <span className="text-[10px] font-bold font-mono text-indigo-600 bg-indigo-50 border border-indigo-200/50 rounded-md px-1.5 py-0.5">
                        App UID: {user.appUid || "N/A"}
                      </span>
                    </h4>
                    <p className="text-[10px] text-slate-400 font-mono tracking-wide mt-0.5">{user.phone}</p>
                    <p className="text-[9px] text-slate-400 font-bold truncate">In-Game Link: {user.gameUid ? `${user.gameName} (ID: ${user.gameUid})` : "Not Linked"}</p>
                  </div>
                  <div className="text-right space-y-1">
                    <div>
                      <span className="text-[9px] text-slate-400 font-extrabold block uppercase">Main Balance</span>
                      <span className="text-xs font-black text-emerald-600">৳{user.balance?.toFixed(2) || "0.00"}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 font-extrabold block uppercase">Winning Balance</span>
                      <span className="text-xs font-black text-amber-500">৳{(user.winBalance ?? 0).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-slate-100 space-y-2 text-[10px] font-black">
                  {/* Option 1: Add Money (Main Balance) */}
                  <div className="w-full flex items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200/60">
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-slate-700 font-black">Add Money (Main Balance)</span>
                      <span className="text-[8px] text-slate-400 font-bold uppercase tracking-wide">Main Deposit Wallet</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleAdjustBalance(user.uid, "100", "balance")}
                        className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-extrabold rounded text-[9px] cursor-pointer"
                      >
                        +৳100
                      </button>
                      <button
                        onClick={() => handleAdjustBalance(user.uid, "20", "balance")}
                        className="px-1.5 py-1 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-extrabold rounded text-[9px] cursor-pointer"
                      >
                        +৳20
                      </button>
                      <button
                        onClick={() => handleAdjustBalance(user.uid, "-100", "balance")}
                        className="px-2 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-extrabold rounded text-[9px] cursor-pointer"
                      >
                        -৳100
                      </button>
                    </div>
                  </div>

                  {/* Option 2: Win Prize (Withdrawable Balance) */}
                  <div className="w-full flex items-center justify-between bg-amber-50/20 p-2 rounded-xl border border-amber-200/40">
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] text-amber-800 font-black">Win Prize (Withdrawable)</span>
                      <span className="text-[8px] text-amber-600/70 font-bold uppercase tracking-wide">Withdraw Allowed</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleAdjustBalance(user.uid, "100", "winBalance")}
                        className="px-2 py-1 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-amber-700 font-extrabold rounded text-[9px] cursor-pointer"
                      >
                        +৳100
                      </button>
                      <button
                        onClick={() => handleAdjustBalance(user.uid, "20", "winBalance")}
                        className="px-1.5 py-1 bg-yellow-550/10 hover:bg-yellow-500/20 border border-yellow-500/20 text-yellow-800 font-extrabold rounded text-[9px] cursor-pointer"
                      >
                        +৳20
                      </button>
                      <button
                        onClick={() => handleAdjustBalance(user.uid, "-100", "winBalance")}
                        className="px-2 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-extrabold rounded text-[9px] cursor-pointer"
                      >
                        -৳100
                      </button>
                    </div>
                  </div>

                  {/* Option 3: Profile Stats, Wins & Details Editors */}
                  {editingUserUid === user.uid ? (
                    <div className="bg-indigo-50/70 border border-indigo-200/50 p-3.5 rounded-xl space-y-3 mt-1.5 text-left text-slate-800">
                      <span className="text-[10px] text-indigo-700 font-black uppercase tracking-wider block border-b border-indigo-150 pb-1">
                        ✏️ Edit Gamer Profile, Stats & verification status
                      </span>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Lobby Nickname</label>
                          <input
                            type="text"
                            value={editAppName}
                            onChange={(e) => setEditAppName(e.target.value)}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Phone Number</label>
                          <input
                            type="text"
                            value={editPhone}
                            onChange={(e) => setEditPhone(e.target.value)}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Matches Played</label>
                          <input
                            type="number"
                            value={editMatchesPlayed}
                            onChange={(e) => setEditMatchesPlayed(Math.max(0, Number(e.target.value)))}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Matches Won (Wins count)</label>
                          <input
                            type="number"
                            value={editMatchesWon}
                            onChange={(e) => setEditMatchesWon(Math.max(0, Number(e.target.value)))}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded font-bold text-indigo-700"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Main Wallet Balance (৳)</label>
                          <input
                            type="number"
                            value={editBalance}
                            onChange={(e) => setEditBalance(parseFloat(e.target.value) || 0)}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Winning Wallet Balance (৳)</label>
                          <input
                            type="number"
                            value={editWinBalance}
                            onChange={(e) => setEditWinBalance(parseFloat(e.target.value) || 0)}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Free Fire Game Nick</label>
                          <input
                            type="text"
                            value={editGameName}
                            onChange={(e) => setEditGameName(e.target.value)}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                        <div>
                          <label className="text-[8.5px] text-slate-500 font-bold block mb-0.5">Free Fire Game ID</label>
                          <input
                            type="text"
                            value={editGameUid}
                            onChange={(e) => setEditGameUid(e.target.value)}
                            className="w-full text-xs font-semibold p-1.5 bg-white border border-slate-200 rounded"
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-1 border-t border-slate-200/50">
                        <input
                          type="checkbox"
                          id={`verify-badge-${user.uid}`}
                          checked={editIsUidVerified}
                          onChange={(e) => setEditIsUidVerified(e.target.checked)}
                          className="h-4 w-4 bg-white text-indigo-600 rounded border-slate-300"
                        />
                        <label htmlFor={`verify-badge-${user.uid}`} className="text-[9.5px] text-slate-700 font-bold tracking-wide select-none cursor-pointer">
                          ⭐️ Verified Elite Badge (Show VIP verification ticks in lobbies)
                        </label>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/50">
                        <button
                          type="button"
                          onClick={() => setEditingUserUid(null)}
                          className="py-1.5 text-[10px] font-black uppercase text-slate-500 bg-slate-200 hover:bg-slate-300 rounded cursor-pointer text-center"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={isSavingUserChanges}
                          onClick={() => handleSaveUserChanges(user.uid)}
                          className="py-1.5 text-[10px] font-black uppercase text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded cursor-pointer text-center"
                        >
                          {isSavingUserChanges ? "Saving..." : "Save Changes"}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleStartEditingUser(user)}
                      className="w-full py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/40 font-extrabold text-[9px] rounded-lg tracking-wide flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      ⚙️ Manage Profile, Wins Count & Verification Status
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTAINER 4: GENERAL APP LAYOUT & GRAPHICS */}
      {activeTab === "config" && (
        <div className="space-y-5">
          {/* Global Parameters Form */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3.5">
            <div className="flex items-center gap-1.5 pb-2 border-b border-slate-100">
              <Settings className="h-4.5 w-4.5 text-indigo-500" />
              <h3 className="text-xs font-black text-slate-800">Global System Parameters</h3>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Notice Banner Message
              </label>
              <textarea
                value={notice}
                onChange={(e) => setNotice(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none h-16 resize-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Main Image Graphic banner URL
              </label>
              <input
                type="text"
                value={bannerUrl}
                onChange={(e) => setBannerUrl(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Support / Contact Mobile (General)
                </label>
                <input
                  type="text"
                  value={adminPhone}
                  onChange={(e) => setAdminPhone(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Admin bKash Number (Personal / Send Money)
                </label>
                <input
                  type="text"
                  value={bkashPhone}
                  onChange={(e) => setBkashPhone(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Admin Nagad Number (Personal / Send Money)
                </label>
                <input
                  type="text"
                  value={nagadPhone}
                  onChange={(e) => setNagadPhone(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                  Admin Rocket Number (Personal / Send Money)
                </label>
                <input
                  type="text"
                  value={rocketPhone}
                  onChange={(e) => setRocketPhone(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                />
              </div>
            </div>

            <button
              onClick={handleSaveConfig}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-[11px] rounded-xl cursor-pointer flex items-center justify-center gap-1 transition-all"
            >
              <Save className="h-4 w-4 text-indigo-400" /> Save Parameters Setup
            </button>
          </div>

          {/* Active Header Banners Collection Box (Banner Add System) */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-4">
            <div className="flex items-center gap-1.5 pb-2 border-b border-slate-100">
              <Settings className="h-4.5 w-4.5 text-indigo-600 animate-spin-slow" />
              <h3 className="text-xs font-black text-slate-800">Carousel Banner System</h3>
            </div>

            {/* Banner Add Form */}
            <form onSubmit={handleAddBanner} className="space-y-3 bg-slate-50 p-3 rounded-xl border border-slate-200/50">
              <span className="text-[10px] text-indigo-600 font-extrabold uppercase block tracking-wider">
                Add Premium Event Banner
              </span>

              <div>
                <label className="text-[9px] text-slate-400 font-extrabold uppercase block mb-1">
                  Banner Text Header
                </label>
                <input
                  type="text"
                  value={newBannerTitle}
                  onChange={(e) => setNewBannerTitle(e.target.value)}
                  placeholder="e.g. MEGA TOURNAMENT CASH MATCH"
                  className="w-full text-xs font-bold p-2 bg-white border border-slate-200 rounded-lg focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-[9px] text-slate-400 font-extrabold uppercase block mb-1">
                  Banner Subtitle details
                </label>
                <input
                  type="text"
                  value={newBannerSubtitle}
                  onChange={(e) => setNewBannerSubtitle(e.target.value)}
                  placeholder="e.g. Join the 4v4 CS lobby segment & win rewards instantly!"
                  className="w-full text-xs font-semibold p-2 bg-white border border-slate-200 rounded-lg focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-[9px] text-slate-400 font-extrabold uppercase block mb-1">
                  Illustration Image URL
                </label>
                <input
                  type="text"
                  required
                  value={newBannerImg}
                  onChange={(e) => setNewBannerImg(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full text-xs font-bold p-2 bg-white border border-slate-200 rounded-lg focus:border-indigo-500 outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={addingBanner}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[10px] rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <Plus className="h-4 w-4" /> {addingBanner ? "Injecting..." : "Add Event Slide Banner"}
              </button>
            </form>

            {/* List current active banners */}
            <div className="space-y-2.5">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">
                Active Banners Array list ({banners.length})
              </span>

              {banners.length === 0 ? (
                <p className="text-[11px] text-slate-400 italic">No slide banners setup. Initial templates will seed on home page.</p>
              ) : (
                <div className="space-y-2">
                  {banners.map((b: any) => (
                    <div
                      key={b.id}
                      className="flex gap-2.5 bg-slate-50 border border-slate-200 rounded-xl p-2.5 items-center relative overflow-hidden"
                    >
                      <img
                        src={b.img || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=200"}
                        alt="Banner Preview"
                        className="w-14 h-11 object-cover rounded-lg shrink-0 border border-slate-200"
                      />
                      <div className="flex-1 min-w-0 pr-6">
                        <h4 className="text-[11px] font-black text-slate-800 uppercase truncate">
                          {b.title || "Untitled Carousel Banner"}
                        </h4>
                        <p className="text-[9.5px] text-slate-500 font-medium truncate leading-tight mt-0.5">
                          {b.subtitle}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteBanner(b.id)}
                        className="absolute right-2.5 p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 bg-white border border-slate-200 rounded-lg cursor-pointer transition-all self-center"
                        title="Delete Banner Slide"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Broadcast Announcements */}
          <form
            onSubmit={handleBroadcastAnnouncement}
            className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3.5"
          >
            <div className="flex items-center gap-1.5 pb-2 border-b border-slate-100">
              <Bell className="h-4.5 w-4.5 text-rose-500 animate-swing" />
              <h3 className="text-xs font-black text-slate-800">Broadcast Announcement</h3>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Notification Header
              </label>
              <input
                type="text"
                value={notifTitle}
                onChange={(e) => setNotifTitle(e.target.value)}
                placeholder="e.g. Server Maintenance Notice"
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">
                Announcement Message Body
              </label>
              <textarea
                value={notifMsg}
                onChange={(e) => setNotifMsg(e.target.value)}
                placeholder="e.g. Tonight we are upgrading the gaming lobby servers..."
                className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none h-16 resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[11px] rounded-xl cursor-pointer flex items-center justify-center gap-1 transition-all"
            >
              🚀 Send Global Notify
            </button>
          </form>
        </div>
      )}

      {/* TAB CONTAINER 5: DYNAMIC 6-CHARACTER GIVEAWAYS GENERATOR */}
      {activeTab === "giveaways" && (
        <div className="space-y-5">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2.5 border-b border-slate-100">
              <span className="text-xl">🎁</span>
              <div>
                <h3 className="text-xs font-black text-slate-800 leading-none">Dynamic Giveaway Builder</h3>
                <p className="text-[10px] text-slate-400 mt-1">Create 6-digit promotional codes that players can claim value from instantly.</p>
              </div>
            </div>

            <form onSubmit={handleCreateGiveaway} className="space-y-3.5 bg-slate-50 p-4 rounded-xl border border-slate-200/60 shadow-inner">
              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="text-[10px] text-slate-500 font-extrabold uppercase block mb-1">
                    Giveaway Promo Code (6 characters)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={newGiveawayCode}
                      onChange={(e) => setNewGiveawayCode(e.target.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase())}
                      placeholder="e.g. BOOY50"
                      className="flex-1 text-xs font-black p-2.5 bg-white border border-slate-200 rounded-xl focus:border-indigo-500 outline-none font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleGenerate6DigitCode}
                      className="px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-black text-[10px] rounded-xl cursor-pointer transition-all border border-indigo-200/50"
                    >
                      ⚡ Gen 6-Digit
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 font-extrabold uppercase block mb-1">
                    Reward Coin (৳)
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newGiveawayReward}
                    onChange={(e) => setNewGiveawayReward(Math.max(1, Number(e.target.value)))}
                    className="w-full text-xs font-black p-2.5 bg-white border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isCreatingGiveaway || newGiveawayCode.length !== 6}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-55 disabled:cursor-not-allowed text-white font-extrabold text-[11px] rounded-xl cursor-pointer flex items-center justify-center gap-1 shadow-md transition-all active:scale-[0.99]"
              >
                {isCreatingGiveaway ? "Generating..." : "🔥 Authorize Dynamic Promo Code"}
              </button>
            </form>
          </div>

          {/* Active Giveaways list */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-100 pb-2">
              Active Dynamic Giveaways ({giveaways.length})
            </h4>

            {giveaways.length === 0 ? (
              <div className="text-center py-6">
                <span className="text-3xl block filter grayscale opacity-45">✨</span>
                <p className="text-[11px] text-slate-400 italic mt-2">No custom dynamic promo codes created yet. Use the builder above!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {giveaways.map((g) => (
                  <div key={g.id} className="relative bg-slate-50 border border-slate-200/70 p-4 rounded-xl flex items-start justify-between gap-3 overflow-hidden shadow-sm hover:border-slate-350 transition-all">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 bg-slate-900 border border-[#2d82fe]/30 font-mono text-xs font-black uppercase tracking-widest text-[#2f83fe] rounded-lg">
                          {g.code}
                        </span>
                        <span className="text-xs text-amber-500 font-extrabold flex items-center gap-0.5">
                          ৳{g.reward} Value
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-450 font-semibold">
                        Created At: <span className="font-mono">{g.createdAt ? new Date(g.createdAt).toLocaleString() : "N/A"}</span>
                      </p>
                      <div className="pt-1.5">
                        <span className="text-[9px] text-slate-400 font-extrabold uppercase bg-slate-200/40 rounded px-1.5 py-0.5">
                          Redeemed claims count: {g.claimedBy?.length || 0}
                        </span>
                        {g.claimedBy && g.claimedBy.length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1 max-h-16 overflow-y-auto">
                            {g.claimedBy.map((uid: string) => (
                              <span key={uid} className="text-[8px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-150 rounded px-1 truncate max-w-16">
                                {uid.substring(0, 5)}...
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteGiveaway(g.id)}
                      className="p-1 px-2.5 text-[10px] text-rose-600 hover:text-white bg-rose-50 hover:bg-rose-600 border border-rose-200 rounded-lg cursor-pointer transition-colors"
                      title="Deactivate Promo"
                    >
                      Disable
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTAINER 6: TWO HTML DOWNLOADS EXPORTER */}
      {activeTab === "exports" && (
        <div className="space-y-50 h-full">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2.5 border-b border-slate-100">
              <span className="text-xl">💻</span>
              <div>
                <h3 className="text-xs font-black text-slate-800 leading-none">Self-Contained Code Portal Exporter</h3>
                <p className="text-[10px] text-slate-400 mt-1">Export individual, ready-to-run Ꭷɴᴇㅤꜰʟᴇx.!TUR! template layouts instantly.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
              {/* Box 1: User App Template */}
              <div className="bg-slate-900 rounded-2xl p-4 border border-slate-850 flex flex-col justify-between space-y-3.5 relative overflow-hidden">
                <div className="absolute top-[-25px] right-[-25px] w-20 h-20 bg-indigo-500/5 blur-xl pointer-events-none" />
                
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] bg-indigo-500/10 text-indigo-400 font-extrabold uppercase px-2 py-0.5 rounded-full">
                      User Client Lobby Portal html
                    </span>
                    <span className="text-[10px] text-indigo-200 font-bold font-mono">user_portal.html</span>
                  </div>
                  <h4 className="text-sm font-black text-white mt-1">User Layout Interface Code</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                    Loads fully dynamic matches list, slider, and profile segment codes.
                  </p>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[9.5px] font-mono text-emerald-400 h-44 overflow-y-auto">
                  {`<!-- Ꭷɴᴇㅤꜰʟᴇx USER INTERFACE LOBBY TEMPLATE -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ꭷɴᴇㅤꜰʟᴇx Gamer Lobby</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0e1015] text-slate-100 min-h-screen">
  <header class="p-4 bg-[#141722] border-b border-slate-800 flex justify-between items-center">
    <div class="flex items-center gap-1.5">
      <div class="h-8 w-8 bg-indigo-600 rounded flex items-center justify-center font-bold">1F</div>
      <span class="font-bold text-white">Ꭷɴᴇㅤꜰʟᴇx.!TUR! Client</span>
    </div>
    <span class="text-xs bg-slate-800 px-3 py-1 rounded text-amber-500 font-black">৳550.00</span>
  </header>
  <main class="p-4 space-y-4 max-w-xl mx-auto">
    <!-- Sliding event card -->
    <div class="bg-indigo-900/40 border border-indigo-500/30 p-4 rounded-xl text-center">
      <span class="text-[9px] bg-rose-600 px-2 py-0.5 rounded-full text-white font-bold uppercase">HOT MATCH LOBBY</span>
      <h3 class="font-extrabold text-sm text-indigo-100 mt-1.5">Daily Tournament Rooms open now</h3>
    </div>
  </main>
</body>
</html>`}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const htmlCode = `<!-- Ꭷɴᴇㅤꜰʟᴇx USER INTERFACE LOBBY TEMPLATE -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ꭷɴᴇㅤꜰʟᴇx Gamer Lobby</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0e1015] text-slate-100 min-h-screen">
  <header class="p-4 bg-[#141722] border-b border-slate-800 flex justify-between items-center">
    <div class="flex items-center gap-1.5">
      <div class="h-8 w-8 bg-indigo-600 rounded flex items-center justify-center font-bold">1F</div>
      <span class="font-bold text-white">Ꭷɴᴇㅤꜰʟᴇx.!TUR! Client</span>
    </div>
    <span class="text-xs bg-slate-800 px-3 py-1 rounded text-amber-500 font-black">৳550.00</span>
  </header>
  <main class="p-4 space-y-4 max-w-xl mx-auto">
    <!-- Sliding event card -->
    <div class="bg-indigo-900/40 border border-indigo-500/30 p-4 rounded-xl text-center">
      <span class="text-[9px] bg-rose-600 px-2 py-0.5 rounded-full text-white font-bold uppercase">HOT MATCH LOBBY</span>
      <h3 class="font-extrabold text-sm text-indigo-100 mt-1.5">Daily Tournament Rooms open now</h3>
    </div>
  </main>
</body>
</html>`;
                    navigator.clipboard.writeText(htmlCode);
                    onToast("Copied User Portal HTML Template successfully!");
                  }}
                  className="w-full text-center py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] uppercase tracking-wider rounded-xl cursor-pointer"
                >
                  📋 Copy User Portal HTML Code
                </button>
              </div>

              {/* Box 2: Admin App Template */}
              <div className="bg-slate-900 rounded-2xl p-4 border border-slate-850 flex flex-col justify-between space-y-3.5 relative overflow-hidden">
                <div className="absolute top-[-25px] right-[-25px] w-20 h-20 bg-amber-500/5 blur-xl pointer-events-none" />

                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] bg-amber-500/10 text-amber-400 font-extrabold uppercase px-2 py-0.5 rounded-full">
                      Admin Console Panel html
                    </span>
                    <span className="text-[10px] text-amber-200 font-bold font-mono">admin_portal.html</span>
                  </div>
                  <h4 className="text-sm font-black text-white mt-1">Admin Layout Interface Code</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                    Includes dynamic database controllers and transaction ledger systems.
                  </p>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[9.5px] font-mono text-emerald-400 h-44 overflow-y-auto">
                  {`<!-- Ꭷɴᴇㅤꜰʟᴇx ADMINISTRATIVE PANEL TEMPLATE -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ꭷɴᴇㅤꜰʟᴇx Authority Panel</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] p-6">
  <div class="max-w-4xl mx-auto space-y-6">
    <div class="p-6 bg-gradient-to-r from-[#1f2833] to-[#0b0c10] border border-[#66fcf1]/20 rounded-xl flex justify-between items-center">
      <div>
        <span class="text-xs text-[#66fcf1] font-black uppercase">CONTROL TERMINAL</span>
        <h2 class="text-xl font-black text-white mt-1">Custom admin Settings</h2>
      </div>
      <div class="text-xs bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded">ACTIVE CONNECTION</div>
    </div>
  </div>
</body>
</html>`}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const htmlCode = `<!-- Ꭷɴᴇㅤꜰʟᴇx ADMINISTRATIVE PANEL TEMPLATE -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ꭷɴᴇㅤꜰʟᴇx Authority Panel</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] p-6">
  <div class="max-w-4xl mx-auto space-y-6">
    <div class="p-6 bg-gradient-to-r from-[#1f2833] to-[#0b0c10] border border-[#66fcf1]/20 rounded-xl flex justify-between items-center">
      <div>
        <span class="text-xs text-[#66fcf1] font-black uppercase">CONTROL TERMINAL</span>
        <h2 class="text-xl font-black text-white mt-1">Custom admin Settings</h2>
      </div>
      <div class="text-xs bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded">ACTIVE CONNECTION</div>
    </div>
  </div>
</body>
</html>`;
                    navigator.clipboard.writeText(htmlCode);
                    onToast("Copied Admin Portal HTML Template successfully!");
                  }}
                  className="w-full text-center py-2 bg-amber-600 hover:bg-amber-700 text-white font-black text-[10px] uppercase tracking-wider rounded-xl cursor-pointer"
                >
                  📋 Copy Admin Portal HTML Code
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
