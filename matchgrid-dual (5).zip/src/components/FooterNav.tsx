import React from "react";
import { Gamepad2, Calendar, Trophy, User } from "lucide-react";

interface FooterNavProps {
  activeView: string;
  onSelectView: (view: string) => void;
  onCheckLogin: (callback: () => void) => void;
}

export const FooterNav: React.FC<FooterNavProps> = ({
  activeView,
  onSelectView,
  onCheckLogin,
}) => {
  const navItems = [
    { id: "home", label: "Play", icon: Gamepad2, secure: false },
    { id: "matches", label: "Matches", icon: Calendar, secure: true },
    { id: "leaderboard", label: "Results", icon: Trophy, secure: false },
    { id: "profile", label: "Profile", icon: User, secure: true },
  ];

  return (
    <div className="absolute bottom-5 left-4 right-4 z-40">
      <nav className="h-[68px] bg-[#111728]/95 border border-[#1e293b]/60 backdrop-blur-md rounded-full px-3 flex justify-between items-center shadow-2xl shadow-black/60">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;

          const handleClick = () => {
            if (item.secure) {
              onCheckLogin(() => onSelectView(item.id));
            } else {
              onSelectView(item.id);
            }
          };

          return (
            <button
              key={item.id}
              onClick={handleClick}
              className={`flex items-center justify-center transition-all duration-300 cursor-pointer ${
                isActive
                  ? "bg-[#2d82fe] text-white font-extrabold px-5 py-2.5 rounded-full shadow-lg shadow-blue-500/30 gap-2 scale-102 flex-1 max-w-[130px] h-[48px]"
                  : "text-slate-450 hover:text-slate-205 p-3 h-[48px] w-[48px] rounded-full flex items-center justify-center transition-colors"
              }`}
            >
              <Icon className={`h-5 w-5 transition-transform duration-200 ${isActive ? "scale-105" : ""}`} />
              {isActive && (
                <span className="text-xs tracking-wide animate-fade-in font-sans font-bold whitespace-nowrap">
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
};

