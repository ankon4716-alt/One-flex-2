import React, { useState, useEffect } from "react";
import { Match, UserData } from "../types";
import {
  Calendar,
  History,
  Trophy,
  Lock,
  Unlock,
  Copy,
  Map,
  Users,
  Smartphone,
  CircleAlert,
  LayoutGrid,
  Eye,
  X,
  CircleCheck,
  Zap,
  ArrowLeft,
} from "lucide-react";

interface MyMatchesViewProps {
  activeSubTab: "upcoming" | "history";
  onSelectSubTab: (tab: "upcoming" | "history") => void;
  matches: Match[];
  joinedMatchIds: string[];
  onCopyText: (text: string) => void;
  userData?: UserData | null;
  onBack?: () => void;
  onOpenRoomDetails: (match: Match) => void;
  onOpenPrizeDetails: (match: Match) => void;
  onOpenSlotsDetails: (match: Match) => void;
}

// Inline CountdownBar component matching the HomeView styling
const CountdownBar: React.FC<{ targetTime: any }> = ({ targetTime }) => {
  const [timeLeft, setTimeLeft] = useState<string>("TBD");
  const [isLive, setIsLive] = useState<boolean>(false);

  useEffect(() => {
    let targetMs = 0;
    if (!targetTime) return;

    if (targetTime.seconds) {
      targetMs = targetTime.seconds * 1000;
    } else {
      targetMs = new Date(targetTime).getTime();
    }

    const updateTimer = () => {
      const now = Date.now();
      const diff = targetMs - now;

      if (diff <= 0) {
        setTimeLeft("Ongoing / In Action");
        setIsLive(true);
        return;
      }

      const hrs = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diff % (1000 * 60)) / 1000);

      const hStr = hrs > 0 ? `${hrs}h ` : "";
      const mStr = mins > 0 ? `${mins}m ` : "";
      const sStr = `${secs}s`;

      setTimeLeft(`Starts in: ${hStr}${mStr}${sStr}`);
      setIsLive(false);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [targetTime]);

  return (
    <div className="w-full mt-3 bg-[#1c1f2e] border border-[#2d3247] rounded-xl py-2 px-3 text-center flex items-center justify-center gap-1.5 shadow-inner">
      <span className={`h-1.5 w-1.5 rounded-full ${isLive ? "bg-rose-500 animate-ping" : "bg-indigo-400"}`} />
      <span className="text-[10px] font-bold text-slate-300 font-mono tracking-wider uppercase">
        {timeLeft}
      </span>
    </div>
  );
};

export const MyMatchesView: React.FC<MyMatchesViewProps> = ({
  activeSubTab,
  onSelectSubTab,
  matches,
  joinedMatchIds,
  onCopyText,
  userData,
  onBack,
  onOpenRoomDetails,
  onOpenPrizeDetails,
  onOpenSlotsDetails,
}) => {
  // Filter matches based on user's join records and status Tab selection
  const userMatches = matches.filter((m) => joinedMatchIds.includes(m.id));

  const filteredMatches =
    activeSubTab === "upcoming"
      ? userMatches.filter((m) => m.status !== "completed")
      : userMatches.filter((m) => m.status === "completed");

  return (
    <div className="w-full pb-32">
      <div className="p-4 flex items-center gap-3.5">
        {onBack && (
          <button 
            onClick={onBack}
            className="h-10 w-10 flex items-center justify-center rounded-xl bg-[#161a26] border border-[#242835]/45 text-slate-300 hover:text-white transition-colors active:scale-95 cursor-pointer shrink-0"
            title="Go Back"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
        )}
        <div>
          <h2 className="text-xl font-black text-white uppercase tracking-wider">My Matches</h2>
          <p className="text-xs text-slate-400 mt-0.5">Track your ongoing lobby details & match performance</p>
        </div>
      </div>

      {/* Modern High-Contrast Sub Tabs */}
      <div className="px-4 mb-5">
        <div className="bg-[#141722] border border-[#242835]/50 p-1 rounded-2xl flex shadow-lg">
          <button
            onClick={() => onSelectSubTab("upcoming")}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-150 cursor-pointer ${
              activeSubTab === "upcoming"
                ? "bg-[#1f2333] text-white font-black shadow-inner border border-[#2d3247]/50"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Calendar className="h-4 w-4" /> Upcoming
          </button>
          <button
            onClick={() => onSelectSubTab("history")}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-150 cursor-pointer ${
              activeSubTab === "history"
                ? "bg-[#1f2333] text-white font-black shadow-inner border border-[#2d3247]/50"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <History className="h-4 w-4" /> Match History
          </button>
        </div>
      </div>

      {/* Matches Grid List: formatted exactly like HomeView */}
      <div className="px-4 space-y-6">
        {filteredMatches.length === 0 ? (
          <div className="bg-[#141722] rounded-3xl border border-[#242835] p-12 text-center flex flex-col items-center justify-center shadow-xl shadow-slate-950/40">
            <Trophy className="h-10 w-10 text-slate-500 mb-3 animate-pulse" />
            <h4 className="text-white font-black text-sm uppercase tracking-wider">No Match Registered</h4>
            <p className="text-slate-400 text-xs mt-1.5 max-w-xs leading-relaxed">
              {activeSubTab === "upcoming"
                ? "You haven't joined any battle tournaments yet. Grab your weapon and join now!"
                : "No completed match histories in your profile archive."}
            </p>
          </div>
        ) : (
          filteredMatches.map((m) => {
            const progressPercentage = Math.min((m.joined / m.total) * 100, 100);
            const isCompleted = m.status === "completed";

            // Formulate beautiful human dates
            let rawDate = new Date();
            if (m.startTime) {
              if (m.startTime.seconds) {
                rawDate = new Date(m.startTime.seconds * 1000);
              } else {
                rawDate = new Date(m.startTime);
              }
            }
            const formattedDateStr = rawDate.toLocaleDateString("en-US", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            });
            const formattedTimeStr = rawDate.toLocaleTimeString("en-US", {
              hour: "2-digit",
              minute: "2-digit",
              hour12: true
            });

            // 4-digit code helper
            const matchShortId = m.id ? (m.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) % 9000 + 1000) : "8567";

            return (
              <div
                key={m.id}
                className="bg-[#141722] rounded-3xl overflow-hidden border border-[#242835] flex flex-col relative group transition-all duration-300 shadow-xl shadow-slate-950/40"
              >
                {/* Top Banner Graphic Header */}
                <div className="h-52 relative overflow-hidden bg-slate-950">
                  <img
                    src={m.img || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600"}
                    alt={m.title}
                    className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-750"
                  />
                  {/* Premium overlay shadow gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#141722] via-[#141722]/35 to-transparent" />

                  {/* Text details overlay inside image */}
                  <div className="absolute inset-0 p-5 flex flex-col justify-end">
                    <h4 className="text-white text-xl font-black tracking-wide uppercase drop-shadow-md leading-tight">
                      {m.title || `${m.type} Tournament`}
                    </h4>

                    <div className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-350 font-extrabold uppercase tracking-widest leading-none drop-shadow-sm">
                      <span className="text-[#2d82fe]">{m.type}</span>
                      <span>•</span>
                      <span>{m.teamMode?.toUpperCase() || "SOLO"}</span>
                    </div>

                    <div className="mt-2 flex items-center gap-2">
                      <span className="bg-black/40 backdrop-blur-md px-3 py-1 rounded-lg text-[10px] text-slate-350 font-extrabold tracking-widest uppercase border border-slate-700/30">
                        MATCH ID: {matchShortId}
                      </span>
                    </div>

                    {/* Clock text details row */}
                    <div className="mt-2.5 flex items-center gap-2 text-amber-500 font-bold drop-shadow-sm text-[12px] uppercase tracking-wide">
                      <Calendar className="h-4.5 w-4.5 shrink-0 text-amber-500" />
                      <span>{formattedDateStr}, {formattedTimeStr}</span>
                    </div>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-5 flex-1 flex flex-col justify-between text-slate-200 bg-[#141722]">
                  {/* Column block details row */}
                  <div className="grid grid-cols-3 gap-2 text-center py-2.5 border-b border-[#242835]/40 mb-3 text-slate-300">
                    <div className="flex items-center justify-center gap-1.5 text-xs md:text-sm font-semibold">
                      <Map className="h-4 w-4 text-slate-400 shrink-0" />
                      <span className="truncate">{m.map}</span>
                    </div>
                    <div className="flex items-center justify-center gap-1.5 text-xs md:text-sm font-semibold">
                      <Users className="h-4 w-4 text-slate-400 shrink-0" />
                      <span>{m.teamMode || "Solo"}</span>
                    </div>
                    <div className="flex items-center justify-center gap-1.5 text-xs md:text-sm font-semibold">
                      <Smartphone className="h-4 w-4 text-slate-400 shrink-0" />
                      <span>{m.platform || "MOBILE"}</span>
                    </div>
                  </div>

                  {/* Pricing Matrix Block */}
                  <div className="grid grid-cols-3 gap-2 text-center mb-4 pt-1.5">
                    <div>
                      <div className="text-[10px] text-slate-450 font-bold uppercase tracking-wider mb-1">Prize Pool</div>
                      <div className="text-xl font-extrabold text-white">৳{m.prize}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-450 font-bold uppercase tracking-wider mb-1">Per Kill</div>
                      <div className="text-xl font-extrabold text-white font-mono">৳{m.perKill !== undefined ? m.perKill : 7}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-450 font-bold uppercase tracking-wider mb-1">Entry Fee</div>
                      <div className="text-xl font-extrabold text-white">৳{Number(m.fee).toFixed(2)}</div>
                    </div>
                  </div>

                  {/* Progress panel and Status flag button */}
                  <div className="border-t border-[#242835]/30 pt-4 mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex flex-col">
                        <span className="text-[11px] text-slate-400 font-extrabold tracking-wide uppercase">Spots Left</span>
                        {m.total - m.joined > 0 && (
                          <span className="mt-1 w-max px-2 py-0.5 text-[9px] font-black tracking-wider text-amber-500 bg-amber-500/5 rounded-lg border border-amber-500/20 uppercase">
                            {m.total - m.joined} Need Players
                          </span>
                        )}
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-white">{m.joined}/{m.total}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-4 mt-3">
                      <div className="flex-1">
                        {/* Custom visual progress bar matching layout */}
                        <div className="w-full bg-[#1e2333]/80 rounded-full h-2 overflow-hidden border border-[#242835]/30">
                          <div
                            className="h-full rounded-full bg-blue-600 shadow-sm shadow-blue-500/50"
                            style={{ width: `${progressPercentage}%` }}
                          />
                        </div>
                      </div>

                      {/* Playing state wine red button exact match */}
                      <button className="px-6 py-2 bg-[#823a3a] text-white text-[11px] font-black tracking-widest uppercase rounded-xl shadow-md border border-[#9b4949] cursor-default select-none">
                        {isCompleted ? "FINISHED" : "PLAYING"}
                      </button>
                    </div>
                  </div>

                  {/* 3 Action Options with Custom borders and click handlers */}
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {/* Room Details */}
                    <button
                      onClick={() => onOpenRoomDetails(m)}
                      className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-blue-500/40 bg-blue-950/20 hover:bg-blue-900/30 cursor-pointer transition-all active:scale-95 duration-150"
                    >
                      <CircleAlert className="h-4.5 w-4.5 text-blue-400 mb-1" />
                      <span className="text-[10px] font-bold text-slate-200 whitespace-nowrap uppercase tracking-wider">Room Details</span>
                    </button>

                    {/* Slot Details */}
                    <button
                      onClick={() => onOpenSlotsDetails(m)}
                      className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-slate-500/40 bg-slate-900/20 hover:bg-slate-800/30 cursor-pointer transition-all active:scale-95 duration-150"
                    >
                      <LayoutGrid className="h-4.5 w-4.5 text-slate-300 mb-1" />
                      <span className="text-[10px] font-bold text-slate-200 whitespace-nowrap uppercase tracking-wider">Slot Details</span>
                    </button>

                    {/* Prize Details */}
                    <button
                      onClick={() => onOpenPrizeDetails(m)}
                      className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-[#d97706]/40 bg-[#c27c13]/10 hover:bg-[#c27c13]/25 cursor-pointer transition-all active:scale-95 duration-150"
                    >
                      <Trophy className="h-4.5 w-4.5 text-[#f59e0b] mb-1" />
                      <span className="text-[10px] font-bold text-amber-400 whitespace-nowrap uppercase tracking-wider">Prize Details</span>
                    </button>
                  </div>

                  {/* Marker status dot and text */}
                  <div className="flex items-center justify-center gap-1.5 mt-2 py-1 select-none">
                    <span className={`h-2 w-2 rounded-full ${isCompleted ? "bg-slate-500" : "bg-[#dc2626] animate-ping"}`} />
                    <span className={`text-[10px] font-black uppercase tracking-wider ${isCompleted ? "text-slate-400" : "text-[#dc2626]"}`}>
                      {isCompleted ? "• MATCH CONCLUDED" : "• MATCH IS LIVE"}
                    </span>
                  </div>

                  {/* Spectacular VIEW RESULT button - Always shown for history or completed, or pending results */}
                  <button
                    onClick={() => onOpenPrizeDetails(m)}
                    className="w-full mt-3.5 flex items-center justify-center gap-2 py-3 bg-[#1d4ed8] hover:bg-[#1e40af] text-white text-xs font-black uppercase tracking-widest rounded-2xl cursor-pointer active:scale-98 transition-all shadow-lg hover:shadow-blue-950/40 border border-blue-500/30"
                  >
                    <Eye className="h-4.5 w-4.5 text-white" />
                    <span>View Result</span>
                  </button>

                  {!isCompleted && <CountdownBar targetTime={m.startTime} />}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
