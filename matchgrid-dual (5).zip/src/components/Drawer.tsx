import React from "react";
import { UserData } from "../types";
import { X, User, Phone, Edit, ArrowRight, Calendar, History, ShieldAlert, Headphones, Scroll, LogOut, CheckCircle2, Settings } from "lucide-react";

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userData: UserData | null;
  onOpenAuth: () => void;
  onOpenEditProfile: () => void;
  onOpenRules: () => void;
  onOpenSettings: () => void;
  onOpenSupport: () => void;
  onLogout: () => void;
  onSelectView: (view: string) => void;
  onSelectSubTab: (tab: "upcoming" | "history") => void;
  onCheckLogin: (callback: () => void) => void;
}

export const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  userData,
  onOpenAuth,
  onOpenEditProfile,
  onOpenRules,
  onOpenSettings,
  onOpenSupport,
  onLogout,
  onSelectView,
  onSelectSubTab,
  onCheckLogin,
}) => {
  if (!isOpen) return null;

  const maskedPhone = (ph: string) => {
    if (!ph || ph.length < 5) return "Not Set";
    return ph.substring(0, 3) + "******" + ph.substring(ph.length - 2);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop overlay */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Slideout Panel */}
      <div className="absolute inset-y-0 left-0 max-w-[300px] w-4/5 bg-slate-50 shadow-2xl flex flex-col justify-between animate-slide-in">
        <div className="overflow-y-auto flex-1">
          {/* Profile Header Block */}
          <div className="p-5 bg-white border-b border-slate-200 relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 text-slate-400 bg-slate-50 hover:bg-slate-100 rounded-full cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            {userData ? (
              /* Authenticated Profile View */
              <div className="relative pt-2">
                <button
                  onClick={onOpenEditProfile}
                  className="absolute top-0 right-0 text-[10px] bg-indigo-50 text-indigo-600 font-extrabold px-2.5 py-1 rounded-full flex items-center gap-1 hover:bg-indigo-100 cursor-pointer"
                >
                  <Edit className="h-3 w-3" /> Edit
                </button>

                <div className="flex items-center gap-3.5 mb-4">
                  <div className="h-14 w-14 rounded-full bg-indigo-600 p-0.5 shadow-md">
                    <img
                      src={
                        userData.photoUrl ||
                        `https://ui-avatars.com/api/?name=${userData.appName}&background=4f46e5&color=fff`
                      }
                      alt="Avatar"
                      className="w-full h-full object-cover rounded-full bg-white"
                    />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 tracking-tight leading-none flex items-center gap-1.5 flex-wrap">
                      {userData.appName}
                      <span className="text-[8.5px] font-bold font-mono text-emerald-600 bg-emerald-50 border border-emerald-200/50 rounded-md px-1.5 py-0.5">
                        ID: {userData.appUid || "---"}
                      </span>
                    </h3>
                    <p className="text-[10px] text-slate-400 font-bold mt-1.5 tracking-wider font-mono">
                      {maskedPhone(userData.phone)}
                    </p>
                  </div>
                </div>

                {/* Game specific credentials */}
                <div className="bg-slate-100/60 p-2.5 rounded-xl flex justify-between gap-2 border border-slate-200/50 mb-3.5">
                  <div>
                    <span className="text-[8px] text-slate-400 font-extrabold uppercase block leading-none">
                      Game Nickname
                    </span>
                    <span className="text-xs font-bold text-slate-700 mt-1 block truncate max-w-[100px]">
                      {userData.gameName || "Not Set"}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[8px] text-slate-400 font-extrabold uppercase block leading-none">
                      FREE FIRE UID
                    </span>
                    <span className="text-xs font-bold font-mono tracking-wide text-slate-700 mt-1 block">
                      {userData.gameUid || "---"}
                    </span>
                  </div>
                </div>

                {/* Verified badges */}
                <div className="flex gap-2 mb-4">
                  <div className="w-full bg-emerald-50 text-emerald-600 text-[10px] font-extrabold py-1.5 rounded-lg flex items-center justify-center gap-1.5 border border-emerald-100 shadow-sm">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 fill-emerald-500/10" /> Phone Verified
                  </div>
                </div>

                {/* Mini Wallet Info */}
                <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 p-3.5 rounded-2xl text-white shadow-lg shadow-indigo-600/10 mb-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-[9px] text-indigo-200 font-bold leading-none">WALLET STABLE BALANCE</span>
                      <h4 className="text-lg font-black mt-1">৳ {userData.balance.toFixed(2)}</h4>
                    </div>
                    <button
                      onClick={() => {
                        onClose();
                        onSelectView("wallet");
                      }}
                      className="text-[9px] font-black bg-white/20 text-white px-2.5 py-1 rounded-lg hover:bg-white/30 cursor-pointer flex items-center gap-0.5 border border-white/10"
                    >
                      Wallet <ArrowRight className="h-2.5 w-2.5" />
                    </button>
                  </div>
                </div>

                {/* Tournament stats summary */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-white border border-slate-100 p-2 rounded-xl">
                    <span className="text-[14px] font-extrabold text-slate-800">{userData.matchesPlayed || 0}</span>
                    <span className="block text-[8px] text-slate-400 font-bold leading-none uppercase mt-1">Played</span>
                  </div>
                  <div className="bg-white border border-slate-100 p-2 rounded-xl">
                    <span className="text-[14px] font-extrabold text-slate-800">{userData.matchesWon || 0}</span>
                    <span className="block text-[8px] text-slate-400 font-bold leading-none uppercase mt-1">Won</span>
                  </div>
                  <div className="bg-white border border-slate-100 p-2 rounded-xl text-emerald-600">
                    <span className="text-[14px] font-extrabold">৳{userData.totalEarned || 0}</span>
                    <span className="block text-[8px] text-slate-400 font-bold leading-none uppercase mt-1">Earned</span>
                  </div>
                </div>
              </div>
            ) : (
              /* Guest Sidebar State */
              <div className="pt-8 text-center">
                <div className="h-14 w-14 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <User className="h-7 w-7" />
                </div>
                <h4 className="text-sm font-black text-slate-800">Guest Gamer</h4>
                <p className="text-[11px] text-slate-400 mt-1 max-w-[180px] mx-auto leading-relaxed">
                  Join cash battles and start winning real rewards!
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenAuth();
                  }}
                  className="w-full mt-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer"
                >
                  Join / Sign Up Now
                </button>
              </div>
            )}
          </div>

          {/* Shortcuts & Support Groups */}
          <div className="p-5 space-y-6">
            {/* Nav Shortcuts */}
            <div>
              <h5 className="text-[9px] text-slate-400 font-black uppercase tracking-wider mb-2.5">
                My Tournaments
              </h5>
              <div className="space-y-1 bg-white border border-slate-200/50 rounded-xl p-1 shadow-sm">
                <button
                  onClick={() => {
                    onClose();
                    onCheckLogin(() => {
                      onSelectSubTab("upcoming");
                      onSelectView("matches");
                    });
                  }}
                  className="w-full flex items-center gap-3.5 px-3 py-2.5 text-xs text-slate-700 font-bold hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  <Calendar className="h-4.5 w-4.5 text-indigo-500" />
                  <span>My Joined Matches</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onCheckLogin(() => {
                      onSelectSubTab("history");
                      onSelectView("matches");
                    });
                  }}
                  className="w-full flex items-center gap-3.5 px-3 py-2.5 text-xs text-slate-700 font-bold hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  <History className="h-4.5 w-4.5 text-indigo-500" />
                  <span>Competition History</span>
                </button>
              </div>
            </div>

            {/* Admin Sector */}
            {userData && (userData.email === "ankon4716@gmail.com" || userData.isAdmin) && (
              <div>
                <h5 className="text-[9px] text-indigo-600 font-extrabold uppercase tracking-wider mb-2.5 flex items-center gap-1">
                  <span className="h-1.5 w-1.5 bg-indigo-600 rounded-full animate-ping" /> Administrator
                </h5>
                <div className="space-y-1 bg-indigo-50 border border-indigo-150 rounded-xl p-1 shadow-sm">
                  <button
                    onClick={() => {
                      onClose();
                      onSelectView("admin");
                    }}
                    className="w-full flex items-center gap-3.5 px-3 py-2.5 text-xs text-indigo-900 font-black hover:bg-indigo-100 rounded-lg cursor-pointer"
                  >
                    <Settings className="h-4.5 w-4.5 text-indigo-600" />
                    <span>Admin Controls Panel</span>
                  </button>
                </div>
              </div>
            )}

            {/* Support Configs */}
            <div>
              <h5 className="text-[9px] text-slate-400 font-black uppercase tracking-wider mb-2.5">
                Rules & Settings
              </h5>
              <div className="space-y-1 bg-white border border-slate-200/50 rounded-xl p-1 shadow-sm">
                <button
                  onClick={() => {
                    onClose();
                    onCheckLogin(onOpenSettings);
                  }}
                  className="w-full flex items-center gap-3.5 px-3 py-2.5 text-xs text-slate-700 font-bold hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  <ShieldAlert className="h-4.5 w-4.5 text-slate-400" />
                  <span>Security & Withdrawals</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onOpenSupport();
                  }}
                  className="w-full flex items-center gap-3.5 px-3 py-2.5 text-xs text-slate-700 font-bold hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  <Headphones className="h-4.5 w-4.5 text-emerald-500" />
                  <span>Help Center & WhatsApp</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onOpenRules();
                  }}
                  className="w-full flex items-center gap-3.5 px-3 py-2.5 text-xs text-slate-700 font-bold hover:bg-slate-50 rounded-lg cursor-pointer"
                >
                  <Scroll className="h-4.5 w-4.5 text-slate-400" />
                  <span>Fair Play Regulations</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Action Bottom Footer (Logout options etc.) */}
        {userData && (
          <div className="p-5 border-t border-slate-200 bg-white">
            <button
              onClick={() => {
                onClose();
                onLogout();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-rose-50 border border-rose-100 hover:bg-rose-100/50 text-rose-600 font-extrabold text-xs rounded-xl cursor-pointer"
            >
              <LogOut className="h-4 w-4" /> Logout Account
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
