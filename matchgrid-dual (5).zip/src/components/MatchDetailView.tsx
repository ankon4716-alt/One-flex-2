import React, { useState, useEffect } from "react";
import { Match, UserData } from "../types";
import {
  ChevronLeft,
  Calendar,
  Map,
  Users,
  Smartphone,
  Trophy,
  Target,
  Timer,
  CheckCircle2,
  AlertCircle,
  PlayCircle,
  AlertTriangle,
  Ban,
  Car,
  CheckSquare,
  Info,
} from "lucide-react";
import { motion } from "motion/react";

interface MatchDetailViewProps {
  match: Match;
  onBack: () => void;
  onJoin: (match: Match) => void;
  isJoined: boolean;
  userData: UserData | null;
  onOpenRoomDetails: (match: Match) => void;
  onOpenPrizeDetails: (match: Match) => void;
  onOpenSlotsDetails: (match: Match) => void;
  onOpenRulesDetails: (match: Match) => void;
}

const Countdown: React.FC<{ targetTime: any }> = ({ targetTime }) => {
  const [timeLeft, setTimeLeft] = useState<string>("TBD");

  useEffect(() => {
    let targetMs = 0;
    if (!targetTime) return;

    if (targetTime.seconds) {
      targetMs = targetTime.seconds * 1000;
    } else {
      targetMs = new Date(targetTime).getTime();
    }

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetMs - now;

      if (distance < 0) {
        setTimeLeft("LIVE MATCH STARTED");
        clearInterval(interval);
      } else {
        const h = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((distance % (1000 * 60)) / 1000);

        const hStr = h < 10 ? "0" + h : h;
        const mStr = m < 10 ? "0" + m : m;
        const sStr = s < 10 ? "0" + s : s;

        setTimeLeft(`Starts in: ${hStr}h ${mStr}m ${sStr}s`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetTime]);

  return (
    <div className="flex items-center justify-center gap-2">
      <Timer className="h-4 w-4 text-[#94a3b8]" />
      <span className="text-[13px] font-mono font-bold tracking-tight text-white/90">
        {timeLeft}
      </span>
    </div>
  );
};

export const MatchDetailView: React.FC<MatchDetailViewProps> = ({
  match,
  onBack,
  onJoin,
  isJoined,
  userData,
  onOpenRoomDetails,
  onOpenPrizeDetails,
  onOpenSlotsDetails,
  onOpenRulesDetails,
}) => {
  const progressPercentage = Math.min((match.joined / match.total) * 100, 100);
  const isFull = match.joined >= match.total;

  let rawDate = new Date();
  if (match.startTime) {
    if (match.startTime.seconds) {
      rawDate = new Date(match.startTime.seconds * 1000);
    } else {
      rawDate = new Date(match.startTime);
    }
  }
  const formattedDateStr = rawDate.toLocaleDateString("en-US", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
  const formattedTimeStr = rawDate.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
  });

  const matchShortId = match.id ? (match.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) % 9000 + 1000) : "8568";

  // Parse rules into a readable format if they are structured, or show default rules
  const rulesList = match.rules ? match.rules.split("\n").filter(r => r.trim() !== "") : [
    "⚠️ “LETS PLAY” Br Solo & Duo Match Rules & Conditions ⚠️",
    "⚠️ “LETS PLAY” BR Solo Match এর নিয়মাবলী এবং শর্তসমূহ:-",
    "🚫 Double Vector & Charge Boster ❌ Not Allow",
    "✔️ M590 Gun Allow ✔️",
    "🚫 Vehicle (গাড়ি) ❌ Not Allow",
    "🚫 Only Kord Gun Not Allow ❌",
    "🚫 All Sniper ❌ Not Allow",
    "⚠️ Must Be Follow",
    "🚫 আপনারা ম্যাচ কেনার পরে স্লট নাম্বার পেয়ে যাবেন, Slot List থেকে নাম্বার দেখে নিবেন। প্রথমে Observe Mode এ যাবেন, তারপর আপনার কেনা স্লট নাম্বার অনুযায়ী বসবেন।"
  ];

  const getRuleIcon = (rule: string) => {
    const r = rule.toLowerCase();
    if (r.includes("🚫") || r.includes("banned") || r.includes("নিষিদ্ধ") || r.includes("kick") || r.includes("কিক") || r.includes("not allow") || r.includes("no ")) {
      return <Ban className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />;
    }
    if (r.includes("✔️") || r.includes("allow") || r.includes("অনুমোদিত")) {
      return <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />;
    }
    if (r.indexOf("⚠️") !== -1 || r.includes("must")) {
      return <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />;
    }
    return <Info className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed inset-0 z-50 bg-[#07080a] flex flex-col md:max-w-md md:mx-auto md:border-x md:border-slate-800"
    >
      {/* Header Bar */}
      <div className="flex items-center p-4 border-b border-white/5 bg-[#0e1015]/80 backdrop-blur-md sticky top-0 z-10">
        <button 
          onClick={onBack}
          className="h-10 w-10 rounded-full flex items-center justify-center text-white mr-4 active:scale-90 transition-transform"
        >
          <ChevronLeft className="h-7 w-7" />
        </button>
        <div className="flex-1 flex justify-center pr-10">
          <h2 className="text-xl font-black text-white uppercase tracking-tight">
            MATCH ID: {matchShortId}
          </h2>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-32">
        {/* Banner Section */}
        <div className="relative h-64 md:h-72 w-full">
          <img
            src={match.img || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800"}
            alt={match.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#07080a] via-transparent to-black/20" />
          
          <div className="absolute bottom-6 left-6 right-6">
            <h1 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tight leading-tight drop-shadow-2xl">
              {match.title}
            </h1>
            
            <div className="mt-3 flex flex-wrap gap-2">
              <div className="bg-black/60 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-xl flex items-center gap-2">
                <span className="text-[10px] font-black text-white/50 uppercase tracking-widest">Type:</span>
                <span className="text-[11px] font-black text-white tracking-widest">{match.type || 'BR SOLO'}</span>
              </div>
              <div className="bg-black/60 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-xl flex items-center gap-2">
                <Calendar className="h-3.5 w-3.5 text-amber-500" />
                <span className="text-[11px] font-black text-amber-500 tracking-tight">
                  {formattedDateStr}, {formattedTimeStr}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="px-5 mt-6">
          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: <Map className="h-4 w-4" />, label: "MAP", value: match.map },
              { icon: <Target className="h-4 w-4" />, label: "TYPE", value: match.type },
              { icon: <Smartphone className="h-4 w-4" />, label: "DEVICE", value: match.platform || "MOBILE" },
              { icon: <Users className="h-4 w-4" />, label: "MODE", value: match.teamMode || "Solo" },
              { icon: <Info className="h-4 w-4" />, label: "MATCH TYPE", value: match.fee > 0 ? "Paid" : "Free" },
            ].map((item, idx) => (
              <div key={idx} className="bg-[#141722] border border-[#242835]/40 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                <div className="text-slate-500 mb-1 flex items-center gap-1.5">
                  {item.icon}
                  <span className="text-[9px] font-black uppercase tracking-widest">{item.label}</span>
                </div>
                <span className="text-xs font-black text-white uppercase truncate w-full">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Prize Stats */}
        <div className="px-5 mt-6">
          <div className="bg-[#141722] border border-[#242835]/50 rounded-[32px] p-6 shadow-xl shadow-black/20">
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="text-center">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2">Total Prize</span>
                <span className="text-xl font-black text-amber-500 tracking-tight">৳{match.prize}</span>
              </div>
              <div className="text-center border-x border-white/5">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2">Per Kill</span>
                <span className="text-xl font-black text-[#2d82fe] tracking-tight">৳{match.perKill ?? 7}</span>
              </div>
              <div className="text-center">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-1.5">Entry Fee</span>
                <span className="text-xl font-black text-rose-500 tracking-tight">৳{Number(match.fee).toFixed(2)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <button
                onClick={() => onOpenRoomDetails(match)}
                className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-white/5 border border-white/10 text-white text-xs font-black uppercase tracking-wider hover:bg-white/10 active:scale-95 transition-all"
              >
                <AlertCircle className="h-4 w-4 text-blue-400" />
                Room Details
              </button>
              <button
                onClick={() => onOpenPrizeDetails(match)}
                className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-white/5 border border-white/10 text-white text-xs font-black uppercase tracking-wider hover:bg-white/10 active:scale-95 transition-all"
              >
                <Trophy className="h-4 w-4 text-amber-500" />
                Prize Details
              </button>
            </div>
            <button
              onClick={() => onOpenSlotsDetails(match)}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black uppercase tracking-wider hover:bg-indigo-500/20 active:scale-95 transition-all mb-3"
            >
              <Users className="h-4 w-4" />
              View Participants / Slots
            </button>

            <button
              onClick={() => onOpenRulesDetails(match)}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-black uppercase tracking-wider hover:bg-emerald-500/20 active:scale-95 transition-all"
            >
              <CheckSquare className="h-4 w-4" />
              Match Rules & Conditions
            </button>
          </div>
        </div>

        {/* How to join match */}
        <div className="px-5 mt-4">
          <div className="bg-[#141722] border border-slate-800/40 rounded-3xl p-4 flex items-center justify-between">
            <span className="text-sm font-bold text-slate-300">How to join match?</span>
            <button 
              onClick={() => {
                window.open("https://www.youtube.com/results?search_query=how+to+join+free+fire+custom+room", "_blank");
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-500/10 text-indigo-500 text-[11px] font-black uppercase tracking-wider border border-indigo-500/20 active:scale-95 transition-all cursor-pointer"
            >
              <PlayCircle className="h-3.5 w-3.5" />
              Watch Tutorial
            </button>
          </div>
        </div>

        {/* Rules Section */}
        <div className="px-5 mt-8 pb-10">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-6 w-1.5 bg-amber-500 rounded-full" />
            <h3 className="text-xl font-black text-white uppercase tracking-tight">Rules & Regulations</h3>
          </div>
          
          <div className="space-y-6">
            <div>
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-[0.2em] block mb-4">Description</span>
              
              <div className="space-y-5">
                <div className="flex flex-col gap-4 pt-2">
                  {rulesList.map((rule, i) => (
                    <div key={i} className="flex gap-4 items-start bg-white/5 p-4 rounded-2xl border border-white/5 transition-all hover:bg-white/[0.07]">
                      {getRuleIcon(rule)}
                      <p className="text-[13px] font-bold text-slate-200 leading-relaxed">
                        {rule}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer sticky bar */}
      <div className="p-5 bg-[#0e1015] border-t border-white/5 sticky bottom-0 z-10 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
        <div className="w-full bg-[#1e2333]/40 rounded-xl py-3 px-4 mb-4 border border-white/5 shadow-inner">
           <Countdown targetTime={match.startTime} />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Participants</span>
            <div className="flex items-center gap-2">
              <span className="text-lg font-black text-white">{match.joined}<span className="text-slate-600 font-black">/{match.total}</span></span>
              {match.total - match.joined > 0 && (
                <span className="bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[10px] font-black px-2 py-0.5 rounded-lg uppercase">
                  {match.total - match.joined} Need
                </span>
              )}
            </div>
          </div>

          <button
            disabled={isJoined || isFull}
            onClick={() => onJoin(match)}
            className={`px-12 py-3.5 rounded-[20px] text-sm font-black tracking-widest uppercase transition-all duration-300 shadow-xl flex items-center gap-2 ${
              isJoined
                ? "bg-indigo-600/20 text-indigo-400 cursor-not-allowed border border-indigo-500/20"
                : isFull
                ? "bg-rose-950/20 text-rose-500 cursor-not-allowed border border-rose-500/20"
                : "bg-[#008744] hover:bg-[#007038] text-white active:scale-95 shadow-emerald-950/40"
            }`}
          >
            {isJoined ? (
              <>
                <CheckCircle2 className="h-4 w-4" />
                JOINED
              </>
            ) : isFull ? "Match Full" : "JOIN MATCH"}
          </button>
        </div>
      </div>
    </motion.div>
  );
};
