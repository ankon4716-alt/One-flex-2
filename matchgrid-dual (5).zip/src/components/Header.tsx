import React from "react";
import { Wallet, Megaphone } from "lucide-react";
import { UserData } from "../types";

interface HeaderProps {
  userData: UserData | null;
  onOpenDrawer: () => void;
  onGoToWallet: () => void;
  onCheckLogin: (callback: () => void) => void;
  onOpenNotice: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  userData,
  onOpenDrawer,
  onGoToWallet,
  onCheckLogin,
  onOpenNotice,
}) => {
  return (
    <header className="sticky top-0 left-0 w-full h-[65px] bg-[#0e1015] border-b border-[#21242c]/55 flex justify-between items-center px-4 z-40 shadow-xl transition-all duration-300">
      {/* Brand logo & title on the left */}
      <div className="flex items-center gap-2 select-none">
        {/* Avatar custom logo */}
        <div className="h-10 w-10 rounded-full bg-slate-900 border-2 border-[#2d82fe] overflow-hidden flex items-center justify-center shadow-[0_0_15px_rgba(45,130,254,0.3)]">
          <img 
            src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=100" 
            alt="Logo" 
            className="h-full w-full object-cover"
          />
        </div>
        <h1 className="text-[18px] font-black tracking-tight font-sans flex items-center">
          <span className="text-white">Let's </span>
          <span className="text-[#fb923c] ml-1.5">Play</span>
        </h1>
      </div>

      {/* Header operations on the right */}
      <div className="flex items-center gap-2.5">
        {/* Notice button with alert pulse */}
        <button
          onClick={onOpenNotice}
          className="p-1.5 hover:bg-[#1b1c24] rounded-lg cursor-pointer text-amber-500 transition-all border border-amber-500/10 bg-amber-500/5"
          title="Notice Announcement"
        >
          <Megaphone className="h-4 w-4" />
        </button>

        {/* Dynamic Coins Wallet pill with dark style */}
        <div
          onClick={() => onCheckLogin(onGoToWallet)}
          className="bg-[#1a1c24] border border-[#2c2f3a]/80 px-4 py-2 rounded-2xl flex items-center gap-2 text-sm font-black text-slate-100 cursor-pointer select-none transition-all hover:bg-slate-800 shadow shadow-black/35"
        >
          <div className="h-6 w-6 bg-emerald-500/15 border border-emerald-500/30 rounded-lg flex items-center justify-center shrink-0">
            <Wallet className="h-3.5 w-3.5 text-emerald-400 stroke-[3]" />
          </div>
          <span className="font-sans">
            {userData
              ? `৳ ${Math.floor(userData.balance)}`
              : "Login"}
          </span>
        </div>
      </div>
    </header>
  );
};

