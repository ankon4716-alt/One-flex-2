import React from 'react';
import { motion } from 'motion/react';
import { 
  ChevronLeft, 
  Map, 
  User, 
  Smartphone, 
  Info, 
  LayoutGrid, 
  Trophy, 
  Timer 
} from 'lucide-react';
import { Match } from '../types';

interface CategoryMatchesViewProps {
  category: string;
  matches: Match[];
  onBack: () => void;
  onSelectMatch: (match: Match) => void;
  onOpenRoomDetails: (match: Match) => void;
  onOpenPrizeDetails: (match: Match) => void;
  onOpenSlotsDetails: (match: Match) => void;
  onOpenRulesDetails: (match: Match) => void;
}

export const CategoryMatchesView: React.FC<CategoryMatchesViewProps> = ({ 
  category, 
  matches, 
  onBack, 
  onSelectMatch,
  onOpenRoomDetails,
  onOpenPrizeDetails,
  onOpenSlotsDetails,
  onOpenRulesDetails
}) => {
  return (
    <div className="flex flex-col min-h-screen bg-[#07080a]">
      {/* Header */}
      <header className="p-4 flex items-center bg-[#07080a] border-b border-white/5 sticky top-0 z-40">
        <button 
          onClick={onBack}
          className="h-10 w-10 rounded-full flex items-center justify-center text-white mr-4 active:scale-90 transition-transform"
        >
          <ChevronLeft size={28} />
        </button>
        <div className="flex-1 flex justify-center pr-10">
          <h2 className="text-xl font-black text-white uppercase tracking-tight">{category}</h2>
        </div>
      </header>

      {/* Match List */}
      <div className="p-4 space-y-6 pb-24">
        {matches.length > 0 ? (
          matches.map((match) => (
            <motion.div 
              key={match.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#141722] rounded-[32px] overflow-hidden border border-[#242835] shadow-2xl"
            >
              {/* Image Banner */}
              <div className="relative h-44">
                <img 
                  src={match.img || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600"} 
                  className="w-full h-full object-cover opacity-80" 
                  alt="" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#141822] via-transparent" />
                <div className="absolute inset-0 p-6 flex flex-col justify-end">
                  <h3 className="text-xl font-black text-white uppercase leading-tight mb-2">
                    {match.title}
                  </h3>
                  <div className="flex items-center gap-2">
                    <span className="bg-black/40 backdrop-blur-md border border-white/10 px-2.5 py-1 rounded-lg text-[9px] font-black text-white/70">
                      MATCH ID: {match.id}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-amber-500 font-bold text-[11px]">
                    <Timer size={12} />
                    <span>{new Date(match.startTime).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="p-6">
                <div className="grid grid-cols-3 gap-1 mb-8 opacity-70">
                  <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                    <Map size={14} className="text-slate-500" /> {match.map}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                    <User size={14} className="text-slate-500" /> {match.type}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                    <Smartphone size={14} className="text-slate-500" /> {match.platform}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-8">
                  <div>
                    <span className="text-[10px] font-black text-slate-500 uppercase block mb-1">Prize Pool</span>
                    <span className="text-lg font-black text-white">৳{match.prize}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-black text-slate-500 uppercase block mb-1">Per Kill</span>
                    <span className="text-lg font-black text-white">৳{match.perKill ?? 0}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-black text-slate-500 uppercase block mb-1">Entry Fee</span>
                    <span className="text-lg font-black text-white">৳{Number(match.fee).toFixed(2)}</span>
                  </div>
                </div>

                <hr className="border-white/5 mb-6" />

                <div className="flex items-center justify-between gap-4 mb-6">
                  <div className="flex-1">
                    <div className="flex justify-between text-[11px] font-black uppercase mb-1.5">
                       <span className="text-slate-500 tracking-wider">Spots Left</span>
                       <span className="text-white">{match.joined}/{match.total}</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500" 
                        style={{ width: `${(match.joined / match.total) * 100}%` }} 
                      />
                    </div>
                    <div className="mt-2.5">
                       <span className="bg-amber-500/10 text-amber-500 border border-amber-500/20 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider">
                        {(match.total || 48) - (match.joined || 0)} Need Players
                       </span>
                    </div>
                  </div>
                  <button 
                    onClick={() => onSelectMatch(match)}
                    className="bg-[#008744] text-white px-9 py-4 rounded-[24px] text-base font-black uppercase shadow-xl shadow-emerald-950/20 active:scale-95 transition-all"
                  >
                    JOIN
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2.5">
                  <button 
                    onClick={() => onOpenRoomDetails(match)}
                    className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#141722] border border-blue-500/30 text-white gap-1.5 hover:bg-blue-500/10 transition-colors"
                  >
                    <Info size={20} className="text-blue-400" />
                    <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">Room Details</span>
                  </button>
                  <button 
                    onClick={() => onOpenSlotsDetails(match)}
                    className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#141722] border border-slate-700/60 text-white gap-1.5 hover:bg-slate-800 transition-colors"
                  >
                    <LayoutGrid size={20} className="text-slate-400" />
                    <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">Slot Details</span>
                  </button>
                  <button 
                    onClick={() => onOpenPrizeDetails(match)}
                    className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#141722] border border-amber-500/30 text-white gap-1.5 hover:bg-amber-500/10 transition-colors"
                  >
                    <Trophy size={20} className="text-amber-500" />
                    <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">Prize Details</span>
                  </button>
                </div>

                <div className="mt-6 w-full bg-black/40 border border-white/5 py-3 rounded-2xl flex items-center justify-center gap-2">
                  <Timer size={14} className="text-slate-500" />
                  <span className="text-[11px] font-bold text-slate-300">Starts in: 23m 32s</span>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500">
            <LayoutGrid size={48} className="mb-4 opacity-20" />
            <p className="font-bold uppercase tracking-widest text-sm">No Matches Found</p>
          </div>
        )}
      </div>
    </div>
  );
};
