import React, { useState, useEffect } from "react";
import { Match, AppConfig, UserData } from "../types";
import {
  Calendar,
  Timer,
  Trophy,
  Coins,
  Users,
  CircleAlert,
  LayoutGrid,
  X,
  Copy,
  Lock,
  Unlock,
  CheckCircle2,
  TrendingUp,
  Map,
  Smartphone,
  ChevronLeft,
  ChevronRight,
  Headphones,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { MatchDetailView } from "./MatchDetailView";

interface HomeViewProps {
  bannerConfig: AppConfig | null;
  banners?: any[];
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  matches: Match[];
  joinedMatchIds: string[];
  onOpenJoin: (match: Match) => void;
  onCheckLogin: (callback: () => void) => void;
  userData?: UserData | null;
  onCopyText?: (text: string) => void;
  onOpenRoomDetails: (match: Match) => void;
  onOpenPrizeDetails: (match: Match) => void;
  onOpenSlotsDetails: (match: Match) => void;
  onOpenRulesDetails: (match: Match) => void;
}

// Simple Countdown Component for tiny labels
const Countdown: React.FC<{ targetTime: any }> = ({ targetTime }) => {
  const [timeLeft, setTimeLeft] = useState<string>("TBD");
  const [isLive, setIsLive] = useState<boolean>(false);

  useEffect(() => {
    let targetMs = 0;
    if (!targetTime) return;

    if (targetTime.seconds) {
      targetMs = targetTime.seconds * 1000;
    } else {
      targetMs = new Date(targetTime).getTime();
    }

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetMs - now;

      if (distance < 0) {
        setTimeLeft("LIVE / ENDED");
        setIsLive(true);
        clearInterval(interval);
      } else {
        const h = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((distance % (1000 * 60)) / 1000);

        const hStr = h < 10 ? "0" + h : h;
        const mStr = m < 10 ? "0" + m : m;
        const sStr = s < 10 ? "0" + s : s;

        setTimeLeft(`${hStr}h ${mStr}m ${sStr}s`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetTime]);

  return (
    <span className={`text-[10px] md:text-xs font-mono font-bold px-1.5 py-0.5 rounded ${isLive ? 'bg-rose-500/10 text-rose-500' : 'bg-indigo-500/10 text-indigo-400'}`}>
      {timeLeft}
    </span>
  );
};

// Wide block countdown bar underneath exactly matching the screenshot
const CountdownBar: React.FC<{ targetTime: any }> = ({ targetTime }) => {
  const [timeLeft, setTimeLeft] = useState<string>("TBD");
  const [isLive, setIsLive] = useState<boolean>(false);

  useEffect(() => {
    let targetMs = 0;
    if (!targetTime) return;

    if (targetTime.seconds) {
      targetMs = targetTime.seconds * 1000;
    } else {
      targetMs = new Date(targetTime).getTime();
    }

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetMs - now;

      if (distance < 0) {
        setTimeLeft("LIVE MATCH STARTED");
        setIsLive(true);
        clearInterval(interval);
      } else {
        const h = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((distance % (1000 * 60)) / 1000);

        const hStr = h < 10 ? "0" + h : h;
        const mStr = m < 10 ? "0" + m : m;
        const sStr = s < 10 ? "0" + s : s;

        setTimeLeft(`Starts in: ${hStr}h ${mStr}m ${sStr}s`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetTime]);

  return (
    <div className="w-full mt-2.5 bg-[#090d16] text-[#94a3b8] rounded-xl py-2 px-3 flex items-center justify-center gap-1.5 border border-[#1e293b]/50 shadow-inner">
      <Timer className="h-3.5 w-3.5 text-indigo-400 shrink-0 leading-none" />
      <span className="text-[10.5px] font-mono font-bold tracking-normal text-slate-300">
        {timeLeft}
      </span>
    </div>
  );
};

// Helper to determine the estimated release time for room details
const getReleaseTimeStr = (startTimeStr: any) => {
  if (!startTimeStr) return "ম্যাচ শুরুর ১৫ মিনিট আগে";
  let targetDate: Date;
  if (startTimeStr.seconds) {
    targetDate = new Date(startTimeStr.seconds * 1000);
  } else {
    targetDate = new Date(startTimeStr);
  }
  // Subtract 15 minutes
  const releaseDate = new Date(targetDate.getTime() - 15 * 60 * 1000);
  return releaseDate.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

export const HomeView: React.FC<HomeViewProps> = ({
  bannerConfig,
  banners = [],
  categories,
  selectedCategory,
  onSelectCategory,
  matches,
  joinedMatchIds,
  onOpenJoin,
  onCheckLogin,
  userData,
  onCopyText,
  onOpenRoomDetails,
  onOpenPrizeDetails,
  onOpenSlotsDetails,
  onOpenRulesDetails,
}) => {
  const [activeModalMatch, setActiveModalMatch] = useState<Match | null>(null);
  const [activeModalType, setActiveModalType] = useState<"room" | "slot" | "prize" | "rules" | null>(null);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);

  useEffect(() => {
    if (!banners || banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [banners?.length]);

  const handleNextBanner = () => {
    if (!banners || banners.length === 0) return;
    setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
  };

  const handlePrevBanner = () => {
    if (!banners || banners.length === 0) return;
    setCurrentBannerIndex((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const filteredMatches =
    selectedCategory === "All"
      ? matches
      : matches.filter((m) => m.type === selectedCategory);

  const handleCopy = (text: string) => {
    if (onCopyText) {
      onCopyText(text);
    } else {
      navigator.clipboard.writeText(text);
    }
  };

  // Helper to generate dynamic mock slots
  const getMockSlots = (match: Match) => {
    const isJoined = joinedMatchIds.includes(match.id);
    const slotsList: { slotNum: number; playerName: string; gameUid: string; isUser: boolean }[] = [];

    const fallbackNames = [
      "ankon77", "sabbir99", "pro_ff_gamer", "bucky_88", "dark_lord", "vortex_head", 
      "fire_dragon", "devil_may_care", "silent_killer", "bangla_pro", "headshot_special", 
      "cobra_commander", "raptor77", "zero_gravity", "apex_warrior", "ff_king", "skylord",
      "bongo_fighter", "taka_master", "boss_gamer", "alpha_alpha", "ghost_rider", "zeus_ff"
    ];

    const totalSlots = match.total || 48;
    const joinedCount = match.joined || 0;

    // Use persistence assigned slot if found, else default to 3
    const userSlotNum = (userData && userData.matchSlots && userData.matchSlots[match.id])
      ? Number(userData.matchSlots[match.id])
      : 3;

    for (let s = 1; s <= totalSlots; s++) {
      if (s === userSlotNum && isJoined && userData) {
        slotsList.push({
          slotNum: s,
          playerName: userData.gameName || userData.appName || "You",
          gameUid: userData.gameUid || "Linked",
          isUser: true,
        });
      } else if (s <= joinedCount) {
        const nameIndex = (match.id.charCodeAt(0) + s) % fallbackNames.length;
        const uidSuffix = (match.id.charCodeAt(1) * s * 13) % 900000 + 100000;
        slotsList.push({
          slotNum: s,
          playerName: fallbackNames[nameIndex] + "_" + s,
          gameUid: `524${uidSuffix}`,
          isUser: false,
        });
      } else {
        slotsList.push({
          slotNum: s,
          playerName: "Available Slot",
          gameUid: "Unoccupied",
          isUser: false,
        });
      }
    }

    return slotsList;
  };

  return (
    <div className="w-full h-full pb-32">
      <AnimatePresence>
        {selectedMatch && (
          <MatchDetailView
            match={selectedMatch}
            onBack={() => setSelectedMatch(null)}
            onJoin={(m) => onOpenJoin(m)}
            isJoined={joinedMatchIds.includes(selectedMatch.id)}
            userData={userData}
            onOpenRoomDetails={onOpenRoomDetails}
            onOpenPrizeDetails={onOpenPrizeDetails}
            onOpenSlotsDetails={onOpenSlotsDetails}
          />
        )}
      </AnimatePresence>

      {/* Banner Slider System */}
      <div className="px-4 pt-4">
        <div className="w-full h-44 md:h-52 rounded-[32px] overflow-hidden shadow-2xl relative bg-[#10131e] border border-white/5 select-none ring-1 ring-white/5">
          {banners && banners.length > 0 ? (
            <div className="relative w-full h-full">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentBannerIndex}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0 w-full h-full"
                >
                  <img
                    src={banners[currentBannerIndex]?.img || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800"}
                    alt="Tournament Banner"
                    className="w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0e1015] via-[#0e1015]/40 to-transparent flex flex-col justify-end p-6">
                    <span className="bg-amber-500 shadow-lg border border-amber-400/30 text-black text-[9px] font-black px-2.5 py-1 rounded-full w-max mb-2.5 uppercase tracking-widest">
                      ★ Active Event
                    </span>
                    <h2 className="text-white text-xl md:text-2xl font-black tracking-tight leading-tight uppercase drop-shadow-2xl">
                      {banners[currentBannerIndex]?.title || "PRO CASH TOURNAMENTS"}
                    </h2>
                    <p className="text-slate-200 text-[11px] leading-snug md:text-xs mt-1 max-w-[90%] font-medium">
                      {banners[currentBannerIndex]?.subtitle || "Play daily matches & withdraw instantly via bKash or Nagad"}
                    </p>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Navigation overlays */}
              {banners.length > 1 && (
                <>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10 z-20">
                    <motion.div
                      key={currentBannerIndex}
                      initial={{ width: "0%" }}
                      animate={{ width: "100%" }}
                      transition={{ duration: 4, ease: "linear" }}
                      className="h-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                    />
                  </div>
                  <button
                    onClick={handlePrevBanner}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 p-2 rounded-full bg-slate-950/50 hover:bg-slate-900/80 text-white transition-all cursor-pointer z-10"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  <button
                    onClick={handleNextBanner}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-2 rounded-full bg-slate-950/50 hover:bg-slate-900/80 text-white transition-all cursor-pointer z-10"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>

                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                    {banners.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setCurrentBannerIndex(idx)}
                        className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                          currentBannerIndex === idx ? "bg-amber-500 w-6" : "bg-white/20 w-1.5"
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="relative w-full h-full">
              <img
                src={bannerConfig?.bannerUrl || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800"}
                alt="Tournament Banner"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-4">
                <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full w-max mb-1 uppercase tracking-wider">
                  Mega Tournament
                </span>
                <h2 className="text-white text-lg md:text-2xl font-black tracking-tight leading-tight">
                  PRO CASH TOURNAMENTS
                </h2>
                <p className="text-white/80 text-[11px] md:text-xs mt-0.5">
                  Play daily matches & withdraw instantly via bKash or Nagad
                </p>
              </div>
            </div>
          )}
        </div>
      </div>



      {/* GAME MODES GRID (SHOW ONLY WHEN 'All' IS SELECTED) */}
      {selectedCategory === "All" && (
        <div className="px-4 pb-4 select-none">
          {/* NEWS TICKER CONTAINER */}
          <div className="mb-4 flex items-center gap-3 bg-[#141722] border border-[#242835]/40 rounded-2xl p-3 shadow-md shadow-slate-950/20">
            <span className="bg-[#ef4444] text-[#ffff] font-black text-[10px] tracking-widest px-2.5 py-1 rounded-lg uppercase">
              NEWS
            </span>
            <p className="text-xs text-slate-200 font-semibold tracking-wide truncate">
              Skill দেখাও, Prize জিতো।
            </p>
          </div>

          {/* CUSTOMER SUPPORT BOX */}
          <div className="mb-5 bg-[#141722] border border-[#242835]/40 rounded-3xl p-5 flex items-center justify-between shadow-md shadow-slate-950/20">
            <div className="flex flex-col">
              <span className="text-[11px] text-slate-400 font-bold block mb-1">
                Need any help?
              </span>
              <span className="text-base font-black text-white uppercase tracking-wide">
                Customer Support
              </span>
            </div>
            <button 
              onClick={() => {
                window.open("https://wa.me/8801726471689", "_blank");
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-[#2d82fe] hover:bg-[#1a73e8] text-white font-black text-xs uppercase tracking-wider rounded-xl transition-all active:scale-95 duration-100 cursor-pointer shadow-lg shadow-blue-500/10"
            >
              <Headphones className="h-4 w-4 stroke-[2.5]" />
              <span>Contact</span>
            </button>
          </div>

          <div className="flex justify-between items-center mb-3">
            <h3 className="text-white text-base font-black uppercase tracking-wider flex items-center gap-1.5">
              Game Modes
            </h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {categories.filter(c => c !== "All").map((mode) => {
              const liveCount = matches.filter(m => m.type === mode && m.status === "upcoming").length;
              return (
                <div
                  key={mode}
                  onClick={() => onSelectCategory(mode)}
                  className="relative h-36 rounded-3xl overflow-hidden group cursor-pointer border border-[#242835]/40 bg-[#141722] transition-all duration-300 hover:border-indigo-600/60 active:scale-95 shadow-md shadow-slate-950/25"
                >
                  <img
                    src={(() => {
                      const norm = mode.toUpperCase();
                      if (norm.includes("BR SOLO") || norm === "SOLO") return "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400";
                      if (norm.includes("BR DUO") || norm === "DUO") return "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=400";
                      if (norm.includes("SURVIVAL") || norm.includes("BR SURVIVAL") || norm.includes("SQUAD")) return "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&q=80&w=400";
                      if (norm.includes("CS [2V2]") || norm.includes("2V2")) return "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=400";
                      if (norm.includes("CLASH SQUAD") || norm.includes("CS-RANKED") || norm.includes("CS")) return "https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&q=80&w=400";
                      if (norm.includes("LONE WOLF") || norm.includes("LONE")) return "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=400";
                      if (norm.includes("LUDO")) return "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&q=80&w=400";
                      return "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400";
                    })()}
                    alt={mode}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
                  />
                  {/* Black bottom gradient to match the exact aesthetic screenshot */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/25 to-transparent" />
                  
                  {/* Translucent circle card selector icon as screenshot */}
                  <div className="absolute top-3 right-3 h-7 w-7 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-white/80 backdrop-blur-xs group-hover:bg-white/15 group-hover:text-white transition-all">
                    <ChevronRight className="h-4 w-4" />
                  </div>

                  {/* Brand dynamic details */}
                  <div className="absolute bottom-3 left-3 right-3 flex flex-col items-start leading-none">
                    <span className="text-white text-xs md:text-sm font-black tracking-wider uppercase drop-shadow-md">
                      {mode}
                    </span>
                    {liveCount > 0 ? (
                      <div className="mt-2 flex items-center gap-1 px-2 py-0.5 rounded-full border border-emerald-500/20 bg-emerald-950/40 text-[9px] font-black uppercase text-emerald-400 tracking-wider">
                        <span className="h-1 w-1 rounded-full bg-emerald-400 animate-pulse" />
                        {liveCount} Live
                      </div>
                    ) : (
                      <div className="mt-2 flex items-center gap-1 px-2 py-0.5 rounded-full border border-slate-700/20 bg-slate-900/40 text-[9px] font-black uppercase text-slate-400 tracking-wider">
                        <span className="h-1 w-1 rounded-full bg-slate-500" />
                        No Live
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* FILTER ACTIVE SLEEK BACK BAR */}
      {selectedCategory !== "All" && (
        <div className="px-4 py-1.5 select-none animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between shadow-md">
            <span className="text-[11px] text-slate-200 font-black uppercase tracking-widest flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 animate-ping" />
              Mode: {selectedCategory}
            </span>
            <button
              onClick={() => onSelectCategory("All")}
              className="text-[9.5px] font-black text-rose-450 hover:text-rose-400 transition-all uppercase tracking-wider cursor-pointer flex items-center gap-1 bg-rose-950/20 border border-rose-900/30 px-2.5 py-1 rounded-lg hover:bg-rose-900/40"
            >
              ✖ All Game Modes
            </button>
          </div>
        </div>
      )}

      {/* MATCHES GRID: SHOW ONLY WHEN A SPECIFIC SEGMENT/GAME MODE IS CHOSEN */}
      {selectedCategory !== "All" && (
        <div className="px-4">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-slate-800 text-sm md:text-base font-bold tracking-tight">
              Live & Upcoming Matches
            </h3>
            <span className="text-[11px] font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded">
              {filteredMatches.length} Matches Available
            </span>
          </div>

          {filteredMatches.length === 0 ? (
            <div className="bg-[#141722] rounded-3xl border border-[#242835] p-10 text-center flex flex-col items-center justify-center shadow-xl shadow-slate-950/40 select-none animate-fade-in">
              <div className="relative h-16 w-16 rounded-full border border-rose-500/20 bg-rose-950/40 flex items-center justify-center text-rose-500 mb-4 animate-bounce">
                <span className="absolute inset-0 rounded-full bg-rose-500/10 animate-ping" />
                <Coins className="h-7 w-7" />
              </div>
              <h4 className="text-white text-base font-black tracking-widest uppercase">No Live Match Available</h4>
              <p className="text-slate-400 text-xs mt-2 font-medium max-w-xs leading-relaxed">
                Currently, there are no live or upcoming matches scheduled for <span className="text-indigo-400 font-bold">{selectedCategory}</span>. Please check back later or explore other modes!
              </p>
              <button
                onClick={() => onSelectCategory("All")}
                className="mt-6 text-[10.5px] font-black uppercase tracking-wider text-rose-400 bg-rose-950/30 border border-rose-900/40 px-5 py-2.5 rounded-2xl hover:bg-rose-900/50 active:scale-95 transition-all cursor-pointer"
              >
                Go Back to All Modes
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-2">
              {filteredMatches.map((m) => {
                const progressPercentage = Math.min((m.joined / m.total) * 100, 100);
                const isFull = m.joined >= m.total;
                const isJoined = joinedMatchIds.includes(m.id);

                // Formulate beautiful human dates
                let rawDate = new Date();
                if (m.startTime) {
                  if (m.startTime.seconds) {
                    rawDate = new Date(m.startTime.seconds * 1000);
                  } else {
                    rawDate = new Date(m.startTime);
                  }
                }
                const formattedDateStr = rawDate.toLocaleDateString("en-US", {
                  day: "2-digit",
                  month: "short",
                  year: "numeric"
                });
                const formattedTimeStr = rawDate.toLocaleTimeString("en-US", {
                  hour: "2-digit",
                  minute: "2-digit",
                  hour12: true
                });

                // 4-digit code helper
                const matchShortId = m.id ? (m.id.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) % 9000 + 1000) : "8568";

                return (
                  <div
                    key={m.id}
                    id={`match-card-${m.id}`}
                    onClick={() => setSelectedMatch(m)}
                    className="bg-[#141722] rounded-3xl overflow-hidden border border-[#242835] flex flex-col relative group transition-all duration-300 shadow-xl shadow-slate-950/40 cursor-pointer"
                  >
                    {/* Top graphic header - absolute precision overlay */}
                    <div className="h-56 relative overflow-hidden bg-slate-950">
                      <img
                        src={m.img || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600"}
                        alt={m.title}
                        className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                      />
                      {/* Gradient to match exact screenshot */}
                      <div className="absolute inset-0 bg-gradient-to-t from-[#141722] via-[#141722]/35 to-transparent" />

                      {/* Text details overlay inside graphic */}
                      <div className="absolute inset-0 p-5 flex flex-col justify-end">
                        <h4 className="text-white text-xl md:text-2xl font-black tracking-wide uppercase drop-shadow-md leading-tight">
                          {m.title || `${m.type} Tournament`}
                        </h4>
                        
                        <div className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-350 font-extrabold uppercase tracking-widest leading-none drop-shadow-sm">
                          <span className="text-[#2d82fe]">{m.type}</span>
                          <span>•</span>
                          <span>{m.teamMode?.toUpperCase() || "SOLO"}</span>
                        </div>

                        <div className="mt-2.5 flex items-center gap-2">
                          <span className="bg-black/40 backdrop-blur-md px-3 py-1 rounded-lg text-[10px] text-slate-300 font-extrabold tracking-widest uppercase border border-slate-700/30">
                            MATCH ID: {matchShortId}
                          </span>
                        </div>

                        {/* Amber date clock row */}
                        <div className="mt-3.5 flex items-center gap-2 text-amber-500 font-bold drop-shadow-sm text-[12.5px] uppercase tracking-wide">
                          <Calendar className="h-4.5 w-4.5 shrink-0 text-amber-500" />
                          <span>{formattedDateStr}, {formattedTimeStr}</span>
                        </div>
                      </div>
                    </div>

                    {/* Body Content */}
                    <div className="p-5 flex-1 flex flex-col justify-between text-slate-200 bg-[#141722]">
                      {/* Column block icons Row */}
                      <div className="grid grid-cols-3 gap-2 text-center py-2.5 border-b border-[#242835]/40 mb-3 text-slate-300">
                        <div className="flex items-center justify-center gap-1.5 text-xs md:text-sm font-semibold">
                          <Map className="h-4 w-4 text-slate-400 shrink-0" />
                          <span className="truncate">{m.map}</span>
                        </div>
                        <div className="flex items-center justify-center gap-1.5 text-xs md:text-sm font-semibold">
                          <Users className="h-4 w-4 text-slate-400 shrink-0" />
                          <span>{m.teamMode || "Solo"}</span>
                        </div>
                        <div className="flex items-center justify-center gap-1.5 text-xs md:text-sm font-semibold">
                          <Smartphone className="h-4 w-4 text-slate-400 shrink-0" />
                          <span>{m.platform || "MOBILE"}</span>
                        </div>
                      </div>

                      {/* Pricing matrix block */}
                      <div className="grid grid-cols-3 gap-2.5 text-center mb-4 pt-1.5">
                        <div>
                          <div className="text-[10px] text-slate-450 font-bold uppercase tracking-wider mb-1">Prize Pool</div>
                          <div className="text-xl md:text-2xl font-black text-white">৳{m.prize}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-450 font-bold uppercase tracking-wider mb-1">Per Kill</div>
                          <div className="text-xl md:text-2xl font-black text-white font-mono">৳{m.perKill !== undefined ? m.perKill : 7}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-450 font-bold uppercase tracking-wider mb-1">Entry Fee</div>
                          <div className="text-xl md:text-2xl font-black text-white">৳{Number(m.fee).toFixed(2)}</div>
                        </div>
                      </div>

                      <div className="border-t border-[#242835]/30 pt-4 mb-4">
                        {/* Spots Left */}
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex flex-col">
                            <span className="text-[12px] text-slate-455 font-bold tracking-wide uppercase">Spots Left</span>
                            {/* "Need Players" custom amber indicator */}
                            {m.total - m.joined > 0 && (
                              <span className="mt-1.5 w-max px-2 py-0.5 text-[10px] font-black tracking-wider text-amber-500 bg-amber-500/5 rounded-lg border border-amber-500/20 uppercase">
                                {m.total - m.joined} Need Players
                              </span>
                            )}
                          </div>

                          <div className="text-right">
                            <span className="text-sm font-black text-white">{m.joined}/{m.total}</span>
                          </div>
                        </div>

                        {/* Flexbox container for dynamic slider + green join key */}
                        <div className="flex items-center justify-between gap-4 mt-3">
                          <div className="flex-1">
                            {/* Thin slider matching image */}
                            <div className="w-full bg-[#1e2333]/80 rounded-full h-2 overflow-hidden border border-[#242835]/30">
                              <div
                                className="h-full rounded-full bg-blue-600 shadow-sm shadow-blue-500/50"
                                style={{ width: `${progressPercentage}%` }}
                              />
                            </div>
                          </div>

                          <button
                            id={`btn-join-${m.id}`}
                            disabled={isFull || isJoined}
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenJoin(m);
                            }}
                            className={`px-7 py-2.5 rounded-xl text-[13px] font-black tracking-widest uppercase transition-all duration-200 cursor-pointer text-center select-none ${
                              isJoined
                                ? "bg-indigo-950/60 text-indigo-400 cursor-not-allowed border border-indigo-500/20"
                                : isFull
                                ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                                : "bg-[#008744] hover:bg-[#007038] text-white active:scale-[0.97] hover:shadow-lg shadow-emerald-950/30"
                            }`}
                          >
                            {isJoined ? "Joined" : isFull ? "Closed" : "Join"}
                          </button>
                        </div>
                      </div>

                      {/* 4 Action Buttons in a responsive grid */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                        {/* Room Details */}
                        <button
                          id={`btn-room-details-${m.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenRoomDetails(m);
                          }}
                          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-blue-500/40 bg-blue-950/20 hover:bg-blue-900/30 cursor-pointer transition-all active:scale-95 duration-150"
                        >
                          <CircleAlert className="h-4.5 w-4.5 text-blue-400 mb-1" />
                          <span className="text-[10px] font-bold text-slate-200 whitespace-nowrap uppercase tracking-wider">Room Details</span>
                        </button>

                        {/* Match Rules */}
                        <button
                          id={`btn-rules-details-${m.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenRulesDetails(m);
                          }}
                          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-emerald-500/40 bg-emerald-950/20 hover:bg-emerald-900/30 cursor-pointer transition-all active:scale-95 duration-150"
                        >
                          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-400 mb-1" />
                          <span className="text-[10px] font-bold text-emerald-400 whitespace-nowrap uppercase tracking-wider">Match Rules</span>
                        </button>

                        {/* Slot Details */}
                        <button
                          id={`btn-slot-details-${m.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenSlotsDetails(m);
                          }}
                          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-slate-500/40 bg-slate-900/20 hover:bg-slate-800/30 cursor-pointer transition-all active:scale-95 duration-150"
                        >
                          <LayoutGrid className="h-4.5 w-4.5 text-slate-300 mb-1" />
                          <span className="text-[10px] font-bold text-slate-200 whitespace-nowrap uppercase tracking-wider">Slot Details</span>
                        </button>

                        {/* Prize Details */}
                        <button
                          id={`btn-prize-details-${m.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenPrizeDetails(m);
                          }}
                          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-[#d97706]/40 bg-[#c27c13]/10 hover:bg-[#c27c13]/25 cursor-pointer transition-all active:scale-95 duration-150"
                        >
                          <Trophy className="h-4.5 w-4.5 text-[#f59e0b] mb-1" />
                          <span className="text-[10px] font-bold text-amber-400 whitespace-nowrap uppercase tracking-wider">Prize Details</span>
                        </button>
                      </div>

                      {/* Wide Block Countdown Bar at bottom exact match */}
                      <CountdownBar targetTime={m.startTime} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* CORE WORKING MODAL OVERLAYS */}
      {activeModalMatch && activeModalType && (
        <div className="fixed inset-0 z-45 flex items-end justify-center sm:items-center p-0 sm:p-4 animate-fade-in font-sans">
          <div
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
            onClick={() => {
              setActiveModalMatch(null);
              setActiveModalType(null);
            }}
          />
          <div className="bg-[#0b0c10] border-t sm:border border-slate-800/80 w-full sm:max-w-md rounded-t-[32px] sm:rounded-3xl max-h-[92vh] overflow-y-auto p-5 relative z-10 animate-slide-up pb-10 text-slate-100">
            
            {/* Red Bordered Cross Close Button overlapping top-right of the modal card */}
            <button
              onClick={() => {
                setActiveModalMatch(null);
                setActiveModalType(null);
              }}
              className="absolute -top-3.5 right-4 sm:-top-4 sm:-right-4 p-1.5 bg-[#0b0c10] border-2 border-rose-500 rounded-full shadow-[0_0_15px_rgba(239,68,68,0.45)] cursor-pointer text-white hover:bg-rose-950 transition-all active:scale-95 z-50 flex items-center justify-center"
            >
              <X className="h-4.5 w-4.5 text-white" />
            </button>

            {/* Header / Action Bar with custom titles */}
            <div className="flex justify-between items-center pb-4 border-b border-slate-800/50 mb-5 text-left sticky top-0 bg-[#0b0c10]/95 backdrop-blur-md z-1">
              <div className="flex items-center gap-2.5">
                {activeModalType === "room" && (
                  <div className="bg-blue-500/10 p-2 text-blue-400 rounded-full flex items-center justify-center shrink-0">
                    <Unlock className="h-5 w-5" />
                  </div>
                )}
                {activeModalType === "rules" && (
                  <div className="bg-[#10b981]/15 p-2 text-[#10b981] rounded-full flex items-center justify-center shrink-0">
                    <CheckCircle2 className="h-5 w-5" />
                  </div>
                )}
                {activeModalType === "slot" && (
                  <div className="bg-indigo-500/10 p-2 text-indigo-400 rounded-full flex items-center justify-center shrink-0">
                    <Users className="h-5 w-5" />
                  </div>
                )}
                {activeModalType === "prize" && (
                  <div className="bg-amber-500/15 p-2.5 text-amber-500 rounded-full flex items-center justify-center shrink-0">
                    <Trophy className="h-5 w-5" />
                  </div>
                )}
                <div>
                  <h3 className="text-[17px] font-black text-white leading-none">
                    {activeModalType === "room" && "Room Details"}
                    {activeModalType === "rules" && "Match Rules"}
                    {activeModalType === "slot" && "Participants"}
                    {activeModalType === "prize" && "Prize Pool"}
                  </h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase mt-1 tracking-wider">
                    {activeModalMatch.title}
                  </p>
                </div>
              </div>
              
              {activeModalType === "slot" && (
                <span className="bg-[#10b981]/15 border border-[#10b981]/25 text-[#10b981] text-[10.5px] font-bold px-3 py-1.5 rounded-full select-none">
                  {(activeModalMatch.total || 48) - (activeModalMatch.joined || 0)} Slots Left
                </span>
              )}
            </div>

            {/* Modal Contents matching specified layouts */}
            {activeModalType === "room" && (
              <div className="space-y-4">
                {joinedMatchIds.includes(activeModalMatch.id) ? (
                  activeModalMatch.roomId && activeModalMatch.roomPass ? (
                    <div className="space-y-4 text-left">
                      <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 text-center">
                        <span className="text-[11px] text-[#10b981] font-black uppercase tracking-wider block mb-1">
                          রুম আইডি এবং পাসওয়ার্ড তৈরি
                        </span>
                        <span className="text-xs font-semibold text-slate-300 block leading-relaxed">
                          রুম আইডি এবং পাসওয়ার্ড পেয়ে গেছেন! দ্রুত ফ্রি ফায়ার অ্যাপে গিয়ে কাস্টম রুমে জয়েন করুন।
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3">
                        <div
                          onClick={() => handleCopy(activeModalMatch.roomId || "")}
                          className="bg-[#121620] border border-slate-800 rounded-2xl p-4 text-center cursor-pointer hover:bg-slate-900 transition active:scale-95"
                        >
                          <div className="text-[10px] text-slate-450 font-extrabold uppercase tracking-wider">রুম আইডি (ROOM ID)</div>
                          <div className="text-white font-mono font-black text-base mt-1.5">{activeModalMatch.roomId}</div>
                          <div className="text-[9.5px] text-blue-500 font-black mt-1.5 uppercase tracking-wide flex items-center justify-center gap-1">
                            <Copy className="h-3 w-3" /> কপি রুম আইডি
                          </div>
                        </div>
                        <div
                          onClick={() => handleCopy(activeModalMatch.roomPass || "")}
                          className="bg-[#121620] border border-slate-800 rounded-2xl p-4 text-center cursor-pointer hover:bg-[#121620]/70 transition active:scale-95"
                        >
                          <div className="text-[10px] text-slate-450 font-extrabold uppercase tracking-wider">পাসওয়ার্ড (PASSWORD)</div>
                          <div className="text-white font-mono font-black text-base mt-1.5">{activeModalMatch.roomPass}</div>
                          <div className="text-[9.5px] text-blue-400 font-black mt-1.5 uppercase tracking-wide flex items-center justify-center gap-1">
                            <Copy className="h-3 w-3" /> কপি পাসওয়ার্ড
                          </div>
                        </div>
                      </div>

                      <div className="bg-amber-500/5 border border-amber-500/15 p-3.5 rounded-xl text-[10.5px] text-amber-500/90 leading-relaxed font-semibold">
                        ⚠️ আইডি এবং পাসওয়ার্ড কপি করে ফ্রি ফায়ারে কাস্টম রুমে সার্চ করে আপনার বরাদ্দকৃত স্লটে জয়েন করুন। অন্য কোনো স্লটে বসবেন না!
                      </div>
                    </div>
                  ) : (
                    <div className="bg-[#0e111a] border border-slate-800 rounded-2xl p-6 text-center space-y-4">
                      <Lock className="h-10 w-10 text-indigo-400 mx-auto animate-pulse" />
                      <h4 className="text-[15px] font-black text-white">রুম আইডি লক করা আছে</h4>
                      <p className="text-[11.5px] text-slate-300 leading-relaxed max-w-xs mx-auto font-medium">
                        আপনার এন্ট্রি সম্পূর্ণরূপে সফল হয়েছে! ম্যাচ শুরুর ঠিক ১০ থেকে ১৫ মিনিট আগে রুম আইডি এবং পাসওয়ার্ড এখানে দেওয়া হবে। দয়া করে লক্ষ্য রাখুন!
                      </p>
                      <div className="bg-amber-500/5 border border-amber-500/25 rounded-xl py-2.5 px-4 text-center mt-2">
                        <span className="text-[11px] text-[#facc15] font-black block">
                          রুমের তথ্য প্রকাশের সম্ভাব্য সময়: {getReleaseTimeStr(activeModalMatch.startTime)}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 justify-center text-slate-400 font-mono font-bold text-xs pt-1.5 border-t border-slate-800/30">
                        <Timer className="h-3.5 w-3.5 text-indigo-400" />
                        <Countdown targetTime={activeModalMatch.startTime} />
                      </div>
                    </div>
                  )
                ) : (
                  <div className="space-y-4">
                    {/* Visual warning box matching Screenshot 3 */}
                    <div className="bg-[#1c1216] border border-rose-500/20 py-8 px-6 rounded-[22px] flex flex-col justify-center items-center text-center space-y-4 shadow-[0_4px_25px_rgba(239,68,68,0.02)]">
                      <div className="h-14 w-14 rounded-full bg-rose-500/10 border-2 border-rose-500/80 flex items-center justify-center text-rose-500 text-3xl font-black">
                        !
                      </div>
                      <span className="text-[15.5px] font-black text-slate-200 block leading-tight">
                        রুমের বিস্তারিত দেখতে আগে রেজিস্ট্রেশন সম্পন্ন করুন।
                      </span>
                    </div>

                    {/* Countdown below warning container */}
                    <div className="flex items-center gap-2 justify-center text-slate-400 font-mono font-bold text-xs pt-1">
                      <Timer className="h-3.5 w-3.5 text-rose-500 shrink-0" />
                      <Countdown targetTime={activeModalMatch.startTime} />
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeModalType === "slot" && (() => {
              const isJoined = joinedMatchIds.includes(activeModalMatch.id);
              const registrars: string[] = [];

              const authenticGamerNames = [
                "TDEzoro69",
                "TNX_SHADOW",
                "Ⓥ. I TZ ◌͜͡ S U P A N ⁀",
                "TM ◌͜͡ L I D E R ⁀",
                "☣️DEMON,LORD☠️",
                "MF&Rafim",
                "MR DARK FOX",
                "Alpha_Mamba",
                "SABBIR_YT",
                "Baki_Hanma",
                "PRO_ANUP",
                "RAIYANKING",
                "HEADSHOT_DADA",
                "SniperBangla"
              ];

              if (isJoined && userData) {
                registrars.push(userData.gameName || userData.appName || "You");
              }

              const desiredCount = activeModalMatch.joined || 0;
              for (let i = registrars.length; i < desiredCount; i++) {
                const nameIndex = (activeModalMatch.id.charCodeAt(0) + i) % authenticGamerNames.length;
                registrars.push(authenticGamerNames[nameIndex]);
              }

              const registryList = registrars.slice(0, desiredCount);

              return (
                <div className="space-y-4 text-left">
                  <div className="bg-[#0c101c] border border-slate-800/80 rounded-2xl p-4 max-h-[340px] overflow-y-auto space-y-2.5 scrollbar-thin">
                    {registryList.map((name, index) => {
                      const isCurrentUser = userData && (name === userData.gameName || name === userData.appName);
                      return (
                        <div
                          key={index}
                          className={`flex items-center p-3.5 bg-[#141722] border rounded-[16px] transition duration-150 ${
                            isCurrentUser ? "border-indigo-500 bg-indigo-950/20" : "border-slate-800/60"
                          }`}
                        >
                          <span className="h-7 w-7 rounded-full bg-[#1c2235] text-blue-400 font-bold font-mono text-xs flex items-center justify-center shrink-0 mr-3.5">
                            {index + 1}
                          </span>
                          <span className={`text-[13px] font-black uppercase font-sans tracking-wide truncate ${
                            isCurrentUser ? "text-indigo-300 font-extrabold" : "text-slate-100"
                          }`}>
                            {name} {isCurrentUser && <span className="text-[10px] text-indigo-400 font-normal lowercase">(You)</span>}
                          </span>
                        </div>
                      );
                    })}

                    {registryList.length === 0 && (
                      <div className="text-center py-8">
                        <span className="text-3xl block filter opacity-45">👥</span>
                        <p className="text-[11px] text-[#facc15] font-semibold mt-2">ম্যাচে এখনও কেউ জয়েন করেনি। প্রথম প্লেয়ার হিসেবে জয়েন করুন!</p>
                      </div>
                    )}
                  </div>

                  <div className="bg-slate-900/40 p-3.5 rounded-xl border border-slate-800/40 text-[10px] text-slate-450 leading-relaxed text-center font-bold">
                    নিবন্ধিত প্লেয়ারদের উপরে তালিকাভুক্ত করা হয়েছে। কাস্টম রুমে কেবল এই নামগুলোর প্লেয়ারদের এলাউ করা হবে।
                  </div>
                </div>
              );
            })()}

            {activeModalType === "rules" && (
              <div className="space-y-4 text-left font-sans">
                <div className="bg-[#10b981]/5 border border-[#10b981]/15 p-4 rounded-xl space-y-1">
                  <h4 className="text-xs font-black text-[#10b981] uppercase tracking-widest flex items-center gap-1.5">
                    📢 কাস্টম ম্যাচ গুরুত্বপূর্ণ নিয়মাবলী
                  </h4>
                  <p className="text-[11px] text-slate-300 font-medium font-sans">
                    যেকোনো পেমেন্ট বা পয়েন্ট ভেরিফিকেশনের জন্য নিচের কড়া নিয়মগুলো মেনে চলতে হবে। কোনো নিয়ম ভঙ্গ করলে পুরস্কার দেওয়া হবে না।
                  </p>
                </div>

                <div className="bg-[#0c101c] border border-slate-800/80 rounded-2xl p-4 max-h-[280px] overflow-y-auto leading-relaxed space-y-3.5 text-xs text-slate-200">
                  <div className="space-y-2">
                    <p className="font-extrabold text-[#f39c12]">১। নো এমুলেটর পলিসি (Mobile Only):</p>
                    <p className="text-slate-300 pl-4 text-[11px] leading-relaxed">
                      ম্যাচে অংশগ্রহণকারী সকল প্লেয়ারদের অবশ্যই মোবাইল ডিভাইস ব্যবহার করে খেলতে হবে। কোনো প্রকার পিসি, ট্যাব অথবা এমুলেটর এলাউড নয়। কাস্টম রুমে এমুলেটর ম্যাচ ডিটেক্ট হলে তাৎক্ষণিক ব্যান দেওয়া হতে পারে।
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-extrabold text-[#f39c12]">২। অ্যান্টি-হ্যাক ও ফেয়ার প্লে নিয়ম:</p>
                    <p className="text-slate-300 pl-4 text-[11px] leading-relaxed">
                      গেম ফাইলের কোনো থার্ড-পার্টি পরিবর্তন, হ্যাক অথবা অন্যান্য স্কোয়াডের প্লেয়ারের সাহায্য নেওয়া সম্পূর্ণ নিষিদ্ধ। হ্যাক সনাক্ত হলে অ্যাকাউন্ট সরাসরি সাময়িক বা স্থায়ী স্থগিতাদেশে সাবমিট করা হবে।
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-extrabold text-[#f39c12]">৩। কাস্টম রুম ও বরাদ্দ স্লট:</p>
                    <p className="text-slate-300 pl-4 text-[11px] leading-relaxed">
                      ম্যাচ শুরুর ঠিক ৫-১০ মিনিট আগে রুম পেয়ে জয়েন করবেন। সর্বদা গেমের নির্ধারিত সময় মাথায় রাখবেন এবং আইডি অনুযায়ী নিজে বরাদ্দকৃত সঠিক স্লটে বসবেন। অন্যজনের স্লট বুক বা দখল করলে হোস্ট দ্বারা কিক আউট হবেন।
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-extrabold text-[#f39c12]">৪। স্ক্রিনশট এবং রেওয়ার্ড সাবমিশন (বাধ্যতামূলক):</p>
                    <p className="text-slate-300 pl-4 text-[11px] leading-relaxed">
                      Booyah বিজয়ের পর অবশ্যই পুরো স্ক্রিনের একটি বিজয়ের শেষ স্ক্রিনশট (Victory Screenshot) ফাইল সেভ রাখবেন। কোনো প্রকার বিরোধ বা পেমেন্ট সংক্রান্ত ঝামেলার ক্ষেত্রে স্ক্রিনশট পেশ করা বাধ্যতামূলক।
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900/40 p-3.5 rounded-xl border border-slate-800/40 text-[10px] text-slate-400 leading-relaxed text-center font-bold max-w-xs mx-auto">
                  ফেয়ার বা ন্যায্য গেমপ্লে বজায় রাখতে আমাদের সাথে সহযোগিতা করুন এবং পুরস্কার উপভোগ করুন।
                </div>
              </div>
            )}

            {activeModalType === "prize" && (
              <div className="space-y-4 text-left font-sans">
                {/* Glowing Premium Orange total prize card matching Screenshot 1 */}
                <div className="bg-gradient-to-r from-[#f59e0b] to-[#ea580c] rounded-[22px] p-5 shadow-[0_4px_25px_rgba(245,158,11,0.15)] flex justify-between items-center relative overflow-hidden select-none">
                  <div className="flex items-center gap-3">
                    <Trophy className="h-6.5 w-6.5 text-white/95" />
                    <span className="text-[15.5px] font-black text-white tracking-wide uppercase">
                      Total Prize Pool
                    </span>
                  </div>
                  <span className="text-3xl font-black text-white block tracking-tight">
                    ৳{activeModalMatch.prize}
                  </span>
                </div>

                {/* Fire red multi per kill card matching Screenshot 1 */}
                <div className="bg-[#241315] border border-rose-500/15 rounded-[18px] p-4.5 flex justify-between items-center select-none">
                  <div className="flex items-center gap-2">
                    <span className="text-rose-500 text-lg">🔥</span>
                    <span className="text-[13px] font-bold text-rose-350 uppercase tracking-wide">
                      Per Kill
                    </span>
                  </div>
                  <span className="text-xl font-black text-rose-500">
                    ৳{activeModalMatch.perKill || 7}
                  </span>
                </div>

                {/* Centered POSITIONS line separator matching Screenshot 1 */}
                <div className="flex items-center my-4">
                  <div className="flex-1 h-[1px] bg-slate-800/80"></div>
                  <span className="px-4 text-[10px] text-slate-500 font-extrabold uppercase tracking-widest leading-none">
                    Positions
                  </span>
                  <div className="flex-1 h-[1px] bg-slate-800/80"></div>
                </div>

                {/* Sub positions cards with design corresponding to Screenshot 1 */}
                <div className="space-y-2.5 max-h-[250px] overflow-y-auto pr-1">
                  <div className="flex justify-between items-center bg-[#121620] border border-slate-800/80 rounded-[16px] p-4 hover:border-amber-500/30 transition">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">👑</span>
                      <span className="text-[13px] font-bold text-slate-100">Winner (Booyah)</span>
                    </div>
                    <span className="font-black text-amber-500 text-sm">
                      ৳{activeModalMatch.prize}
                    </span>
                  </div>

                  <div className="flex justify-between items-center bg-[#121620] border border-slate-800/80 rounded-[16px] p-4 hover:border-blue-500/30 transition">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">🥈</span>
                      <span className="text-[13px] font-bold text-slate-200">Position 2</span>
                    </div>
                    <span className="font-extrabold text-slate-350 text-sm">
                      ৳{Math.round(activeModalMatch.prize * 0.65)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center bg-[#121620] border border-slate-800/80 rounded-[16px] p-4 hover:border-orange-500/30 transition">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">🥉</span>
                      <span className="text-[13px] font-bold text-slate-200">Position 3</span>
                    </div>
                    <span className="font-extrabold text-slate-350 text-sm">
                      ৳{Math.round(activeModalMatch.prize * 0.45)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center bg-[#121620] border border-slate-800/80 rounded-[16px] p-4">
                    <div className="flex items-center gap-3">
                      <span className="text-sm">🎖️</span>
                      <span className="text-[13px] font-bold text-slate-300">Position 4</span>
                    </div>
                    <span className="font-extrabold text-slate-400 text-sm">
                      ৳{Math.round(activeModalMatch.prize * 0.3)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center bg-[#121620] border border-slate-800/80 rounded-[16px] p-4">
                    <div className="flex items-center gap-3">
                      <span className="text-sm">🎖️</span>
                      <span className="text-[13px] font-bold text-slate-300">Position 5</span>
                    </div>
                    <span className="font-extrabold text-slate-400 text-sm">
                      ৳{Math.round(activeModalMatch.prize * 0.2)}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

