import React, { useState } from "react";
import { Transaction, UserData } from "../types";
import { 
  Plus, 
  ArrowDown, 
  Gift, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowLeft, 
  Trophy, 
  Play, 
  X, 
  ExternalLink 
} from "lucide-react";

interface WalletViewProps {
  userData: UserData | null;
  transactions: Transaction[];
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
  onOpenTransfer: () => void;
  onOpenSupport: () => void;
  onBack?: () => void;
  onViewAllTransactions?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  userData,
  transactions,
  onOpenDeposit,
  onOpenWithdraw,
  onOpenTransfer,
  onOpenSupport,
  onBack,
  onViewAllTransactions,
}) => {
  const [activeTutorial, setActiveTutorial] = useState<{
    title: string;
    banglaTitle: string;
    steps: string[];
    ytQuery: string;
  } | null>(null);

  const handleShowTutorial = (type: "deposit" | "withdraw" | "gift") => {
    let tutorialInfo = {
      title: "",
      banglaTitle: "",
      steps: [] as string[],
      ytQuery: ""
    };

    if (type === "deposit") {
      tutorialInfo = {
        title: "How to Deposit Money",
        banglaTitle: "কিভাবে টাকা ডিপোজিট করবেন?",
        steps: [
          "১. 'Deposit' বাটনে চাপ দিন।",
          "২. এডমিনদের BKash অথবা Nagad নম্বরটি কপি করুন।",
          "৩. আপনার নিজস্ব পার্সোনাল ওয়ালেট থেকে ক্যাশ আউট বা সেন্ডমানি সম্পন্ন করুন।",
          "৪. ট্রানজেকশন আইডি এবং টাকা পাঠানোর পরিমাণটি অ্যাপে সাবমিট করে ভেরিফাই করুন।"
        ],
        ytQuery: "how+to+deposit+bkash+nagad+game+tournament"
      };
    } else if (type === "withdraw") {
      tutorialInfo = {
        title: "How to Withdraw Money",
        banglaTitle: "কিভাবে টাকা উঠাবেন বা উইথড্র করবেন?",
        steps: [
          "১. 'Withdraw' বাটনে চাপ দিন।",
          "২. আপনার কাঙ্ক্ষিত ওয়ালেট মেথড সিলেক্ট করুন (যেমন: bKash, Nagad)।",
          "৩. আপনার কাঙ্ক্ষিত উইথড্র এমাউন্ট এবং পার্সোনাল নম্বরটি সঠিকভাবে টাইপ করুন।",
          "৪. উইথড্র রিকুয়েস্ট সফল হলে ২৪ ঘণ্টার মধ্যে এডমিন আপনার বিকাশ/নগদে টাকা পাঠিয়ে দিবে।"
        ],
        ytQuery: "how+to+withdraw+bkash+nagad+game+tournament"
      };
    } else {
      tutorialInfo = {
        title: "How to Send gift to Friends",
        banglaTitle: "কিভাবে বন্ধুকে গিফট পাঠাবেন?",
        steps: [
          "১. 'Gift' বা ট্রান্সফার বাটনে চাপ দিন।",
          "২. আপনার বন্ধুর UID (ইউনিক আইডি) প্রবেশ করুন এবং পাশে 'Verify' ক্লিক করুন।",
          "৩. গিফট এমাউন্ট এবং সাথে একটি সুন্দর শুভেচ্ছা বার্তা লিখুন।",
          "৪. আপনার অ্যাপ সিকিউরিটি পিন দিয়ে কনফার্ম করুন, সেকেন্ডের মধ্যে তার ওয়ালেটে ব্যালেন্স চলে যাবে।"
        ],
        ytQuery: "how+to+transfer+gift+cash+game+tournament"
      };
    }

    setActiveTutorial(tutorialInfo);
  };

  // Safe transaction parsing
  const parseAmountDisplay = (amountStr: string) => {
    const isLoss = amountStr.includes("-") || amountStr.toLowerCase().includes("deduct") || amountStr.toLowerCase().includes("withdraw") || amountStr.toLowerCase().includes("registration");
    const cleanNum = amountStr.replace(/[+\-৳\s,BDTbdt]/g, "");
    const numValue = parseFloat(cleanNum) || 0;
    const formattedVal = `৳${numValue.toFixed(2)}`;
    return {
      isLoss,
      display: isLoss ? `-${formattedVal}` : `+${formattedVal}`
    };
  };

  const formatTransactionDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      
      return d.toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true
      });
    } catch (err) {
      return dateStr;
    }
  };

  // Display Available Balance (format as dynamic matching screenshot)
  const balanceVal = userData?.balance || 0;
  const displayAvailableBalance = balanceVal % 1 === 0 ? balanceVal.toFixed(0) : balanceVal.toFixed(2);

  const winBalanceVal = userData?.winBalance ?? 0;
  const displayWinningBalance = winBalanceVal % 1 === 0 ? winBalanceVal.toFixed(0) : winBalanceVal.toFixed(2);

  // Show only last 5 transactions for a neat quick summary
  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="w-full pb-32 bg-[#0e1015] min-h-screen text-white select-none">
      
      {/* HEADER SECTION */}
      <div className="sticky top-0 z-30 bg-[#0e1015]/95 backdrop-blur-md border-b border-[#1e2330]/85 px-4 h-16 flex items-center justify-between">
        <button
          onClick={onBack}
          className="h-10 w-10 bg-[#161a26] border border-[#242835]/45 rounded-xl flex items-center justify-center text-slate-300 hover:text-white transition-colors active:scale-95 cursor-pointer"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <span className="text-base font-black tracking-wide font-sans text-white">
          My Wallet
        </span>
        <div className="w-10 h-10" /> {/* Centering spacing spacer */}
      </div>

      <div className="max-w-md mx-auto p-4 space-y-6">
        
        {/* AVAILABLE BALANCE CONTAINER CARD (Exactly matching first screenshot) */}
        <div className="w-full bg-[#131622] rounded-3xl p-6 border border-[#242835]/45 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl mt-1">
          {/* Subtle background glow */}
          <div className="absolute top-[-40px] right-[-40px] w-36 h-36 rounded-full bg-blue-500/5 blur-xl pointer-events-none" />
          
          <span className="text-[13px] text-slate-405 font-medium tracking-wide text-center">
            Available Balance
          </span>
          <div className="text-5xl md:text-6xl font-black mt-2.5 mb-4 text-center tracking-tight text-white font-sans">
            ৳{displayAvailableBalance}
          </div>
          
          {/* Gold badge button for Winning balance */}
          <div className="mb-6">
            <div className="bg-[#cca043]/10 border border-[#cca043]/30 px-5 py-2 rounded-full inline-flex items-center justify-center gap-1.5 text-xs font-bold text-[#cca043] tracking-wide">
              <Trophy className="h-4 w-4 text-[#cca043] fill-[#cca043]/10" />
              <span>Winning Balance: ৳{displayWinningBalance}</span>
            </div>
          </div>

          {/* Icon control grid inside the main card */}
          <div className="w-full grid grid-cols-3 gap-3 pt-2">
            
            {/* Deposit Box Button */}
            <button
              onClick={onOpenDeposit}
              className="bg-[#181c2b] border border-[#242835]/30 rounded-2xl py-3.5 px-2 flex flex-col items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:border-[#2d82fe]/30"
            >
              <div className="h-10 w-10 bg-blue-500/10 border border-[#2d82fe]/20 rounded-full flex items-center justify-center text-[#2d82fe]">
                <Plus className="h-5 w-5" />
              </div>
              <span className="text-[11px] font-extrabold text-slate-300">Deposit</span>
            </button>

            {/* Withdraw Box Button */}
            <button
              onClick={onOpenWithdraw}
              className="bg-[#181c2b] border border-[#242835]/30 rounded-2xl py-3.5 px-2 flex flex-col items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:border-[#2d82fe]/30"
            >
              <div className="h-10 w-10 bg-blue-500/10 border border-[#2d82fe]/20 rounded-full flex items-center justify-center text-[#2d82fe]">
                <ArrowDown className="h-5 w-5" />
              </div>
              <span className="text-[11px] font-extrabold text-slate-300">Withdraw</span>
            </button>

            {/* Gift Box Button */}
            <button
              onClick={onOpenTransfer}
              className="bg-[#181c2b] border border-[#242835]/30 rounded-2xl py-3.5 px-2 flex flex-col items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:border-[#2d82fe]/30"
            >
              <div className="h-10 w-10 bg-blue-500/10 border border-[#2d82fe]/20 rounded-full flex items-center justify-center text-[#2d82fe]">
                <Gift className="h-5 w-5" />
              </div>
              <span className="text-[11px] font-extrabold text-slate-300">Gift</span>
            </button>

          </div>
        </div>

        {/* TUTORIALS PORTION (Exactly matching first screenshot Bengali script layout) */}
        <div className="space-y-3 pt-1">
          <h3 className="text-white text-[15px] font-extrabold tracking-wide uppercase px-0.5">
            Tutorials
          </h3>
          
          <div className="space-y-3">
            {/* Card 1 */}
            <div className="bg-[#131622] border border-[#242835]/35 rounded-2xl p-4 flex items-center justify-between shadow-md">
              <span className="text-xs md:text-sm text-slate-200 font-bold tracking-wide">
                কিভাবে টাকা ডিপোজিট করবেন?
              </span>
              <button
                onClick={() => handleShowTutorial("deposit")}
                className="bg-blue-600/10 border border-blue-500/20 text-[#2d82fe] font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:bg-blue-600/20"
              >
                <Play className="h-3.5 w-3.5 fill-[#2d82fe] text-[#2d82fe]" /> Watch
              </button>
            </div>

            {/* Card 2 */}
            <div className="bg-[#131622] border border-[#242835]/35 rounded-2xl p-4 flex items-center justify-between shadow-md">
              <span className="text-xs md:text-sm text-slate-200 font-bold tracking-wide">
                কিভাবে টাকা উঠাবেন করবেন?
              </span>
              <button
                onClick={() => handleShowTutorial("withdraw")}
                className="bg-blue-600/10 border border-blue-500/20 text-[#2d82fe] font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:bg-blue-600/20"
              >
                <Play className="h-3.5 w-3.5 fill-[#2d82fe] text-[#2d82fe]" /> Watch
              </button>
            </div>

            {/* Card 3 */}
            <div className="bg-[#131622] border border-[#242835]/35 rounded-2xl p-4 flex items-center justify-between shadow-md">
              <span className="text-xs md:text-sm text-slate-200 font-bold tracking-wide">
                কিভাবে বন্ধুকে গিফট পাঠাবেন?
              </span>
              <button
                onClick={() => handleShowTutorial("gift")}
                className="bg-blue-600/10 border border-blue-500/20 text-[#2d82fe] font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer hover:bg-blue-600/20"
              >
                <Play className="h-3.5 w-3.5 fill-[#2d82fe] text-[#2d82fe]" /> Watch
              </button>
            </div>
          </div>
        </div>

        {/* RECENT TRANSACTIONS (Exactly matching second screenshot layout) */}
        <div className="space-y-3 pt-2">
          <div className="flex justify-between items-center px-0.5">
            <h3 className="text-white text-[15px] font-extrabold tracking-wide uppercase">
              Recent Transactions
            </h3>
            {onViewAllTransactions && (
              <button
                onClick={onViewAllTransactions}
                className="text-[#2d82fe] text-xs font-black tracking-wider uppercase hover:underline cursor-pointer"
              >
                See All
              </button>
            )}
          </div>

          <div className="space-y-3">
            {recentTransactions.length === 0 ? (
              <div className="bg-[#131622] rounded-2xl border border-[#242835]/35 p-10 text-center text-slate-450 text-xs">
                No recent transaction history found in your account.
              </div>
            ) : (
              recentTransactions.map((t) => {
                const { isLoss, display } = parseAmountDisplay(t.amount);
                const formattedDate = formatTransactionDate(t.date);

                return (
                  <div
                    key={t.id}
                    className="bg-[#131622] rounded-2xl border border-[#242835]/40 p-4.5 flex items-center justify-between shadow-sm transition-all"
                  >
                    <div className="flex items-center gap-4.5">
                      {/* Stylized Circle Arrow box to match red/green vectors from screenshots */}
                      <div
                        className={`h-11 w-11 rounded-xl flex items-center justify-center text-xs border ${
                          isLoss
                            ? "bg-rose-500/10 text-rose-400 border-rose-500/20"
                            : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                        }`}
                      >
                        {isLoss ? (
                          <ArrowUpRight className="h-5.5 w-5.5" />
                        ) : (
                          <ArrowDownLeft className="h-5.5 w-5.5" />
                        )}
                      </div>

                      <div className="flex flex-col">
                        <h4 className="text-sm font-black text-white leading-tight">
                          {t.title || (isLoss ? "Registration Fee" : "Gained Balance")}
                        </h4>
                        <p className="text-[11px] text-slate-400 mt-0.5 leading-snug break-all max-w-[180px] md:max-w-[220px]">
                          {t.note || t.title}
                        </p>
                        <p className="text-[10px] text-slate-500 font-medium mt-1">
                          {formattedDate}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end">
                      <span
                        className={`text-sm md:text-base font-black tracking-wide ${
                          isLoss ? "text-rose-500" : "text-emerald-400"
                        }`}
                      >
                        {display}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>

      {/* POPUP MODAL FOR INTERACTIVE BENGALI VIDEO TUTORIALS */}
      {activeTutorial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#12141c] border border-[#242835] rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl relative animate-fade-in text-white p-6">
            <button
              onClick={() => setActiveTutorial(null)}
              className="absolute top-4 right-4 h-8 w-8 bg-[#1e2230] hover:bg-[#2c3247] transition-all rounded-full flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="flex items-center gap-3.5 mb-4 mt-1">
              <div className="h-10 w-10 bg-blue-500/10 rounded-full flex items-center justify-center text-[#2d82fe]">
                <Play className="h-5 w-5 fill-[#2d82fe]" />
              </div>
              <div>
                <h4 className="text-sm font-black text-white uppercase tracking-wider">{activeTutorial.title}</h4>
                <p className="text-xs text-slate-400 font-semibold">{activeTutorial.banglaTitle}</p>
              </div>
            </div>

            <div className="space-y-3.5 my-5">
              {activeTutorial.steps.map((step: string, idx: number) => (
                <div key={idx} className="flex gap-2 text-xs text-slate-305 font-bold leading-relaxed bg-[#1b1f2e]/40 p-3 rounded-xl border border-slate-800/20">
                  <span>{step}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-2.5 mt-2">
              <a
                href={`https://www.youtube.com/results?search_query=${activeTutorial.ytQuery}`}
                target="_blank"
                rel="noreferrer"
                className="w-full bg-[#ff0000] hover:bg-[#e00000] text-white font-extrabold text-xs py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-98 shadow-md"
              >
                <Play className="h-4 w-4 fill-white text-white" /> Watch Tutorial video
              </a>
              <button
                onClick={() => setActiveTutorial(null)}
                className="w-full bg-[#1b1f2e] text-slate-300 font-extrabold text-xs py-3.5 rounded-2xl hover:text-white transition-all cursor-pointer border border-[#242835]/40"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
