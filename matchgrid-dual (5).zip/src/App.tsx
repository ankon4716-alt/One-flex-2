import { useState, useEffect } from "react";
import { auth, db, handleFirestoreError, OperationType } from "./firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
  onAuthStateChanged,
  EmailAuthProvider,
  reauthenticateWithCredential,
} from "firebase/auth";
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  addDoc,
  query,
  orderBy,
  limit,
  arrayUnion,
  where,
  onSnapshot,
  increment,
} from "firebase/firestore";
import { CheckCircle2 } from "lucide-react";
import { UserData, Match, Transaction, AppConfig } from "./types";
import { Header } from "./components/Header";
import { FooterNav } from "./components/FooterNav";
import { Drawer } from "./components/Drawer";
import { HomeView } from "./components/HomeView";
import { MyMatchesView } from "./components/MyMatchesView";
import { LeaderboardView } from "./components/LeaderboardView";
import { WalletView } from "./components/WalletView";
import { Modals } from "./components/Modals";
import { AdminView } from "./components/AdminView";
import { ProfileView } from "./components/ProfileView";
import { StatementsView } from "./components/StatementsView";
import { AuthView } from "./components/AuthView";
import { CategoryMatchesView } from "./components/CategoryMatchesView";
import { MatchDetailView } from "./components/MatchDetailView";

export default function App() {
  // Navigation & View States
  const [activeView, setActiveView] = useState<string>("home");
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [selectedCategoryName, setSelectedCategoryName] = useState<string | null>(null);
  const [myMatchesSubTab, setMyMatchesSubTab] = useState<"upcoming" | "history">("upcoming");
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Firestore DB states
  const [appConfig, setAppConfig] = useState<AppConfig>({
    bannerUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800",
    notice: "Welcome to Ꭷɴᴇㅤꜰʟᴇx.!TUR! Join daily match segments, play with pro gamers, and cash out instant stable-coin money via Bkash & Nagad.",
    adminPhone: "01726471689",
  });
  const [categories, setCategories] = useState<string[]>(["All", "BR SOLO", "BR DUO", "BR SURVIVAL", "CS [2v2]", "CLASH SQUAD", "LONE WOLF", "Ludo"]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [matches, setMatches] = useState<Match[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [banners, setBanners] = useState<{ id: string; img: string; title: string; subtitle: string }[]>([]);

  // User States
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  // Modals Visibility
  const [showNoticeModal, setShowNoticeModal] = useState<boolean>(false);
  const [showNotifModal, setShowNotifModal] = useState<boolean>(false);
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [activeJoinMatch, setActiveJoinMatch] = useState<Match | null>(null);
  const [isAppJoiningMatch, setIsAppJoiningMatch] = useState<boolean>(false);
  const [showDepositModal, setShowDepositModal] = useState<boolean>(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState<boolean>(false);
  const [showTransferModal, setShowTransferModal] = useState<boolean>(false);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [showRoomModal, setShowRoomModal] = useState<boolean>(false);
  const [showPrizeModal, setShowPrizeModal] = useState<boolean>(false);
  const [showSlotsModal, setShowSlotsModal] = useState<boolean>(false);
  const [selectedMatchForDetails, setSelectedMatchForDetails] = useState<Match | null>(null);
  const [matchParticipants, setMatchParticipants] = useState<any[]>([]);

  // Toast Notice State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Trigger Toast Notification
  const handleToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Check login wrapper before secure clicks
  const checkLogin = (callback: () => void) => {
    if (auth.currentUser) {
      callback();
    } else {
      setShowAuthModal(true);
    }
  };

  // Direct Copy to Clipboard handler
  const handleCopyText = (text: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    handleToast("Copied to clipboard!");
  };

  // Fetch and sync all Firestore parameters
  const fetchGlobalData = async () => {
    try {
      // 1. Fetch Admin Custom Layout configuration
      const configRef = doc(db, "config", "banner");
      const configSnap = await getDoc(configRef);
      if (configSnap.exists()) {
        const d = configSnap.data();
        setAppConfig({
          bannerUrl: d.url || d.bannerUrl || appConfig.bannerUrl,
          notice: d.notice || appConfig.notice,
          adminPhone: d.bkash || d.adminPhone || appConfig.adminPhone,
          bkashPhone: d.bkashPhone || d.bkash || d.adminPhone || appConfig.adminPhone,
          nagadPhone: d.nagadPhone || d.bkash || d.adminPhone || appConfig.adminPhone,
          rocketPhone: d.rocketPhone || d.bkash || d.adminPhone || appConfig.adminPhone,
        });
        if (d.notice && d.notice.trim() !== "") {
          setShowNoticeModal(true);
        }
      } else {
        // Seed default config so it exists in Firebase
        await setDoc(configRef, {
          bannerUrl: appConfig.bannerUrl,
          notice: appConfig.notice,
          bkash: appConfig.adminPhone,
          bkashPhone: appConfig.adminPhone,
          nagadPhone: appConfig.adminPhone,
          rocketPhone: appConfig.adminPhone,
        });
      }

      // 2. Fetch Match categories
      const catSnap = await getDocs(collection(db, "categories"));
      const presetCats = ["BR SOLO", "BR DUO", "BR SURVIVAL", "CS [2v2]", "CLASH SQUAD", "LONE WOLF", "Ludo"];
      if (catSnap.empty) {
        for (const c of presetCats) {
          await addDoc(collection(db, "categories"), { name: c });
        }
        setCategories(["All", ...presetCats]);
      } else {
        const catArr: string[] = ["All"];
        catSnap.forEach((doc) => {
          if (doc.data().name) {
            catArr.push(doc.data().name);
          }
        });
        // Use Set to ensure uniqueness in case the database contains duplicate category names
        setCategories(Array.from(new Set(catArr)));
      }

      // 4. Fetch Leaderboards
      const usersSnap = await getDocs(query(collection(db, "users"), limit(100)));
      const lbArr: any[] = [];
      usersSnap.forEach((doc) => {
        const d = doc.data();
        lbArr.push({
          id: doc.id,
          name: d.appName || "Gamer",
          score: d.matchesWon || 0,
          kills: d.kills || 0,
          img: d.photoUrl || `https://ui-avatars.com/api/?name=${d.appName || "Gamer"}&background=4f46e5&color=fff`,
          isMe: doc.id === auth.currentUser?.uid,
        });
      });
      lbArr.sort((a, b) => b.score - a.score);
      setLeaderboard(lbArr.slice(0, 10));

      // 5. Fetch Global Broadcast notifications
      const notifSnap = await getDocs(collection(db, "notifications"));
      const notifArr: any[] = [];
      notifSnap.forEach((doc) => {
        notifArr.push({ id: doc.id, ...doc.data() });
      });
      setNotifications(notifArr);
    } catch (e) {
      console.error(e);
    }
  };

  // Sync profile details and transaction logs when authed
  const fetchAuthUserData = async (uid: string) => {
    try {
      const snap = await getDoc(doc(db, "users", uid));
      if (snap.exists()) {
        const d = snap.data();
        let appUid = d.appUid;
        if (!appUid) {
          let generatedAppUid = "";
          let isUnique = false;
          let checkLimit = 10;
          while (!isUnique && checkLimit > 0) {
            const possibleUid = Math.floor(1000 + Math.random() * 9000).toString();
            const q = query(collection(db, "users"), where("appUid", "==", possibleUid));
            const querySnap = await getDocs(q);
            if (querySnap.empty) {
              generatedAppUid = possibleUid;
              isUnique = true;
            }
            checkLimit--;
          }
          if (!generatedAppUid) {
            generatedAppUid = Math.floor(1000 + Math.random() * 9000).toString();
          }
          await updateDoc(doc(db, "users", uid), { appUid: generatedAppUid });
          appUid = generatedAppUid;
          d.appUid = appUid;
        }
        setUserData({ uid, ...d } as UserData);
      }

      const trxSnap = await getDocs(collection(db, "users", uid, "transactions"));
      const trxArr: Transaction[] = [];
      trxSnap?.forEach((d) => {
        trxArr.push({ id: d.id, ...d.data() } as Transaction);
      });
      // Sort reverse-chronologically by createdAt first, falling back to parsing date
      trxArr.sort((a, b) => {
        const timeA = a.createdAt || (a.date ? new Date(a.date).getTime() : 0) || 0;
        const timeB = b.createdAt || (b.date ? new Date(b.date).getTime() : 0) || 0;
        return timeB - timeA;
      });
      setTransactions(trxArr);
    } catch (e) {
      console.error(e);
    }
  };

  // Handle dynamic auth state change
  useEffect(() => {
    let unsubUserDoc: (() => void) | null = null;
    let unsubUserTrx: (() => void) | null = null;

    const unsub = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        
        // Ensure initial statistics configuration & appUid are verified
        await fetchAuthUserData(user.uid);

        // Real-time synchronization for user profile document
        unsubUserDoc = onSnapshot(doc(db, "users", user.uid), (snapshot) => {
          if (snapshot.exists()) {
            const d = snapshot.data();
            setUserData({ uid: user.uid, ...d } as UserData);
          }
        }, (err) => {
          console.error("User profile document sync error:", err);
        });

        // Real-time synchronization for user statements feed
        unsubUserTrx = onSnapshot(collection(db, "users", user.uid, "transactions"), (snapshot) => {
          const trxArr: Transaction[] = [];
          snapshot.forEach((d) => {
            trxArr.push({ id: d.id, ...d.data() } as Transaction);
          });
          // Sort reverse-chronologically by createdAt first, falling back to parsing date
          trxArr.sort((a, b) => {
            const timeA = a.createdAt || (a.date ? new Date(a.date).getTime() : 0) || 0;
            const timeB = b.createdAt || (b.date ? new Date(b.date).getTime() : 0) || 0;
            return timeB - timeA;
          });
          setTransactions(trxArr);
        }, (err) => {
          console.error("User transactions sync error:", err);
        });

      } else {
        if (unsubUserDoc) {
          unsubUserDoc();
          unsubUserDoc = null;
        }
        if (unsubUserTrx) {
          unsubUserTrx();
          unsubUserTrx = null;
        }
        setCurrentUser(null);
        setUserData(null);
        setTransactions([]);
      }
      setAuthLoading(false);
    });

    // Run global loaders
    fetchGlobalData();

    return () => {
      unsub();
      if (unsubUserDoc) unsubUserDoc();
      if (unsubUserTrx) unsubUserTrx();
    };
  }, []);

  // Set up live real-time matches listener
  useEffect(() => {
    const unsubMatches = onSnapshot(collection(db, "matches"), async (snapshot) => {
      let matchArr: Match[] = [];
      snapshot.forEach((doc) => {
        matchArr.push({ id: doc.id, ...doc.data() } as Match);
      });

      if (matchArr.length === 0) {
        // Asynchronously seed some matches if collection is empty
        const initialSeed: Omit<Match, "id">[] = [
          {
            title: "Pro CS Cash Clash Cup",
            type: "CS-Ranked",
            map: "Bermuda",
            prize: 100,
            fee: 15,
            total: 8,
            joined: 3,
            status: "upcoming",
            startTime: { seconds: Math.floor(Date.now() / 1000) + 18000, nanoseconds: 0 },
            img: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400"
          },
          {
            title: "Bermuda Classic Squad Run",
            type: "Battle Royale",
            map: "Bermuda",
            prize: 250,
            fee: 25,
            total: 48,
            joined: 19,
            status: "upcoming",
            startTime: { seconds: Math.floor(Date.now() / 1000) + 43200, nanoseconds: 0 },
            img: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=400"
          },
          {
            title: "Kalahari Daily Snipers Hunt",
            type: "Battle Royale",
            map: "Kalahari",
            prize: 300,
            fee: 30,
            total: 48,
            joined: 42,
            status: "upcoming",
            startTime: { seconds: Math.floor(Date.now() / 1000) + 86400, nanoseconds: 0 },
            img: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=400"
          },
          {
            title: "Ludo 1v1 Kings Throne",
            type: "Ludo",
            map: "Classic Board",
            prize: 80,
            fee: 10,
            total: 4,
            joined: 2,
            status: "upcoming",
            startTime: { seconds: Math.floor(Date.now() / 1000) + 9000, nanoseconds: 0 },
            img: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&q=80&w=400"
          }
        ];

        for (const m of initialSeed) {
          await addDoc(collection(db, "matches"), m);
        }
      } else {
        // Sort chronologically
        matchArr.sort((a, b) => {
          const timeA = a.startTime?.seconds ? a.startTime.seconds * 1000 : new Date(a.startTime).getTime();
          const timeB = b.startTime?.seconds ? b.startTime.seconds * 1000 : new Date(b.startTime).getTime();
          return timeA - timeB;
        });
        setMatches(matchArr);
      }
    }, (error) => {
      console.error("Error listening to matches: ", error);
    });

    return () => unsubMatches();
  }, []);

  // Set up live real-time banners sync listener
  useEffect(() => {
    const unsubBanners = onSnapshot(collection(db, "banners"), async (snapshot) => {
      let bannerArr: any[] = [];
      snapshot.forEach((doc) => {
        bannerArr.push({ id: doc.id, ...doc.data() });
      });

      if (bannerArr.length === 0) {
        // Seed some initial banners with the new images provided by the user
        const initialBanners = [
          {
            img: "https://ais-pre-xhfkyaaiwptg7ioebj5yew-981049882163.asia-southeast1.run.app/attachments/2d96c9c4-c2c3-424a-b5df-6a3f019fa76b",
            title: "PRO CASH TOURNAMENTS",
            subtitle: "Play daily matches & withdraw instantly via bKash or Nagad"
          },
          {
            img: "https://ais-pre-xhfkyaaiwptg7ioebj5yew-981049882163.asia-southeast1.run.app/attachments/5ae74fcc-9a3b-41ca-ab2d-05881ba889c0",
            title: "ULTIMATE SURVIVAL BOOYAH",
            subtitle: "High stake squad matches with huge winning rewards"
          },
          {
            img: "https://images.unsplash.com/photo-1614680376593-902f74cf0d41?auto=format&fit=crop&q=80&w=800",
            title: "JOIN OUR COMMUNITY",
            subtitle: "Get latest updates and support on our official WhatsApp group"
          }
        ];

        for (const b of initialBanners) {
          await addDoc(collection(db, "banners"), b);
        }
      } else {
        setBanners(bannerArr);
      }
    }, (error) => {
      console.error("Error listening to banners: ", error);
    });

    return () => unsubBanners();
  }, []);

  // Secure Auth form functions
  const handleLogin = async (email: string, pass: string) => {
    if (!email || !pass) return handleToast("Please fill all authentications fields.");
    try {
      await signInWithEmailAndPassword(auth, email.trim(), pass);
      setShowAuthModal(false);
      handleToast("Signed in successfully!");
    } catch (e: any) {
      handleToast(e.message || "Failed to log in.");
    }
  };

  const handleRegister = async (name: string, email: string, phone: string, pass: string) => {
    if (!name || !email || !phone || !pass) return handleToast("All signup fields are required.");
    if (phone.length < 11) return handleToast("Please specify a valid 11-digit mobile contact.");
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      await updateProfile(cred.user, { displayName: name });
      
      // Generate unique 4 digit code
      let generatedAppUid = "";
      let isUnique = false;
      let checkLimit = 10;
      while (!isUnique && checkLimit > 0) {
        const possibleUid = Math.floor(1000 + Math.random() * 9000).toString();
        const q = query(collection(db, "users"), where("appUid", "==", possibleUid));
        const querySnap = await getDocs(q);
        if (querySnap.empty) {
          generatedAppUid = possibleUid;
          isUnique = true;
        }
        checkLimit--;
      }
      if (!generatedAppUid) {
        generatedAppUid = Math.floor(1000 + Math.random() * 9000).toString();
      }

      const newD: Omit<UserData, "uid"> = {
        appUid: generatedAppUid,
        appName: name,
        email: email.trim(),
        phone: phone.trim(),
        balance: 0,
        joined_matches: [],
        score: 0,
        kills: 0,
        matchesPlayed: 0,
        matchesWon: 0,
        totalEarned: 0,
        gameName: "",
        gameUid: "",
        isUidVerified: false,
        nameChangesLeft: 2,
      };

      await setDoc(doc(db, "users", cred.user.uid), newD);
      setUserData({ uid: cred.user.uid, ...newD } as UserData);
      setShowAuthModal(false);
      handleToast("Registration completed! Welcome aboard.");
    } catch (e: any) {
      handleToast(e.message || "Registration failed.");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setSidebarOpen(false);
      setActiveView("home");
      handleToast("Authenticated profile logged out cleanly.");
    } catch (e: any) {
      handleToast("Failed to log out.");
    }
  };

  // Profile Save
  const handleSaveProfile = async (appName: string, gameName: string, gameUid: string, avatarUrl?: string) => {
    if (!userData) return;
    if (appName.trim().length < 3) return handleToast("Nickname must be between 3-20 characters.");
    try {
      const updates: any = { gameName: gameName.trim() };
      if (appName !== userData.appName) {
        updates.appName = appName.trim();
        await updateProfile(auth.currentUser!, { displayName: appName.trim() });
      }
      updates.gameUid = gameUid.trim();
      if (avatarUrl) {
        updates.photoUrl = avatarUrl;
      }

      await updateDoc(doc(db, "users", userData.uid), updates);
      await fetchAuthUserData(userData.uid);
      setShowEditProfileModal(false);
      handleToast("Gamer profile saved successfully.");
    } catch (e) {
      handleToast("Failed to update profile statistics.");
    }
  };

  // Default withdrawal values save
  const handleSavePaymentSettings = async (methodNum: string, name: string) => {
    if (!userData) return;
    try {
      await updateDoc(doc(db, "users", userData.uid), {
        paymentMethod: methodNum.trim(),
        paymentName: name.trim(),
      });
      await fetchAuthUserData(userData.uid);
      setShowSettingsModal(false);
      handleToast("Withdrawal details updated.");
    } catch (e) {
      handleToast("Error saving account credentials.");
    }
  };

  // Join match confirmation
  const handleConfirmJoinMatch = async (gName: string, gUid: string) => {
    if (!userData || !activeJoinMatch) return;
    if (isAppJoiningMatch) return;
    
    // Hard check to block duplicate balance deduction
    if (userData.joined_matches && userData.joined_matches.includes(activeJoinMatch.id)) {
      handleToast("You have already joined this match! Double-clicks blocked.");
      setActiveJoinMatch(null);
      return;
    }

    const fee = activeJoinMatch.fee;
    const depositBal = userData.balance || 0;
    const winBal = userData.winBalance ?? 0;
    const totalBal = depositBal + winBal;

    if (totalBal < fee) return handleToast("Insufficient coins available inside your wallet.");

    setIsAppJoiningMatch(true);

    try {
      // Find an available slot number specifically for this user
      const usersRef = collection(db, "users");
      const snap = await getDocs(query(usersRef, where("joined_matches", "array-contains", activeJoinMatch.id)));
      const takenSlots = new Set<number>();
      snap.forEach((d) => {
        const u = d.data();
        if (u.matchSlots && u.matchSlots[activeJoinMatch.id]) {
          takenSlots.add(Number(u.matchSlots[activeJoinMatch.id]));
        }
      });

      let assignedSlot = 1;
      const totalSlots = activeJoinMatch.total || 48;
      const available: number[] = [];
      for (let s = 1; s <= totalSlots; s++) {
        if (!takenSlots.has(s)) {
          available.push(s);
        }
      }
      if (available.length > 0) {
        assignedSlot = available[0];
      } else {
        assignedSlot = Math.min(activeJoinMatch.joined + 1, totalSlots);
      }

      // Deduct ledger balance, append join lists (using combined balance deduction)
      let nextDepositBal = depositBal;
      let nextWinBal = winBal;
      if (depositBal >= fee) {
        nextDepositBal = depositBal - fee;
      } else {
        const remainder = fee - depositBal;
        nextDepositBal = 0;
        nextWinBal = winBal - remainder;
      }

      const userRef = doc(db, "users", userData.uid);
      const matchRef = doc(db, "matches", activeJoinMatch.id);

      // Instantly optimize local state first within 1 second so UI updates instantly
      setUserData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          balance: nextDepositBal,
          winBalance: nextWinBal,
          joined_matches: [...(prev.joined_matches || []), activeJoinMatch.id],
          matchesPlayed: (prev.matchesPlayed || 0) + 1,
          gameName: gName,
          gameUid: gUid,
          matchSlots: {
            ...(prev.matchSlots || {}),
            [activeJoinMatch.id]: assignedSlot,
          },
        };
      });

      await updateDoc(matchRef, { joined: activeJoinMatch.joined + 1 });
      await updateDoc(userRef, {
        balance: nextDepositBal,
        winBalance: nextWinBal,
        joined_matches: arrayUnion(activeJoinMatch.id),
        matchesPlayed: (userData.matchesPlayed || 0) + 1,
        gameName: gName,
        gameUid: gUid,
        matchSlots: {
          ...(userData.matchSlots || {}),
          [activeJoinMatch.id]: assignedSlot,
        },
      });

      // Write Transaction log
      await addDoc(collection(db, "users", userData.uid, "transactions"), {
        title: `Joined: ${activeJoinMatch.title} (Slot ${assignedSlot})`,
        amount: `-${fee}`,
        type: "game",
        status: "success",
        date: new Date().toLocaleDateString(),
        createdAt: Date.now(),
      });

      setActiveJoinMatch(null);
      handleToast(`Successfully joined! You have been assigned Slot ${assignedSlot}. This slot is now permanently locked & fixed.`);
      await fetchAuthUserData(userData.uid);
      await fetchGlobalData();
    } catch (e: any) {
      handleToast(e.message || "Match entry fee payment failed.");
    } finally {
      setIsAppJoiningMatch(false);
    }
  };

  // Deposit Request
  const handleDeposit = async (amount: string, trxId: string) => {
    if (!userData) return;
    const val = parseFloat(amount);
    if (!val || val <= 0) return handleToast("Please specify a valid positive sum.");
    try {
      const trxPayload = {
        title: "Deposit Cash Request",
        amount: `+${val}`,
        type: "deposit",
        status: "pending",
        trxId: trxId.trim(),
        date: new Date().toLocaleDateString(),
        createdAt: Date.now(),
        userUid: userData.uid,
        userPhone: userData.phone,
        userName: userData.appName,
      };

      const trxRef = collection(db, "users", userData.uid, "transactions");
      await addDoc(trxRef, trxPayload);

      // Write to global collection for Admin panel tracking
      await addDoc(collection(db, "global_transactions"), trxPayload);

      setShowDepositModal(false);
      handleToast("Verified. Admin is analyzing transaction logs.");
      await fetchAuthUserData(userData.uid);
    } catch (e) {
      handleToast("Failed to post payment query.");
    }
  };

  // Withdraw cash request
  const handleWithdraw = async (amount: string, walletNum: string, selectMethod: string) => {
    if (!userData) return;
    const val = parseFloat(amount);
    const winBal = userData.winBalance ?? 0;
    if (!val || val < 100) return handleToast("Minimum withdrawal requirement is ৳100.");
    if (val > winBal) return handleToast("Insufficient winning balance.");
    try {
      const uniqueTrxId = `W-${Math.floor(100000 + Math.random() * 900000)}`;
      const trxPayload = {
        title: `Withdraw (${selectMethod})`,
        amount: `-${val}`,
        type: "withdraw",
        status: "pending",
        number: walletNum.trim(),
        method: selectMethod,
        trxId: uniqueTrxId,
        date: new Date().toLocaleDateString(),
        createdAt: Date.now(),
        userUid: userData.uid,
        userPhone: userData.phone,
        userName: userData.appName,
      };

      const trxRef = collection(db, "users", userData.uid, "transactions");
      await addDoc(trxRef, trxPayload);

      // Write to global collection for Admin panel tracking
      await addDoc(collection(db, "global_transactions"), trxPayload);

      // Deduct winning balance specifically
      await updateDoc(doc(db, "users", userData.uid), {
        winBalance: winBal - val,
      });

      setShowWithdrawModal(false);
      handleToast("Cashout query submitted to review ledger.");
      await fetchAuthUserData(userData.uid);
    } catch (e) {
      handleToast("Network connection timed out.");
    }
  };

  // Friend UID receiver verification search (using 4-digit App UID!)
  const handleVerifyReceiver = async (appUid: string) => {
    if (!appUid || appUid === userData?.appUid) return { verified: false };
    try {
      const q = query(collection(db, "users"), where("appUid", "==", appUid.trim()));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const docAndData = snap.docs[0];
        return { verified: true, appName: docAndData.data().appName, recipientUid: docAndData.id };
      }
    } catch (e) {}
    return { verified: false };
  };

  // Secure balance transfer
  const handleTransfer = async (uid: string, amount: number, note: string, pass: string) => {
    // ... existed logic (truncated for edit_file usage)
  };

  const handleOpenRoomDetails = (match: Match) => {
    if (!userData?.joined_matches?.includes(match.id)) {
      return handleToast("You must join this match to view Room ID/Pass.");
    }
    setSelectedMatchForDetails(match);
    setShowRoomModal(true);
  };

  const handleOpenPrizeDetails = (match: Match) => {
    setSelectedMatchForDetails(match);
    setShowPrizeModal(true);
  };

  const handleOpenSlotsDetails = async (match: Match) => {
    setSelectedMatchForDetails(match);
    setShowSlotsModal(true);
    setMatchParticipants([]); // Loading state
    try {
      // Fetch users who joined this match
      const q = query(collection(db, "users"), where("joined_matches", "array-contains", match.id));
      const snap = await getDocs(q);
      const parts: any[] = [];
      snap.forEach(d => {
        const u = d.data();
        parts.push({
          uid: d.id,
          appName: u.appName,
          gameName: u.gameName,
          slot: u.matchSlots ? u.matchSlots[match.id] : null
        });
      });
      // Sort by slot number
      parts.sort((a, b) => (Number(a.slot) || 99) - (Number(b.slot) || 99));
      setMatchParticipants(parts);
    } catch (e) {
      console.error(e);
    }
  };

  const handleOpenRulesDetails = (match: Match) => {
    setSelectedMatchForDetails(match);
    setShowRulesModal(true);
  };

  // Redeems a promotional giveaway code dynamically
  const handleRedeemPromo = async (code: string) => {
    if (!userData) return;
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return handleToast("Please enter a valid code.");

    try {
      // 1. Check dynamic Firestore giveaways collection first
      const giveawayRef = doc(db, "giveaways", cleanCode);
      const giveawaySnap = await getDoc(giveawayRef);

      let reward = 0;
      let isDynamic = false;

      if (giveawaySnap.exists()) {
        const giveawayData = giveawaySnap.data();
        reward = Number(giveawayData.reward || 0);
        const claimedBy: string[] = giveawayData.claimedBy || [];
        
        if (claimedBy.includes(userData.uid)) {
          handleToast("You have already redeemed this promo code!");
          throw new Error("Already redeemed");
        }
        
        isDynamic = true;
      } else {
        // Fallback to static offline codes
        const promos: Record<string, number> = {
          LETPLAY20: 20,
          BOOYAH50: 50,
          ANKON50: 50,
          FREECOIN10: 10,
        };

        if (!(cleanCode in promos)) {
          handleToast("Invalid promo giveaway code!");
          throw new Error("Invalid promo giveaway code");
        }

        reward = promos[cleanCode];
      }

      const userRef = doc(db, "users", userData.uid);
      const userSnap = await getDoc(userRef);
      if (!userSnap.exists()) return;

      const userDocData = userSnap.data();
      const claimed: string[] = userDocData.claimedPromos || [];

      if (!isDynamic && claimed.includes(cleanCode)) {
        handleToast("You have already redeemed this promo code!");
        throw new Error("Already redeemed");
      }

      // Update user wallet balance & record claimed promo
      await updateDoc(userRef, {
        balance: increment(reward),
        claimedPromos: arrayUnion(cleanCode),
      });

      // If dynamic, record the claimant on the giveaway document to prevent duplicate claims
      if (isDynamic) {
        await updateDoc(giveawayRef, {
          claimedBy: arrayUnion(userData.uid)
        });
      }

      // Write user transaction log
      await addDoc(collection(db, "users", userData.uid, "transactions"), {
        title: `Redeemed Giveaway: ${cleanCode}`,
        amount: `+${reward}`,
        type: "deposit",
        status: "success",
        date: new Date().toLocaleDateString(),
        createdAt: Date.now(),
      });

      handleToast(`Congratulations! Added ৳${reward} to your balance, real-time!`);
      await fetchAuthUserData(userData.uid);
    } catch (e: any) {
      if (e.message !== "Already redeemed" && e.message !== "Invalid promo giveaway code") {
        handleToast("Failed to redeem giveaway code.");
      }
      throw e;
    }
  };

  if (authLoading) {
    return (
      <div className="relative min-h-screen bg-[#07080a] w-full flex items-center justify-center text-slate-100 selection:bg-blue-600">
        <div className="w-full max-w-md bg-[#0e1015] min-h-screen flex flex-col items-center justify-center relative border-x border-[#21242c]/55 py-12 px-6">
          <div className="relative mb-5">
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#2d82fe] to-amber-500 opacity-60 blur-md animate-pulse"></div>
            <div className="w-16 h-16 rounded-full bg-[#07080a] flex items-center justify-center relative border border-slate-800">
              <span className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
            </div>
          </div>
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-100 font-sans animate-pulse">
            Ꭷɴᴇㅤꜰʟᴇx.!TUR!
          </h3>
          <p className="text-[9px] uppercase font-mono text-slate-500 tracking-wider mt-1.5 leading-none">
            Loading secure connection...
          </p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="relative min-h-screen bg-[#07080a] w-full flex justify-center selection:bg-blue-600 selection:text-white">
        <div className="w-full max-w-md bg-[#0e1015] min-h-screen flex flex-col justify-between relative border-x border-[#21242c]/55 overflow-x-hidden">
          <AuthView
            onLogin={handleLogin}
            onRegister={handleRegister}
            onToast={handleToast}
          />
          {toastMessage && (
            <div className="fixed bottom-[115px] left-1/2 -translate-x-1/2 bg-slate-900 text-white text-xs px-5 py-3 rounded-full flex items-center gap-2 shadow-2xl z-100 font-bold transition-all border border-slate-800 animate-slide-up">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse animate-duration-1000" />
              <span>{toastMessage}</span>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-[#07080a] w-full flex justify-center selection:bg-blue-600 selection:text-white">
      {/* Container wrapper suited for high quality desktop preview framing */}
      <div className="w-full max-w-md bg-[#0e1015] min-h-screen flex flex-col justify-between relative shadow-none border-x border-[#21242c]/55 overflow-x-hidden">
        {/* APP HEADER */}
        <Header
          userData={userData}
          onOpenDrawer={() => setSidebarOpen(true)}
          onGoToWallet={() => setActiveView("wallet")}
          onCheckLogin={checkLogin}
          onOpenNotice={() => setShowNoticeModal(true)}
        />

        {/* MAIN BODY NAVIGATION SECTOR VIEWS */}
        <main className="flex-1 w-full bg-[#0e1015] overflow-y-auto">
          {activeView === "home" && (
            <HomeView
              bannerConfig={appConfig}
              banners={banners}
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategoryName(cat);
                setActiveView("category-matches");
              }}
              matches={matches}
              joinedMatchIds={userData?.joined_matches || []}
              onOpenJoin={(m) => checkLogin(() => setActiveJoinMatch(m))}
              onCheckLogin={checkLogin}
              userData={userData}
              onCopyText={handleCopyText}
              onOpenRoomDetails={handleOpenRoomDetails}
              onOpenPrizeDetails={handleOpenPrizeDetails}
              onOpenSlotsDetails={handleOpenSlotsDetails}
              onOpenRulesDetails={handleOpenRulesDetails}
            />
          )}

          {activeView === "category-matches" && selectedCategoryName && (
            <CategoryMatchesView
              category={selectedCategoryName}
              matches={matches.filter(m => m.type === selectedCategoryName)}
              onBack={() => setActiveView("home")}
              onSelectMatch={(m) => {
                setSelectedMatch(m);
                setActiveView("match-detail-full");
              }}
              onOpenRoomDetails={handleOpenRoomDetails}
              onOpenPrizeDetails={handleOpenPrizeDetails}
              onOpenSlotsDetails={handleOpenSlotsDetails}
              onOpenRulesDetails={handleOpenRulesDetails}
            />
          )}

          {activeView === "match-detail-full" && selectedMatch && (
            <MatchDetailView
              match={selectedMatch}
              onBack={() => setActiveView("category-matches")}
              onJoin={(m) => checkLogin(() => setActiveJoinMatch(m))}
              isJoined={userData?.joined_matches?.includes(selectedMatch.id) || false}
              userData={userData}
              onOpenRoomDetails={handleOpenRoomDetails}
              onOpenPrizeDetails={handleOpenPrizeDetails}
              onOpenSlotsDetails={handleOpenSlotsDetails}
              onOpenRulesDetails={handleOpenRulesDetails}
            />
          )}

          {activeView === "matches" && (
            <MyMatchesView
              activeSubTab={myMatchesSubTab}
              onSelectSubTab={setMyMatchesSubTab}
              matches={matches}
              joinedMatchIds={userData?.joined_matches || []}
              onCopyText={handleCopyText}
              userData={userData}
              onBack={() => setActiveView("home")}
              onOpenRoomDetails={handleOpenRoomDetails}
              onOpenPrizeDetails={handleOpenPrizeDetails}
              onOpenSlotsDetails={handleOpenSlotsDetails}
            />
          )}

          {activeView === "leaderboard" && (
            <LeaderboardView
              leaderboard={leaderboard}
              userData={userData}
              onCheckLogin={checkLogin}
              matches={matches}
              categories={categories}
              onCopyText={handleCopyText}
              onToast={handleToast}
              onBack={() => setActiveView("home")}
            />
          )}

          {activeView === "wallet" && (
            <WalletView
              userData={userData}
              transactions={transactions}
              onOpenDeposit={() => checkLogin(() => setShowDepositModal(true))}
              onOpenWithdraw={() => checkLogin(() => setShowWithdrawModal(true))}
              onOpenTransfer={() => checkLogin(() => setShowTransferModal(true))}
              onOpenSupport={() => handleCopyText(appConfig.adminPhone)}
              onBack={() => setActiveView("profile")}
              onViewAllTransactions={() => setActiveView("statements")}
            />
          )}

          {activeView === "statements" && (
            <StatementsView
              userData={userData}
              transactions={transactions}
              onBack={() => setActiveView("profile")}
            />
          )}

          {activeView === "admin" && (
            <AdminView
              onToast={handleToast}
              matches={matches}
              onRefreshMatches={fetchGlobalData}
              appConfig={appConfig}
              onRefreshConfig={fetchGlobalData}
              banners={banners}
              categories={categories}
              onBack={() => setActiveView("profile")}
            />
          )}

          {activeView === "profile" && (
            <ProfileView
              userData={userData}
              onOpenDeposit={() => checkLogin(() => setShowDepositModal(true))}
              onOpenWithdraw={() => checkLogin(() => setShowWithdrawModal(true))}
              onOpenEditProfile={() => checkLogin(() => setShowEditProfileModal(true))}
              onSelectView={setActiveView}
              onLogout={handleLogout}
              onCopyText={handleCopyText}
              onToast={handleToast}
              onRedeemPromo={handleRedeemPromo}
              onOpenNotifications={() => setShowNotifModal(true)}
              hasUnreadNotification={notifications.length > 0}
            />
          )}
        </main>

        {/* BOTTOM FOOTER NAVIGATION COMPONENT */}
        <FooterNav
          activeView={activeView}
          onSelectView={setActiveView}
          onCheckLogin={checkLogin}
        />

        {/* SHORTCUT DRAWER SIDEBAR PANEL */}
        <Drawer
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          userData={userData}
          onOpenAuth={() => setShowAuthModal(true)}
          onOpenEditProfile={() => setShowEditProfileModal(true)}
          onOpenRules={() => setShowRulesModal(true)}
          onOpenSettings={() => setShowSettingsModal(true)}
          onOpenSupport={() => handleCopyText(appConfig.adminPhone)}
          onLogout={handleLogout}
          onSelectView={setActiveView}
          onSelectSubTab={setMyMatchesSubTab}
          onCheckLogin={checkLogin}
        />

        {/* CUSTOM TRANSACTION REVIEW ALERTS (TOAST POPUP) */}
        {toastMessage && (
          <div className="fixed bottom-[85px] left-1/2 -translate-x-1/2 bg-slate-900 text-white text-xs px-5 py-3 rounded-full flex items-center gap-2 shadow-2xl z-100 font-bold transition-all border border-slate-800 animate-slide-up">
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* MODAL CONFIGURATIONS WRAPPER */}
        <Modals
          showNotice={showNoticeModal}
          noticeText={appConfig.notice}
          onCloseNotice={() => setShowNoticeModal(false)}
          showNotifModal={showNotifModal}
          onCloseNotifModal={() => setShowNotifModal(false)}
          notifList={notifications}
          showEditModal={showEditProfileModal}
          onCloseEditModal={() => setShowEditProfileModal(false)}
          userData={userData}
          onSaveProfile={handleSaveProfile}
          showSettingsModal={showSettingsModal}
          onCloseSettingsModal={() => setShowSettingsModal(false)}
          onSavePaymentSettings={handleSavePaymentSettings}
          activeJoinMatch={activeJoinMatch}
          onCloseJoinMatch={() => setActiveJoinMatch(null)}
          userDataBalance={userData?.balance || 0}
          onConfirmJoinMatch={handleConfirmJoinMatch}
          showRoomModal={showRoomModal}
          onCloseRoomModal={() => setShowRoomModal(false)}
          showPrizeModal={showPrizeModal}
          onClosePrizeModal={() => setShowPrizeModal(false)}
          showSlotsModal={showSlotsModal}
          onCloseSlotsModal={() => setShowSlotsModal(false)}
          showRulesModal={showRulesModal}
          onCloseRulesModal={() => setShowRulesModal(false)}
          selectedMatchForDetails={selectedMatchForDetails}
          participants={matchParticipants}
          showDepositModal={showDepositModal}
          onCloseDepositModal={() => setShowDepositModal(false)}
          adminBkashPhone={appConfig.adminPhone}
          appConfig={appConfig}
          onDeposit={handleDeposit}
          showWithdrawModal={showWithdrawModal}
          onCloseWithdrawModal={() => setShowWithdrawModal(false)}
          onWithdraw={handleWithdraw}
          showTransferModal={showTransferModal}
          onCloseTransferModal={() => setShowTransferModal(false)}
          onVerifyReceiver={handleVerifyReceiver}
          onTransfer={handleTransfer}
          showAuthModal={showAuthModal}
          onCloseAuthModal={() => setShowAuthModal(false)}
          onLogin={handleLogin}
          onRegister={handleRegister}
          onToast={handleToast}
        />
      </div>
    </div>
  );
}
